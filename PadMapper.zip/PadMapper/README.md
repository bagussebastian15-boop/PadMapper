# PadMapper

Aplikasi Android untuk memetakan tombol gamepad (Bluetooth/USB) ke sentuhan layar game.
Tanpa root. Memakai layanan aksesibilitas.

## Fitur
- Auto Map 1 klik (preset layout landscape)
- Multi-tombol bersamaan
- Stik kiri = joystick virtual, stik kanan = joystick virtual kedua (cara kerja sama, pusatnya diatur di editor)
- Editor posisi tombol di atas game (SELECT + START)
- Gelembung melayang (tap = panel: saklar analog kiri & kanan, mapping on/off, tampilkan tombol, mode stik, transparansi, edit posisi)
- Pengaturan transparansi 20–100%
- Sentuhan mengikuti lama tekan tombol (bawaan); mode TAP sekali (hijau) bisa dipilih per tombol di editor
- Ukuran tombol bisa diubah per tombol di editor (slider)
- Kalibrasi sumbu stik kanan
- Analog stik kiri & kanan aktif bawaan; bisa dimatikan/dinyalakan lewat saklar di panel gelembung
- Stik analog halus (kiri & kanan): deadzone radial, jangkauan bisa diatur
- Mode halus: lintasan sentuhan melengkung bersambung + penghalusan (mengurangi kesan patah-patah)
- D-pad serong: dua arah bersamaan (mis. kanan+atas) = satu sentuhan di titik serong
- Gerak 8 arah (opsional): stik kiri dikunci ke 8 arah supaya sentuhan stabil, tidak getar
- Stik kanan punya dua mode (saklar): analog biasa (sama seperti stik kiri) atau mode kamera (jari menggeser terus, kecepatan bisa diatur)
- Anti macet multi-touch: bila gestur dibatalkan sistem, stik analog dimulai ulang dari pusat (saklar di panel gelembung); panel diagnosis menampilkan sumbu stik & jumlah pembatalan
- Jangkauan stik kamera: radius area geser kamera bisa diatur (slider di panel gelembung/layar utama, atau di editor dengan memilih lingkaran RS saat mode kamera)
- Multi-touch: jumlah jari per gestur mengikuti batas sistem (biasanya 10 = LS + RS + 8 tombol); yang tidak muat ditunda, bukan menghapus semua sentuhan
- Kamera: jari kamera diangkat dulu baru diturunkan lagi di pusat (tidak tumpang-tindih), dan koordinatnya dijaga tetap di dalam layar
- Multi-touch lebih tahan banting: satu sentuhan bermasalah tidak lagi menghapus semua sentuhan; koordinat dijaga ≥ 0; pembatalan tidak lagi memunculkan ketukan hantu; error mesin tampil di panel diagnosis (ERR)
- Tombol bahu (L1/L2/R1/R2) tidak lagi terlepas saat dua stik digerakkan bersamaan: target sentuhan stik dijepit ke batas layar yang benar per sumbu (dulu tinggi bisa melewati layar sehingga sistem membatalkan SELURUH gestur), dan tombol yang masih ditahan dipasang ulang otomatis bila sentuhannya hilang; panel diagnosis menampilkan 'klem' (berapa kali target keluar layar)
- Perbaikan tombol bahu terlepas (v3.3): sistem Android membatalkan SELURUH gestur bila gestur lanjutan membawa jari baru yang mulai bersamaan dengan jari yang ditahan (mis. stik kiri/kanan masuk lagi dari deadzone saat L1/L2/R1/R2 ditahan). Sekarang jari baru dimulai beberapa milidetik lebih lambat di dalam gestur yang sama, sehingga jari yang ditahan tidak pernah terputus; panel diagnosis menampilkan 'susul'
- Perbaikan analog macet (v3.4): (1) kamera stik kanan tidak lagi mati setelah jari diangkat di tepi area saat tidak ada jari lain aktif (mesin dulu berhenti bila daftar sentuhan kosong sehingga jari kamera tak pernah diturunkan lagi); (2) bila jari LS/RS hilang dari mesin padahal stik masih didorong (error/reset/gagal kirim), jari dipasang ulang otomatis; (3) tiap event stik 'menendang' mesin sehingga pengaman waktu berjalan walau stik ditahan terus
- Layar tes gamepad (kode tombol & sumbu)
- Diagnosis: titik jari virtual di layar (saklar di panel gelembung) menampilkan posisi sentuhan yang dikirim ke sistem + jumlah pembatalan gestur
- Ikon aplikasi: gambar D-pad

## Build
**Lewat GitHub Actions (tanpa Android Studio):** push ke GitHub, buka tab *Actions* → run terbaru → unduh artifact `PadMapper-debug-apk`.

**Lokal:** buka di Android Studio → Build > Build APK(s).

## Cara pakai
1. Pasang APK, buka aplikasi, aktifkan layanan aksesibilitas PadMapper.
2. Tap **AUTO MAP**, buka game, mainkan dengan gamepad.
3. Sesuaikan posisi: tekan SELECT + START saat game terbuka, geser lingkaran, SIMPAN.

## Catatan
- Stik analog: Android 14+ otomatis; Android lebih lama otomatis lewat jendela penangkap stik (game bisa kehilangan fokus).
- Trigger L2/R2 hanya terbaca bila dikirim sebagai tombol.
