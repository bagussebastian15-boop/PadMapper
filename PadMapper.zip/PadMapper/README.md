# PadMapper

Aplikasi Android untuk memetakan tombol gamepad (Bluetooth/USB) ke sentuhan layar game.
Tanpa root. Memakai layanan aksesibilitas.

## Fitur
- Auto Map 1 klik (preset layout landscape)
- Multi-tombol bersamaan
- Stik kiri = joystick virtual, stik kanan = kamera
- Editor posisi tombol di atas game (SELECT + START)
- Gelembung melayang (tap = panel: mapping on/off, tampilkan tombol, mode stik, transparansi, edit posisi)
- Pengaturan transparansi 20–100%
- Sentuhan mengikuti lama tekan tombol (bawaan); mode TAP sekali (hijau) bisa dipilih per tombol di editor
- Ukuran tombol bisa diubah per tombol di editor (slider)
- Kalibrasi sumbu stik kanan + kamera berbasis waktu
- Stik analog halus: jangkauan & kecepatan kamera bisa diatur
- Deadzone terpisah stik kiri & kanan (0–50%), batas luar (70–100%), pratinjau stik langsung, dan deteksi deadzone otomatis (ukur drift saat stik dilepas)
- Interval sentuhan (10–80 ms) bisa diatur untuk gerakan lebih halus
- Deadzone juga bisa diubah dari gelembung saat game berjalan
- Layar tes gamepad (kode tombol & sumbu)

## Build
**Lewat GitHub Actions (tanpa Android Studio):** push ke GitHub, buka tab *Actions* → run terbaru → unduh artifact `PadMapper-debug-apk`.

**Lokal:** buka di Android Studio → Build > Build APK(s).

## Cara pakai
1. Pasang APK, buka aplikasi, aktifkan layanan aksesibilitas PadMapper.
2. Tap **AUTO MAP**, buka game, mainkan dengan gamepad.
3. Sesuaikan posisi: tekan SELECT + START saat game terbuka, geser lingkaran, SIMPAN.

## Catatan
- Stik analog: Android 14+ otomatis; Android lebih lama lewat "Mode stik" (game bisa kehilangan fokus).
- Trigger L2/R2 hanya terbaca bila dikirim sebagai tombol.
