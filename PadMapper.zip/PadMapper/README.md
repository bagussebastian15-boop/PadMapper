# PadMapper

Aplikasi Android untuk memetakan tombol gamepad (Bluetooth/USB) ke sentuhan layar game.
Tanpa root. Memakai layanan aksesibilitas.

## Fitur
- Auto Map 1 klik (preset layout landscape)
- Multi-tombol bersamaan
- Stik kiri = joystick virtual, stik kanan = joystick virtual kedua (cara kerja sama, pusatnya diatur di editor)
- Editor posisi tombol di atas game (SELECT + START)
- Gelembung melayang (tap = panel: saklar analog kiri & kanan, mapping on/off, tampilkan tombol, mode stik, transparansi, edit posisi)
- Pengaturan transparansi 20–100%
- Sentuhan mengikuti lama tekan tombol (bawaan); mode TAP sekali (hijau) bisa dipilih per tombol di editor
- Ukuran tombol bisa diubah per tombol di editor (slider)
- Kalibrasi sumbu stik kanan
- Analog stik kiri & kanan aktif bawaan; bisa dimatikan/dinyalakan lewat saklar di panel gelembung
- Stik analog halus (kiri & kanan): deadzone radial, jangkauan bisa diatur
- Mode halus: lintasan sentuhan melengkung bersambung + penghalusan (mengurangi kesan patah-patah)
- D-pad serong: dua arah bersamaan (mis. kanan+atas) = satu sentuhan di titik serong
- Gerak 8 arah (opsional): stik kiri dikunci ke 8 arah supaya sentuhan stabil, tidak getar
- Stik kanan punya dua mode (saklar): analog biasa (sama seperti stik kiri) atau mode kamera (jari menggeser terus, kecepatan bisa diatur)
- Anti macet multi-touch: bila gestur dibatalkan sistem, stik analog dimulai ulang dari pusat (saklar di panel gelembung); panel diagnosis menampilkan sumbu stik & jumlah pembatalan
- Layar tes gamepad (kode tombol & sumbu)
- Diagnosis: titik jari virtual di layar (saklar di panel gelembung) menampilkan posisi sentuhan yang dikirim ke sistem + jumlah pembatalan gestur
- Ikon aplikasi: gambar D-pad

## Build
**Lewat GitHub Actions (tanpa Android Studio):** push ke GitHub, buka tab *Actions* → run terbaru → unduh artifact `PadMapper-debug-apk`.

**Lokal:** buka di Android Studio → Build > Build APK(s).

## Cara pakai
1. Pasang APK, buka aplikasi, aktifkan layanan aksesibilitas PadMapper.
2. Tap **AUTO MAP**, buka game, mainkan dengan gamepad.
3. Sesuaikan posisi: tekan SELECT + START saat game terbuka, geser lingkaran, SIMPAN.

## Catatan
- Stik analog: Android 14+ otomatis; Android lebih lama otomatis lewat jendela penangkap stik (game bisa kehilangan fokus).
- Trigger L2/R2 hanya terbaca bila dikirim sebagai tombol.
