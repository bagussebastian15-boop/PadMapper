plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.padmapper"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.padmapper"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "2.3"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
