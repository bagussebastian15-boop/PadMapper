package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Kotak nama slot yang tampil LANGSUNG di atas game (jendela overlay), tanpa pindah ke aplikasi lain.
 * Keyboard bawaan Android muncul saat kolom nama diketuk dan hilang saat Selesai / Simpan / Batal.
 * Selama terbuka, pemetaan gamepad dijeda supaya tombol gamepad tidak menyentuh game.
 */
class SaveSlotOverlay(private val svc: MapperService, private val onClosed: () -> Unit) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val imm = svc.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    private var root: Root? = null
    private lateinit var input: EditText
    private lateinit var msg: TextView
    private lateinit var save: Button
    private var confirmName: String? = null   // nama yang sudah ada & sedang menunggu konfirmasi timpa

    private fun dp(v: Int) = (v * svc.resources.displayMetrics.density).toInt()

    private inner class Root(ctx: Context) : FrameLayout(ctx) {
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) close(); return true }
            return super.dispatchKeyEvent(e)
        }
    }

    private fun pill(t: String, color: Int) = Button(svc).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE)
        transformationMethod = null
        minWidth = 0; minHeight = 0; setPadding(dp(8), 0, dp(8), 0)
        background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(color) }
    }

    fun show() {
        if (root != null) return
        input = EditText(svc).apply {
            hint = "Nama game, mis. Free Fire"
            setHintTextColor(0xFF999999.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI   // bukan keyboard layar penuh di landscape
            setSingleLine()
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_UP) showIme(); false }
            setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_DONE) { hideIme(); true } else false }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (confirmName != null) { confirmName = null; save.text = "Simpan"; setNote("") }
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        save = pill("Simpan", 0xFF2E7D32.toInt()).apply { setOnClickListener { trySave() } }
        val cancel = pill("Batal", 0xFF616161.toInt()).apply { setOnClickListener { close() } }
        msg = TextView(svc).apply { textSize = 11f; setTextColor(0xFFFFB74D.toInt()); visibility = View.GONE }

        val top = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(save, LinearLayout.LayoutParams(dp(84), dp(42)).apply { leftMargin = dp(8) })
            addView(cancel, LinearLayout.LayoutParams(dp(72), dp(42)).apply { leftMargin = dp(6) })
        }
        val card = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply { setColor(0xF0222222.toInt()); cornerRadii = floatArrayOf(dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), 0f, 0f, 0f, 0f) }
            addView(TextView(svc).apply {
                text = "Simpan slot — beri nama (wajib), mis. nama game."
                setTextColor(0xFFCCCCCC.toInt()); textSize = 12f
            })
            addView(top)
            addView(msg)
        }
        val r = Root(svc).apply {
            addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        }
        // Dapat fokus (tanpa NOT_FOCUSABLE) supaya bisa menerima ketikan; tidak berpindah aplikasi.
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        }
        try {
            wm.addView(r, lp)
            root = r
            input.requestFocus()
        } catch (e: Throwable) {
            CrashLog.save(svc, "SLOT", e)
            Toast.makeText(svc, "Gagal membuka kotak nama.", Toast.LENGTH_LONG).show()
            onClosed()
        }
    }

    private fun setNote(t: String) { msg.text = t; msg.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE }

    private fun showIme() {
        input.requestFocus()
        input.post {
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            input.postDelayed({
                if (root == null) return@postDelayed
                if (!imeVisible()) {
                    @Suppress("DEPRECATION") imm.showSoftInput(input, InputMethodManager.SHOW_FORCED)
                    input.postDelayed({
                        if (root != null && !imeVisible() && confirmName == null)
                            setNote("Keyboard tidak muncul: gamepad terdeteksi sebagai keyboard fisik. Nyalakan \"Tampilkan keyboard virtual\" di Pengaturan > Bahasa & input > Keyboard fisik.")
                    }, 500)
                }
            }, 400)
        }
    }

    private fun hideIme() { imm.hideSoftInputFromWindow(input.windowToken, 0) }

    private fun imeVisible(): Boolean {
        val v = root ?: return false
        if (Build.VERSION.SDK_INT >= 30) return v.rootWindowInsets?.isVisible(WindowInsets.Type.ime()) == true
        val r = Rect()
        v.getWindowVisibleDisplayFrame(r)
        return v.rootView.height - r.height() > v.rootView.height * 0.15f
    }

    private fun trySave() {
        val name = ProfileStore.clean(input.text.toString())
        if (name.isEmpty()) { input.error = "Nama tidak boleh kosong"; showIme(); return }
        hideIme()
        if (ProfileStore.exists(svc, name) && confirmName != name) {
            confirmName = name
            save.text = "Timpa"
            setNote("\"$name\" sudah ada. Tekan Timpa untuk mengganti, atau ubah namanya.")
            return
        }
        ProfileStore.save(svc, name)
        Toast.makeText(svc, "Tersimpan: $name", Toast.LENGTH_SHORT).show()
        close()
    }

    fun close() {
        val r = root ?: return
        root = null
        try { imm.hideSoftInputFromWindow(r.windowToken, 0) } catch (_: Exception) {}
        try { wm.removeView(r) } catch (_: Exception) {}
        onClosed()
    }
}
