package com.padmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * Pratinjau langsung kedua stik: lingkaran = jangkauan penuh, area merah = deadzone,
 * garis putus = batas luar, titik = posisi stik (hijau bila sudah melewati deadzone).
 */
class StickPreview(ctx: Context) : View(ctx) {
    var lx = 0f; var ly = 0f
    var rx = 0f; var ry = 0f

    private val d = ctx.resources.displayMetrics.density
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = 0xFF888888.toInt() }
    private val limit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = 0xFFFFB300.toInt()
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(6f * d, 4f * d), 0f)
    }
    private val dead = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x55F44336 }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f * d; color = 0xFF888888.toInt(); textAlign = Paint.Align.CENTER }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize((300 * d).toInt(), w), (170 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val r = min(width / 4f - 12f * d, height / 2f - 22f * d)
        val cy = height / 2f - 6f * d
        val outer = Prefs.outerLimit(context)
        stick(c, width * 0.25f, cy, r, lx, ly, Prefs.deadzoneLeft(context), outer, "KIRI")
        stick(c, width * 0.75f, cy, r, rx, ry, Prefs.deadzoneRight(context), outer, "KANAN")
    }

    private fun stick(c: Canvas, cx: Float, cy: Float, r: Float, x: Float, y: Float, dz: Float, outer: Float, name: String) {
        c.drawCircle(cx, cy, r, outline)
        c.drawCircle(cx, cy, r * outer, limit)
        c.drawCircle(cx, cy, r * dz, dead)
        val mag = hypot(x, y)
        val k = if (mag > 1f) 1f / mag else 1f               // titik tidak keluar dari lingkaran
        dot.color = if (mag > dz) 0xFF4CAF50.toInt() else 0xFF9E9E9E.toInt()
        c.drawCircle(cx + x * k * r, cy + y * k * r, 6f * d, dot)
        c.drawText("$name  ${Math.round(dz * 100)}%", cx, cy + r + 18f * d, txt)
    }
}
