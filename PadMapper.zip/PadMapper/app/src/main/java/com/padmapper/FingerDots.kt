package com.padmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager

/**
 * Alat diagnosis: menggambar titik di posisi tiap jari virtual yang sedang ditahan TouchEngine.
 * Tidak bisa disentuh (tidak mengganggu game). Titik = posisi yang DIKIRIM ke sistem, bukan yang terlihat di game.
 * Kalau titik di sini benar tapi game bergerak aneh, masalahnya ada di game/penerimaan sentuhan, bukan di posisi.
 */
class FingerDots(private val ctx: Context, private val engine: () -> TouchEngine?) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: DotsView? = null
    private val tick = object : Runnable {
        override fun run() {
            view?.let { v ->
                try { v.dots = engine()?.snapshot() ?: emptyList(); v.info = engine()?.cancelInfo() ?: "" } catch (_: Throwable) {}
                v.invalidate()
                handler.postDelayed(this, 33)
            }
        }
    }

    private class DotsView(ctx: Context) : View(ctx) {
        var dots: List<Triple<String, Float, Float>> = emptyList()
        var info = ""
        private val d = ctx.resources.displayMetrics.density
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAFF1744.toInt() }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2f * d
        }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 11f * d; setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
        }

        override fun onDraw(c: Canvas) {
            val r = 14f * d
            for ((id, x, y) in dots) {
                c.drawCircle(x, y, r, fill)
                c.drawCircle(x, y, r, ring)
                c.drawText("${id.substringBefore('~')} ${x.toInt()},${y.toInt()}", x + r + 4f * d, y - r, txt)
            }
            c.drawText("Jari virtual: ${dots.size} | batal ${info}", 8f * d, 16f * d, txt)
        }
    }

    fun show() {
        if (view != null) return
        val v = DotsView(ctx)
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        Win.fullScreen(lp)
        try {
            wm.addView(v, lp)
            view = v
            handler.post(tick)
        } catch (e: Throwable) { CrashLog.save(ctx, "DOTS", e) }
    }

    fun hide() {
        handler.removeCallbacks(tick)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}
