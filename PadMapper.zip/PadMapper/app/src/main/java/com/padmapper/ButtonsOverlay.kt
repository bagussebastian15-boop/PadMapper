package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/** Menampilkan posisi tombol di atas game (tidak bisa disentuh, jadi tidak mengganggu). */
class ButtonsOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null

    private fun label(k: Int) = when (k) {
        Prefs.LS -> "LS"
        Prefs.RS -> "RS"
        else -> KeyEvent.keyCodeToString(k)
            .removePrefix("KEYCODE_").removePrefix("BUTTON_").removePrefix("DPAD_").take(5)
    }

    fun show() {
        if (root != null) return
        val r = FrameLayout(ctx)
        r.alpha = Prefs.opacity(ctx) / 100f
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        Win.fullScreen(lp)
        try {
            wm.addView(r, lp)
            root = r
            r.post { try { build(r) } catch (e: Throwable) { CrashLog.save(ctx, "OVERLAY", e) } }
        } catch (e: Throwable) { CrashLog.save(ctx, "OVERLAY", e) }
    }

    private fun build(r: FrameLayout) {
        val w = r.width.toFloat()
        val h = r.height.toFloat()
        val base = h * 0.11f
        for (k in Prefs.PRESET.keys) {
            val p = Prefs.get(ctx, k) ?: continue
            val big = k < 0
            val sz = if (k == Prefs.LS || k == Prefs.RS)
                         (2f * (if (k == Prefs.RS && Prefs.rsCamera(ctx)) Prefs.rsReach(ctx) else Prefs.stickRadius(ctx)) * h).toInt().coerceAtLeast(24)
                     else (base * Prefs.sizePct(ctx, k) / 100f * (if (big) 1.5f else 1f)).toInt().coerceAtLeast(24)
            val tv = TextView(ctx).apply {
                text = label(k)
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (big) 0x55FF9800 else if (Prefs.tapMode(ctx, k)) 0x554CAF50 else 0x552196F3)
                    setStroke(3, Color.WHITE)
                }
            }
            r.addView(tv, FrameLayout.LayoutParams(sz, sz))
            tv.x = p.first * w - sz / 2f
            tv.y = p.second * h - sz / 2f
        }
    }

    fun applyOpacity() { root?.alpha = Prefs.opacity(ctx) / 100f }

    fun hide() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
    }
}
