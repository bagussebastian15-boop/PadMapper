package com.padmapper

import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Mencatat error/crash terakhir ke penyimpanan supaya bisa dibaca di layar utama aplikasi. */
object CrashLog {
    private var installed = false

    fun install(c: Context) {
        if (installed) return
        installed = true
        val app = c.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            save(app, "CRASH", e)
            prev?.uncaughtException(t, e)
        }
    }

    fun save(c: Context, tag: String, e: Throwable) {
        try {
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            val time = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
            val txt = "$time [$tag] ${sw.toString().take(900)}"
            c.applicationContext.getSharedPreferences("crash", Context.MODE_PRIVATE)
                .edit().putString("last", txt).commit()
        } catch (_: Throwable) {}
    }

    fun last(c: Context): String =
        c.getSharedPreferences("crash", Context.MODE_PRIVATE).getString("last", "") ?: ""

    fun clear(c: Context) {
        c.getSharedPreferences("crash", Context.MODE_PRIVATE).edit().remove("last").apply()
    }
}
