package com.padmapper

import android.os.Build
import android.view.Gravity
import android.view.WindowManager

object Win {
    /**
     * Jendela overlay layar penuh yang BENAR-BENAR mulai dari pojok layar dan ukurannya sama dengan layar fisik
     * (termasuk area poni/notch). Dengan begitu posisi yang Anda lihat di editor = posisi sentuhan sebenarnya.
     */
    fun fullScreen(lp: WindowManager.LayoutParams) {
        lp.flags = lp.flags or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }
}
