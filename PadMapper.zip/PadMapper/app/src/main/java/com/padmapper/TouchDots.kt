package com.padmapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager

/**
 * Alat diagnosis: menggambar titik di posisi SEBENARNYA setiap jari virtual (LS merah, RS oranye, tombol biru)
 * dan nilai stik di pojok kiri atas. Rekam layar dengan ini aktif untuk melihat jari virtual mana yang bergeser.
 */
class TouchDots(private val svc: MapperService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: DotsView? = null

    private val tick = object : Runnable {
        override fun run() {
            view?.update(svc.touchSnapshot(), svc.stickDebug())
            handler.postDelayed(this, 40)
        }
    }

    fun show() {
        if (view != null) return
        val v = DotsView(svc)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        Win.fullScreen(lp)
        try {
            wm.addView(v, lp)
            view = v
            handler.post(tick)
        } catch (e: Throwable) { CrashLog.save(svc, "DOTS", e) }
    }

    fun hide() {
        handler.removeCallbacks(tick)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}

private class DotsView(ctx: Context) : View(ctx) {
    private var pts: List<Triple<String, Float, Float>> = emptyList()
    private var info = ""
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 30f; setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    fun update(p: List<Triple<String, Float, Float>>, i: String) {
        pts = p; info = i; invalidate()
    }

    override fun onDraw(c: Canvas) {
        c.drawText(info, 20f, 50f, txt)
        for ((id, x, y) in pts) {
            dot.color = when {
                id.startsWith("LS") -> 0xEEFF1744.toInt()
                id.startsWith("RS") -> 0xEEFF9100.toInt()
                else -> 0xEE00B0FF.toInt()
            }
            c.drawCircle(x, y, 22f, dot)
            c.drawText(id.take(6), x + 30f, y + 10f, txt)
        }
    }
}
