package com.padmapper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Layar kecil untuk memberi nama slot (dari gelembung maupun aplikasi).
 * Memakai keyboard bawaan Android: muncul saat kolom nama diketuk, hilang saat Selesai / Simpan / Batal.
 */
class SaveSlotActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var hint: LinearLayout
    private val imm by lazy { getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // Kartu di bawah layar ikut naik di atas keyboard
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        input = EditText(this).apply {
            hint = "Nama game, mis. Free Fire"
            setHintTextColor(0xFF999999.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI  // jangan layar penuh di landscape
            setSingleLine()
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO   // tanpa popup "IsiOtomatis"
            setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_UP) showIme()
                false
            }
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_DONE) { hideIme(); true } else false
            }
        }
        val simpan = pill("Simpan", 0xFF2E7D32.toInt()).apply { setOnClickListener { trySave() } }
        val batal = pill("Batal", 0xFF616161.toInt()).apply { setOnClickListener { hideIme(); finish() } }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(simpan, LinearLayout.LayoutParams(dp(84), dp(42)).apply { leftMargin = dp(8) })
            addView(batal, LinearLayout.LayoutParams(dp(72), dp(42)).apply { leftMargin = dp(6) })
        }

        // Muncul hanya bila keyboard sistem gagal tampil (umumnya karena gamepad terdeteksi sebagai keyboard fisik)
        hint = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            addView(TextView(this@SaveSlotActivity).apply {
                text = "Keyboard tidak muncul: gamepad terdeteksi sebagai keyboard fisik. " +
                    "Nyalakan \"Tampilkan keyboard virtual\" di pengaturan keyboard fisik."
                setTextColor(0xFFFFB74D.toInt()); textSize = 11f
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(pill("Buka pengaturan", 0xFF1565C0.toInt()).apply {
                setOnClickListener { openKeyboardSettings() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)).apply { leftMargin = dp(8) })
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFF222222.toInt())
            addView(TextView(this@SaveSlotActivity).apply {
                text = "Simpan slot — beri nama (wajib), mis. nama game."
                setTextColor(0xFFCCCCCC.toInt()); textSize = 12f
            })
            addView(top)
            addView(hint)
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(0x88000000.toInt())
            addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        })
        input.requestFocus()
    }

    private fun pill(t: String, color: Int) = Button(this).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE)
        transformationMethod = null
        minWidth = 0; minHeight = 0; setPadding(dp(8), 0, dp(8), 0)
        background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(color) }
    }

    private fun showIme() {
        input.requestFocus()
        input.post {
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            // Belum muncul? Coba paksa; kalau tetap tidak muncul, tampilkan petunjuk pengaturan.
            input.postDelayed({
                if (!imeVisible()) {
                    @Suppress("DEPRECATION") imm.showSoftInput(input, InputMethodManager.SHOW_FORCED)
                    input.postDelayed({ hint.visibility = if (imeVisible()) View.GONE else View.VISIBLE }, 500)
                } else hint.visibility = View.GONE
            }, 400)
        }
    }

    private fun hideIme() {
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
        hint.visibility = View.GONE
    }

    private fun imeVisible(): Boolean {
        val root = window.decorView
        if (Build.VERSION.SDK_INT >= 30) return root.rootWindowInsets?.isVisible(WindowInsets.Type.ime()) == true
        val r = Rect()
        root.getWindowVisibleDisplayFrame(r)
        return root.rootView.height - r.height() > root.rootView.height * 0.15f
    }

    private fun openKeyboardSettings() {
        try { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        catch (_: Exception) { Toast.makeText(this, "Buka Pengaturan > Bahasa & input > Keyboard fisik", Toast.LENGTH_LONG).show() }
    }

    override fun onPause() {
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        super.onPause()
    }

    private fun trySave() {
        val name = ProfileStore.clean(input.text.toString())
        if (name.isEmpty()) { input.error = "Nama tidak boleh kosong"; showIme(); return }
        hideIme()
        if (ProfileStore.exists(this, name)) {
            AlertDialog.Builder(this)
                .setTitle("Nama sudah ada")
                .setMessage("\"$name\" sudah tersimpan. Timpa dengan tata letak sekarang?")
                .setPositiveButton("Timpa") { _, _ -> done(name) }
                .setNegativeButton("Batal", null)
                .show()
        } else done(name)
    }

    private fun done(name: String) {
        ProfileStore.save(this, name)
        Toast.makeText(this, "Tersimpan: $name", Toast.LENGTH_SHORT).show()
        finish()
    }
}
