package com.padmapper

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

/**
 * Kotak dialog kecil untuk memberi nama slot, dipanggil dari gelembung di atas game
 * (jendela melayang tidak bisa menerima ketikan, jadi memakai activity transparan).
 */
class SaveSlotActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val input = EditText(this).apply {
            hint = "Nama game, mis. Free Fire"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSingleLine()
        }
        val box = LinearLayout(this).apply { setPadding(48, 16, 48, 0); addView(input) }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Simpan slot")
            .setMessage("Beri nama (wajib), misalnya nama game yang sedang dimainkan.")
            .setView(box)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .create()
        dlg.setOnDismissListener { finish() }
        dlg.setOnShowListener {
            dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
            input.requestFocus()
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = ProfileStore.clean(input.text.toString())
                if (name.isEmpty()) { input.error = "Nama tidak boleh kosong"; return@setOnClickListener }
                if (ProfileStore.exists(this, name)) {
                    AlertDialog.Builder(this)
                        .setTitle("Nama sudah ada")
                        .setMessage("\"$name\" sudah tersimpan. Timpa dengan tata letak sekarang?")
                        .setPositiveButton("Timpa") { _, _ -> done(name); dlg.dismiss() }
                        .setNegativeButton("Batal", null)
                        .show()
                } else { done(name); dlg.dismiss() }
            }
        }
        dlg.show()
    }

    private fun done(name: String) {
        ProfileStore.save(this, name)
        Toast.makeText(this, "Tersimpan: $name", Toast.LENGTH_SHORT).show()
    }
}
