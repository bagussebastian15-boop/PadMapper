package com.padmapper

import android.content.Context
import org.json.JSONObject

/**
 * Simpanan tata letak mapping per nama (misalnya nama game). Jumlah slot tidak dibatasi.
 * Yang disimpan: posisi tiap tombol (termasuk joystick & kamera), mode TAP, ukuran tombol,
 * serta pengaturan stik yang biasanya beda tiap game (jangkauan, deadzone, 8 arah, D-pad, kamera, kehalusan).
 * Tidak ikut disimpan: kalibrasi stik, transparansi, gelembung (itu milik perangkat, bukan milik game).
 */
object ProfileStore {
    private val PREFIXES = listOf("x_", "y_", "tap3_", "sz_")
    private val EXACT = setOf(
        "sr3", "dz", "cs", "stick8", "dpad_stick2", "cam_inv", "rs_on", "seg", "smooth", "smoothness"
    )

    const val MAX_NAME = 60

    private fun map(c: Context) = c.getSharedPreferences("map", Context.MODE_PRIVATE)
    private fun store(c: Context) = c.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    private fun isLayoutKey(k: String) = k in EXACT || PREFIXES.any { k.startsWith(it) }

    fun clean(name: String) = name.trim().replace(Regex("\\s+"), " ").take(MAX_NAME)

    fun names(c: Context): List<String> =
        store(c).all.keys.sortedBy { it.lowercase() }

    fun exists(c: Context, name: String) = store(c).contains(clean(name))

    /** Simpan tata letak yang sedang dipakai dengan nama [name] (menimpa bila nama sudah ada). */
    fun save(c: Context, name: String): Boolean {
        val n = clean(name)
        if (n.isEmpty()) return false
        val o = JSONObject()
        for ((k, v) in map(c).all) {
            if (!isLayoutKey(k) || v == null) continue
            val e = JSONObject()
            when (v) {
                is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                is Int -> { e.put("t", "i"); e.put("v", v) }
                is Boolean -> { e.put("t", "b"); e.put("v", v) }
                else -> continue
            }
            o.put(k, e)
        }
        store(c).edit().putString(n, o.toString()).apply()
        return true
    }

    /** Muat tata letak bernama [name] menggantikan tata letak sekarang. */
    fun load(c: Context, name: String): Boolean {
        val raw = store(c).getString(clean(name), null) ?: return false
        val o = try { JSONObject(raw) } catch (_: Exception) { return false }
        val ed = map(c).edit()
        // Hapus dulu semua kunci tata letak, supaya yang tidak ada di simpanan kembali ke bawaan
        map(c).all.keys.filter { isLayoutKey(it) }.forEach { ed.remove(it) }
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            if (!isLayoutKey(k)) continue
            val e = o.optJSONObject(k) ?: continue
            when (e.optString("t")) {
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "i" -> ed.putInt(k, e.getInt("v"))
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
            }
        }
        ed.apply()
        MapperService.instance?.reloadLayout()
        return true
    }

    fun delete(c: Context, name: String) { store(c).edit().remove(clean(name)).apply() }
}
