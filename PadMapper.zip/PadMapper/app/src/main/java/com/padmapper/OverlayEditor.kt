package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

/**
 * Overlay di atas game:
 *  - seret lingkaran = pindahkan posisi
 *  - ketuk lingkaran = pilih (garis kuning) + ganti mode: BIRU = ikuti lama tekan, HIJAU = tap sekali
 *  - slider bawah = ubah ukuran lingkaran yang dipilih
 */
class OverlayEditor(private val ctx: Context, private val onClosed: () -> Unit) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = ctx.resources.displayMetrics.density
    private val root = FrameLayout(ctx)
    private val markers = HashMap<Int, TextView>()
    private val tapModes = HashMap<Int, Boolean>()
    private val sizes = HashMap<Int, Int>()       // persen
    private val curSize = HashMap<Int, Int>()     // piksel
    private var selected: Int? = null
    private var baseSize = 0
    private var rootH = 0f
    private var closed = false
    private lateinit var sizeLabel: TextView
    private lateinit var sizeBar: SeekBar

    fun show() {
        root.setBackgroundColor(0x77000000)
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        Win.fullScreen(lp)
        try {
            wm.addView(root, lp)
            root.post { try { build() } catch (e: Throwable) { CrashLog.save(ctx, "EDITOR", e); close() } }
        } catch (e: Throwable) { CrashLog.save(ctx, "EDITOR", e); close() }
    }

    private fun label(k: Int) = when (k) {
        Prefs.LS -> "LS"
        Prefs.RS -> "RS"
        else -> KeyEvent.keyCodeToString(k)
            .removePrefix("KEYCODE_").removePrefix("BUTTON_").removePrefix("DPAD_").take(5)
    }

    // Untuk LS, "ukuran" = jangkauan stik (jari-jari, % tinggi layar): lingkaran digambar sebesar jangkauan sebenarnya
    private fun pxFor(k: Int, pct: Int) =
        if (k == Prefs.LS) (2f * pct / 100f * rootH).toInt().coerceAtLeast(24)
        else (baseSize * pct / 100f * (if (k < 0) 1.5f else 1f)).toInt().coerceAtLeast(24)

    private fun paint(tv: TextView, k: Int) {
        val tap = tapModes[k] == true
        tv.text = label(k) + if (tap) "\nTAP" else ""
        val color = when {
            k < 0 -> 0xCCFF9800.toInt()
            tap -> 0xCC4CAF50.toInt()
            else -> 0xCC2196F3.toInt()
        }
        (tv.background as GradientDrawable).setColor(color)
    }

    private fun highlight() {
        for ((k, v) in markers) {
            val sel = k == selected
            (v.background as GradientDrawable).setStroke(if (sel) 8 else 3, if (sel) 0xFFFFEB3B.toInt() else Color.WHITE)
        }
    }

    private fun select(k: Int) {
        selected = k
        highlight()
        val isLs = k == Prefs.LS
        val pct = sizes[k] ?: (if (isLs) 19 else 100)
        sizeLabel.text = if (isLs) "Jangkauan stik gerak: $pct% (samakan dengan lingkaran joystick game)"
                         else "Ukuran ${label(k)}: $pct%"
        sizeBar.isEnabled = true
        sizeBar.max = if (isLs) 37 else 200          // LS: 8..45%, lainnya: 50..250%
        sizeBar.progress = pct - (if (isLs) 8 else 50)
    }

    private fun resize(k: Int, pct: Int) {
        val v = markers[k] ?: return
        val old = curSize[k] ?: v.width
        val cx = v.x + old / 2f
        val cy = v.y + old / 2f
        val nsz = pxFor(k, pct)
        sizes[k] = pct
        curSize[k] = nsz
        v.layoutParams = FrameLayout.LayoutParams(nsz, nsz)
        v.x = cx - nsz / 2f
        v.y = cy - nsz / 2f
    }

    private fun build() {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        baseSize = (h * 0.11f).toInt()
        rootH = h

        for (k in Prefs.PRESET.keys) {
            val p = Prefs.get(ctx, k)!!
            tapModes[k] = Prefs.tapMode(ctx, k)
            sizes[k] = if (k == Prefs.LS) Math.round(Prefs.stickRadius(ctx) * 100) else Prefs.sizePct(ctx, k)
            val sz0 = pxFor(k, sizes[k]!!)
            curSize[k] = sz0
            val tv = TextView(ctx).apply {
                textSize = 11f
                gravity = Gravity.CENTER
                alpha = Prefs.opacity(ctx) / 100f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setStroke(3, Color.WHITE)
                }
            }
            paint(tv, k)
            root.addView(tv, FrameLayout.LayoutParams(sz0, sz0))
            tv.x = p.first * w - sz0 / 2f
            tv.y = p.second * h - sz0 / 2f
            markers[k] = tv

            var dx = 0f; var dy = 0f
            var downX = 0f; var downY = 0f
            var moved = false
            tv.setOnTouchListener { v, ev ->
                val sz = curSize[k] ?: sz0
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        select(k)
                        dx = v.x - ev.rawX; dy = v.y - ev.rawY
                        downX = ev.rawX; downY = ev.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(ev.rawX - downX) > 12 || abs(ev.rawY - downY) > 12) moved = true
                        if (moved) {
                            v.x = (ev.rawX + dx).coerceIn(0f, w - sz)
                            v.y = (ev.rawY + dy).coerceIn(0f, h - sz)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved && k >= 0) {
                            tapModes[k] = tapModes[k] != true
                            paint(tv, k)
                        }
                    }
                }
                true
            }
        }

        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(Button(ctx).apply { text = "SIMPAN"; setOnClickListener { save(w, h); close() } })
        bar.addView(Button(ctx).apply { text = "BATAL"; setOnClickListener { close() } })
        bar.addView(Button(ctx).apply {
            text = "RESET"
            setOnClickListener { Prefs.reset(ctx); close() }
        })
        root.addView(bar, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // Panel bawah: slider ukuran + petunjuk
        val bottom = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(16, 8, 16, 8)
        }
        sizeLabel = TextView(ctx).apply {
            text = "Ukuran: pilih lingkaran dulu"
            textSize = 12f
            setTextColor(Color.WHITE)
        }
        sizeBar = SeekBar(ctx).apply {
            max = 200                     // 50%..250%
            isEnabled = false
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val k = selected ?: return
                    if (!fromUser) return
                    val isLs = k == Prefs.LS
                    val pct = (if (isLs) 8 else 50) + p
                    sizeLabel.text = if (isLs) "Jangkauan stik gerak: $pct% (samakan dengan lingkaran joystick game)"
                                     else "Ukuran ${label(k)}: $pct%"
                    resize(k, pct)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bottom.addView(TextView(ctx).apply {
            text = "MODE EDITOR: gamepad DIJEDA (D-pad/stik tidak bergerak). Tekan SIMPAN atau BATAL (atau SELECT + START) untuk kembali bermain."
            textSize = 12f
            setTextColor(0xFFFFB74D.toInt())
        })
        bottom.addView(sizeLabel)
        bottom.addView(sizeBar, LinearLayout.LayoutParams((280 * d).toInt(), WRAP_CONTENT))
        bottom.addView(TextView(ctx).apply {
            text = "Seret = pindah | Ketuk = pilih & ganti mode: BIRU ikuti lama tekan, HIJAU tap sekali"
            textSize = 11f
            setTextColor(Color.WHITE)
        })
        root.addView(bottom, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    }

    private fun save(w: Float, h: Float) {
        for ((k, v) in markers) {
            val sz = curSize[k] ?: v.width
            val cx = (v.x + sz / 2f) / w
            val cy = (v.y + sz / 2f) / h
            Prefs.set(ctx, k, cx, cy)
            if (k == Prefs.LS) Prefs.setStickRadius(ctx, sizes[k] ?: 19)
            else Prefs.setSizePct(ctx, k, sizes[k] ?: 100)
            if (k >= 0) Prefs.setTapMode(ctx, k, tapModes[k] == true)
        }
    }

    fun close() {
        if (closed) return
        closed = true
        try { wm.removeView(root) } catch (_: Exception) {}
        onClosed()
    }
}
