package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Layar overlay di atas game: geser lingkaran ke posisi tombol di game, lalu SIMPAN. */
class OverlayEditor(private val ctx: Context, private val onClosed: () -> Unit) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = FrameLayout(ctx)
    private val markers = HashMap<Int, TextView>()
    private var size = 0
    private var closed = false

    fun show() {
        root.setBackgroundColor(0x77000000)
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        root.post { build() }
    }

    private fun label(k: Int) = when (k) {
        Prefs.LS -> "LS"
        Prefs.RS -> "RS"
        else -> KeyEvent.keyCodeToString(k)
            .removePrefix("KEYCODE_").removePrefix("BUTTON_").removePrefix("DPAD_").take(5)
    }

    private fun build() {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        size = (h * 0.11f).toInt()

        for (k in Prefs.PRESET.keys) {
            val p = Prefs.get(ctx, k)!!
            val big = k < 0
            val sz = if (big) (size * 1.5f).toInt() else size
            val tv = TextView(ctx).apply {
                text = label(k)
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (big) 0xCCFF9800.toInt() else 0xCC2196F3.toInt())
                    setStroke(3, Color.WHITE)
                }
            }
            root.addView(tv, FrameLayout.LayoutParams(sz, sz))
            tv.x = p.first * w - sz / 2f
            tv.y = p.second * h - sz / 2f
            var dx = 0f
            var dy = 0f
            tv.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dx = v.x - ev.rawX; dy = v.y - ev.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        v.x = (ev.rawX + dx).coerceIn(0f, w - sz)
                        v.y = (ev.rawY + dy).coerceIn(0f, h - sz)
                    }
                }
                true
            }
            markers[k] = tv
        }

        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(Button(ctx).apply { text = "SIMPAN"; setOnClickListener { save(w, h); close() } })
        bar.addView(Button(ctx).apply { text = "BATAL"; setOnClickListener { close() } })
        bar.addView(Button(ctx).apply {
            text = "RESET"
            setOnClickListener { Prefs.reset(ctx); close() }
        })
        root.addView(bar, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
    }

    private fun save(w: Float, h: Float) {
        for ((k, v) in markers) {
            val cx = (v.x + v.width / 2f) / w
            val cy = (v.y + v.height / 2f) / h
            Prefs.set(ctx, k, cx, cy)
        }
    }

    fun close() {
        if (closed) return
        closed = true
        try { wm.removeView(root) } catch (_: Exception) {}
        onClosed()
    }
}
