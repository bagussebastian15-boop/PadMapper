package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Overlay di atas game:
 *  - seret lingkaran = pindahkan posisi
 *  - ketuk lingkaran = ganti mode: BIRU = TAHAN (tembak/gerak), HIJAU = TAP (pause/menu)
 */
class OverlayEditor(private val ctx: Context, private val onClosed: () -> Unit) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = FrameLayout(ctx)
    private val markers = HashMap<Int, TextView>()
    private val tapModes = HashMap<Int, Boolean>()
    private var closed = false

    fun show() {
        root.setBackgroundColor(0x77000000)
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        root.post { build() }
    }

    private fun label(k: Int) = when (k) {
        Prefs.LS -> "LS"
        Prefs.RS -> "RS"
        else -> KeyEvent.keyCodeToString(k)
            .removePrefix("KEYCODE_").removePrefix("BUTTON_").removePrefix("DPAD_").take(5)
    }

    private fun paint(tv: TextView, k: Int) {
        val tap = tapModes[k] == true
        tv.text = label(k) + if (tap) "\nTAP" else ""
        val color = when {
            k < 0 -> 0xCCFF9800.toInt()
            tap -> 0xCC4CAF50.toInt()
            else -> 0xCC2196F3.toInt()
        }
        (tv.background as GradientDrawable).setColor(color)
    }

    private fun build() {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val size = (h * 0.11f).toInt()

        for (k in Prefs.PRESET.keys) {
            val p = Prefs.get(ctx, k)!!
            val big = k < 0
            val sz = if (big) (size * 1.5f).toInt() else size
            tapModes[k] = Prefs.tapMode(ctx, k)
            val tv = TextView(ctx).apply {
                textSize = 11f
                gravity = Gravity.CENTER
                alpha = Prefs.opacity(ctx) / 100f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setStroke(3, Color.WHITE)
                }
            }
            paint(tv, k)
            root.addView(tv, FrameLayout.LayoutParams(sz, sz))
            tv.x = p.first * w - sz / 2f
            tv.y = p.second * h - sz / 2f

            var dx = 0f; var dy = 0f
            var downX = 0f; var downY = 0f
            var moved = false
            tv.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dx = v.x - ev.rawX; dy = v.y - ev.rawY
                        downX = ev.rawX; downY = ev.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(ev.rawX - downX) > 12 || abs(ev.rawY - downY) > 12) moved = true
                        if (moved) {
                            v.x = (ev.rawX + dx).coerceIn(0f, w - sz)
                            v.y = (ev.rawY + dy).coerceIn(0f, h - sz)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved && k >= 0) {
                            tapModes[k] = tapModes[k] != true
                            paint(tv, k)
                        }
                    }
                }
                true
            }
            markers[k] = tv
        }

        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(Button(ctx).apply { text = "SIMPAN"; setOnClickListener { save(w, h); close() } })
        bar.addView(Button(ctx).apply { text = "BATAL"; setOnClickListener { close() } })
        bar.addView(Button(ctx).apply {
            text = "RESET"
            setOnClickListener { Prefs.reset(ctx); close() }
        })
        root.addView(bar, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        root.addView(TextView(ctx).apply {
            text = "Seret = pindah  |  Ketuk lingkaran = ganti mode: BIRU tahan, HIJAU tap (untuk pause/menu)"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            setPadding(16, 8, 16, 8)
        }, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    }

    private fun save(w: Float, h: Float) {
        for ((k, v) in markers) {
            val cx = (v.x + v.width / 2f) / w
            val cy = (v.y + v.height / 2f) / h
            Prefs.set(ctx, k, cx, cy)
            if (k >= 0) Prefs.setTapMode(ctx, k, tapModes[k] == true)
        }
    }

    fun close() {
        if (closed) return
        closed = true
        try { wm.removeView(root) } catch (_: Exception) {}
        onClosed()
    }
}
