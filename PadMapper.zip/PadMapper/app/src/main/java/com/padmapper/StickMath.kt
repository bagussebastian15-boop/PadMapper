package com.padmapper

import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.pow

/** Matematika stik analog (murni Kotlin, tanpa Android) supaya mudah diuji. */
object StickMath {
    /** Ambang minimum agar deadzone 0% tidak membuat stik "menyentuh" terus karena noise. */
    const val MIN_ENGAGE = 0.02f

    /** Histeresis: sekali aktif, stik baru dianggap lepas di bawah 60% ambang (tidak putus-nyambung di tepi). */
    fun engaged(mag: Float, dz: Float, wasOn: Boolean): Boolean {
        val t = maxOf(dz, MIN_ENGAGE)
        return if (wasOn) mag > t * 0.6f else mag > t
    }

    /**
     * Deadzone radial + batas luar + skala ulang:
     *  - magnitudo <= dz            -> 0
     *  - dz .. outer                -> naik mulus 0..1 (tidak ada lompatan saat stik mulai bergerak)
     *  - >= outer                   -> 1 (untuk stik yang tidak pernah mencapai 100%)
     * curve > 1 = kontrol lebih halus di defleksi kecil.
     */
    fun shape(ax: Float, ay: Float, dz: Float, outer: Float, curve: Float): Pair<Float, Float> {
        val mag = hypot(ax, ay)
        val lo = dz.coerceIn(0f, 0.9f)
        val hi = outer.coerceIn(lo + 0.05f, 1f)
        if (mag <= lo || mag == 0f) return 0f to 0f
        val e = ((minOf(mag, hi) - lo) / (hi - lo)).pow(curve)
        return ax / mag * e to ay / mag * e
    }

    /** Pilih pasangan sumbu stik kanan: 1 = Z/RZ, 2 = RX/RY, selain itu otomatis. */
    fun pickRight(mode: Int, z: Float, rz: Float, rx: Float, ry: Float): Pair<Float, Float> = when (mode) {
        1 -> z to rz
        2 -> rx to ry
        else -> if (hypot(z, rz) >= hypot(rx, ry)) z to rz else rx to ry
    }

    /** Saran deadzone (persen) dari drift maksimum saat stik dilepas: drift + sedikit margin. */
    fun suggestPct(restMag: Float): Int = ceil((restMag + 0.03f) * 100f).toInt().coerceIn(3, 50)
}
