package com.padmapper

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Beranda: hanya judul + tombol aktifkan aksesibilitas. Semua pengaturan ada di panel gelembung (tap gelembung "PAD"). */
class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        CrashLog.install(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "PADMAPPER BY BAGUS SEBASTIAN"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 48)
        })
        root.addView(Button(this).apply {
            text = "Aktifkan Layanan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "Catatan: tidak semua game mendukung PadMapper, terutama di Android di bawah 14."
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 0)
        })
        setContentView(root)
    }
}
