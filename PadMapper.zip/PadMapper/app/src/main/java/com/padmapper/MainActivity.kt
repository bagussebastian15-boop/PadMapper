package com.padmapper

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

class MainActivity : Activity() {
    private lateinit var test: TextView
    private lateinit var preview: StickPreview
    private val ui = Handler(Looper.getMainLooper())
    private val axesList = intArrayOf(MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ, MotionEvent.AXIS_RX, MotionEvent.AXIS_RY)
    private val amin = FloatArray(4)
    private val amax = FloatArray(4)
    private var calibrating = false

    // Deteksi deadzone otomatis: ukur drift stik saat dilepas
    private var measuring = false
    private var measureFrom = 0L
    private var restL = 0f
    private var restR = 0f
    private var restSamples = 0
    private lateinit var setDzLeft: (Int) -> Unit
    private lateinit var setDzRight: (Int) -> Unit

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startCalibration() {
        for (i in 0..3) { amin[i] = Float.MAX_VALUE; amax[i] = -Float.MAX_VALUE }
        calibrating = true
        test.text = "KALIBRASI: putar stik KANAN penuh ke semua arah selama 5 detik..."
        ui.postDelayed({ finishCalibration() }, 5000)
    }

    private fun finishCalibration() {
        calibrating = false
        fun range(i: Int) = if (amax[i] >= amin[i]) amax[i] - amin[i] else 0f
        val a = minOf(range(0), range(1))   // Z/RZ
        val b = minOf(range(2), range(3))   // RX/RY
        val mode = when { a < 0.5f && b < 0.5f -> 0; a >= b -> 1; else -> 2 }
        Prefs.setRsAxes(this, mode)
        val msg = when (mode) {
            1 -> "Stik kanan = sumbu Z/RZ"
            2 -> "Stik kanan = sumbu RX/RY"
            else -> "Stik kanan tidak terdeteksi, pakai otomatis. Coba ulang dan putar stik lebih penuh."
        }
        test.text = "TES GAMEPAD\n$msg"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    /** 4 detik: 1 detik pertama diabaikan (waktu melepas stik), 3 detik berikutnya diukur. */
    private fun startMeasure() {
        restL = 0f; restR = 0f; restSamples = 0
        measureFrom = System.currentTimeMillis() + 1000
        measuring = true
        test.text = "UKUR DRIFT: gerakkan stik sedikit, lalu LEPAS dan biarkan diam selama 4 detik..."
        ui.postDelayed({ finishMeasure() }, 4000)
    }

    private fun finishMeasure() {
        measuring = false
        if (restSamples == 0) {
            val msg = "Tidak ada drift terbaca (stik bersih) atau gamepad belum mengirim data. Deadzone tidak diubah."
            test.text = "TES GAMEPAD\n$msg"
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            return
        }
        val l = StickMath.suggestPct(restL)
        val r = StickMath.suggestPct(restR)
        setDzLeft(l); setDzRight(r)
        val msg = "Drift kiri ${Math.round(restL * 100)}%, kanan ${Math.round(restR * 100)}% → deadzone diatur $l% / $r%"
        test.text = "TES GAMEPAD\n$msg"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        // Dibungkus ScrollView supaya semua pengaturan (slider di bawah) bisa dijangkau
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })

        root.addView(TextView(this).apply {
            text = "PadMapper\nEditor posisi: SELECT + START di gamepad, atau tombol 3."
            textSize = 15f
        })
        root.addView(Button(this).apply {
            text = "1. Aktifkan Layanan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. AUTO MAP / RESET (1 klik)"
            setOnClickListener {
                Prefs.reset(this@MainActivity)
                Toast.makeText(this@MainActivity, "Mapping default aktif! Buka game Anda.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "3. Edit posisi (muncul 6 detik, buka game dulu)"
            setOnClickListener {
                val s = MapperService.instance
                if (s == null) Toast.makeText(this@MainActivity, "Aktifkan layanan dulu.", Toast.LENGTH_LONG).show()
                else { s.showEditorDelayed(); Toast.makeText(this@MainActivity, "Buka game sekarang...", Toast.LENGTH_LONG).show() }
            }
        })
        if (Build.VERSION.SDK_INT < 34) {
            root.addView(Switch(this).apply {
                text = "Mode stik analog (Android < 14)\nGame bisa kehilangan fokus; matikan bila game terpause."
                isChecked = Prefs.stickMode(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setStickMode(this@MainActivity, on)
                    MapperService.instance?.setStickMode(on)
                }
            })
        }
        root.addView(Switch(this).apply {
            text = "Gelembung kontrol di atas game"
            isChecked = Prefs.bubbleOn(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                val s = MapperService.instance
                if (s != null) s.enableBubble(on) else Prefs.setBubbleOn(this@MainActivity, on)
            }
        })
        addSlider(root, "Transparansi", 20, 100, Prefs.opacity(this)) {
            Prefs.setOpacity(this, it)
            MapperService.instance?.applyOpacity()
        }

        // ---------- Stik analog ----------
        root.addView(TextView(this).apply {
            text = "\nSTIK ANALOG"
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "Kalibrasi stik kanan (5 detik)"
            setOnClickListener { startCalibration() }
        })
        root.addView(Switch(this).apply {
            text = "Balik arah vertikal kamera"
            isChecked = Prefs.camInvert(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setCamInvert(this@MainActivity, on) }
        })
        test = TextView(this).apply { text = "\nTES GAMEPAD: tekan tombol / gerakkan stik di layar ini."; textSize = 14f }
        root.addView(test)
        preview = StickPreview(this)
        root.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        setDzLeft = addSlider(root, "Deadzone stik kiri (gerak)", 0, 50, Math.round(Prefs.deadzoneLeft(this) * 100)) {
            Prefs.setDeadzoneLeft(this, it); preview.invalidate()
        }
        setDzRight = addSlider(root, "Deadzone stik kanan (kamera)", 0, 50, Math.round(Prefs.deadzoneRight(this) * 100)) {
            Prefs.setDeadzoneRight(this, it); preview.invalidate()
        }
        root.addView(Button(this).apply {
            text = "Deteksi deadzone otomatis (lepas stik 4 detik)"
            setOnClickListener { startMeasure() }
        })
        addSlider(root, "Batas luar (dianggap penuh)", 70, 100, Math.round(Prefs.outerLimit(this) * 100)) {
            Prefs.setOuterLimit(this, it); preview.invalidate()
        }
        addSlider(root, "Jangkauan stik gerak", 5, 25, Math.round(Prefs.stickRadius(this) * 100)) { Prefs.setStickRadius(this, it) }
        addSlider(root, "Kehalusan sentuhan (interval, kecil = lebih halus)", 10, 80, Prefs.segMs(this), " ms") { Prefs.setSegMs(this, it) }
        addSlider(root, "Kecepatan kamera", 50, 300, Math.round(Prefs.camSpeed(this) * 100)) { Prefs.setCamSpeed(this, it) }
    }

    /** Menambah label + slider; mengembalikan fungsi untuk mengubah nilainya dari kode. */
    private fun addSlider(root: LinearLayout, title: String, lo: Int, hi: Int, cur: Int, unit: String = "%", onChange: (Int) -> Unit): (Int) -> Unit {
        val lbl = TextView(this).apply { text = "$title: $cur$unit" }
        root.addView(lbl)
        val bar = SeekBar(this).apply {
            this.max = hi - lo
            progress = (cur - lo).coerceIn(0, hi - lo)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    lbl.text = "$title: ${lo + p}$unit"
                    onChange(lo + p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(bar)
        return { v -> bar.progress = (v - lo).coerceIn(0, hi - lo) }
    }

    // Layar tes: menampilkan kode tombol & nilai sumbu supaya gamepad "universal" bisa dicek.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN)
            test.text = "TES GAMEPAD\nTombol: ${KeyEvent.keyCodeToString(e.keyCode)} (${e.keyCode})"
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.actionMasked == MotionEvent.ACTION_MOVE) {
            if (calibrating) {
                for (i in 0..3) {
                    val x = e.getAxisValue(axesList[i])
                    if (x < amin[i]) amin[i] = x
                    if (x > amax[i]) amax[i] = x
                }
                return true
            }
            val lx = e.getAxisValue(MotionEvent.AXIS_X); val ly = e.getAxisValue(MotionEvent.AXIS_Y)
            val (rx, ry) = StickMath.pickRight(
                Prefs.rsAxes(this),
                e.getAxisValue(MotionEvent.AXIS_Z), e.getAxisValue(MotionEvent.AXIS_RZ),
                e.getAxisValue(MotionEvent.AXIS_RX), e.getAxisValue(MotionEvent.AXIS_RY)
            )
            preview.lx = lx; preview.ly = ly; preview.rx = rx; preview.ry = ry
            preview.invalidate()
            if (measuring) {
                if (System.currentTimeMillis() >= measureFrom) {
                    restL = maxOf(restL, hypot(lx, ly))
                    restR = maxOf(restR, hypot(rx, ry))
                    restSamples++
                }
                return true
            }
            fun v(a: Int) = String.format("%.2f", e.getAxisValue(a))
            test.text = "TES GAMEPAD\nX=${v(MotionEvent.AXIS_X)} Y=${v(MotionEvent.AXIS_Y)}\n" +
                "Z=${v(MotionEvent.AXIS_Z)} RZ=${v(MotionEvent.AXIS_RZ)}\n" +
                "RX=${v(MotionEvent.AXIS_RX)} RY=${v(MotionEvent.AXIS_RY)}\n" +
                "HAT=${v(MotionEvent.AXIS_HAT_X)},${v(MotionEvent.AXIS_HAT_Y)}"
            return true
        }
        return super.onGenericMotionEvent(e)
    }
}
