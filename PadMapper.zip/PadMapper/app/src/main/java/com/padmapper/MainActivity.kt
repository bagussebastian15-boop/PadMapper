package com.padmapper

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Button
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var test: TextView
    private val axesList = intArrayOf(MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ, MotionEvent.AXIS_RX, MotionEvent.AXIS_RY)
    private val amin = FloatArray(4)
    private val amax = FloatArray(4)
    private var calibrating = false

    // Kalibrasi pusat analog: nilai terakhir tiap sumbu setelah stik dilepas = titik pusat sebenarnya
    private var centering = false
    private val lastVal = HashMap<Int, Float>()

    private fun startCenterCalibration() {
        lastVal.clear()
        centering = true
        test.text = "KALIBRASI PUSAT: gerakkan kedua stik sedikit, LEPAS, lalu jangan disentuh selama 3 detik..."
        Handler(Looper.getMainLooper()).postDelayed({ finishCenterCalibration() }, 3000)
    }

    private fun finishCenterCalibration() {
        centering = false
        if (lastVal.isEmpty()) {
            test.text = "TES GAMEPAD\nTidak ada gerakan stik terbaca. Coba ulang: gerakkan stik sedikit lalu lepas."
            return
        }
        // Tolak hasil yang tidak masuk akal (stik masih ditahan / bukan posisi pusat)
        val ok = lastVal.filter { kotlin.math.abs(it.value) <= 0.35f }
        if (ok.size < lastVal.size) {
            test.text = "TES GAMEPAD\nKalibrasi dibatalkan: ada stik yang masih ditahan. Lepas kedua stik lalu ulangi."
            return
        }
        Prefs.setCenterOffsets(this, ok)
        val msg = "Pusat analog tersimpan"
        test.text = "TES GAMEPAD\n$msg"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun startCalibration() {
        for (i in 0..3) { amin[i] = Float.MAX_VALUE; amax[i] = -Float.MAX_VALUE }
        calibrating = true
        test.text = "KALIBRASI: putar stik KANAN penuh ke semua arah selama 5 detik..."
        Handler(Looper.getMainLooper()).postDelayed({ finishCalibration() }, 5000)
    }

    private fun finishCalibration() {
        calibrating = false
        fun range(i: Int) = if (amax[i] >= amin[i]) amax[i] - amin[i] else 0f
        val a = minOf(range(0), range(1))   // Z/RZ
        val b = minOf(range(2), range(3))   // RX/RY
        val mode = when { a < 0.5f && b < 0.5f -> 0; a >= b -> 1; else -> 2 }
        Prefs.setRsAxes(this, mode)
        val msg = when (mode) {
            1 -> "Stik kanan = sumbu Z/RZ"
            2 -> "Stik kanan = sumbu RX/RY"
            else -> "Stik kanan tidak terdeteksi, pakai otomatis. Coba ulang dan putar stik lebih penuh."
        }
        test.text = "TES GAMEPAD\n$msg"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 48, 48, 96)
        }
        root.addView(TextView(this).apply {
            text = "PadMapper\nEditor posisi: SELECT + START di gamepad, atau tombol 3."
            textSize = 15f
        })
        root.addView(Button(this).apply {
            text = "1. Aktifkan Layanan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. AUTO MAP / RESET (1 klik)"
            setOnClickListener {
                Prefs.reset(this@MainActivity)
                Toast.makeText(this@MainActivity, "Mapping default aktif! Buka game Anda.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "3. Edit posisi (muncul 6 detik, buka game dulu)"
            setOnClickListener {
                val s = MapperService.instance
                if (s == null) Toast.makeText(this@MainActivity, "Aktifkan layanan dulu.", Toast.LENGTH_LONG).show()
                else { s.showEditorDelayed(); Toast.makeText(this@MainActivity, "Buka game sekarang...", Toast.LENGTH_LONG).show() }
            }
        })
        if (Build.VERSION.SDK_INT < 34) {
            root.addView(Switch(this).apply {
                text = "Mode stik analog (Android < 14)\nGame bisa kehilangan fokus; matikan bila game terpause."
                isChecked = Prefs.stickMode(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setStickMode(this@MainActivity, on)
                    MapperService.instance?.setStickMode(on)
                }
            })
        }
        root.addView(Switch(this).apply {
            text = "Gelembung kontrol di atas game"
            isChecked = Prefs.bubbleOn(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                val s = MapperService.instance
                if (s != null) s.enableBubble(on) else Prefs.setBubbleOn(this@MainActivity, on)
            }
        })
        val opLabel = TextView(this).apply { text = "Transparansi: ${Prefs.opacity(this@MainActivity)}%" }
        root.addView(opLabel)
        root.addView(SeekBar(this).apply {
            max = 80
            progress = Prefs.opacity(this@MainActivity) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Prefs.setOpacity(this@MainActivity, 20 + p)
                    opLabel.text = "Transparansi: ${20 + p}%"
                    MapperService.instance?.applyOpacity()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(Button(this).apply {
            text = "Kalibrasi stik kanan (5 detik)"
            setOnClickListener { startCalibration() }
        })
        root.addView(Switch(this).apply {
            text = "Balik arah vertikal kamera"
            isChecked = Prefs.camInvert(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setCamInvert(this@MainActivity, on) }
        })
        addSlider(root, "Jangkauan stik gerak", 5, 25, Math.round(Prefs.stickRadius(this) * 100)) { Prefs.setStickRadius(this, it) }
        addSlider(root, "Kecepatan kamera", 50, 300, Math.round(Prefs.camSpeed(this) * 100)) { Prefs.setCamSpeed(this, it) }

        root.addView(TextView(this).apply { text = "\nANALOG LANJUTAN"; textSize = 15f })
        addSlider(root, "Deadzone stik kiri (gerak)", 0, 40, Math.round(Prefs.deadzoneL(this) * 100)) { Prefs.setDeadzoneL(this, it) }
        addSlider(root, "Deadzone stik kanan (kamera)", 0, 40, Math.round(Prefs.deadzoneR(this) * 100)) { Prefs.setDeadzoneR(this, it) }
        addSlider(root, "Deadzone luar (anggap penuh)", 0, 15, Math.round(Prefs.outerZone(this) * 100)) { Prefs.setOuterZone(this, it) }
        root.addView(Button(this).apply {
            text = "Kalibrasi pusat analog (3 detik)"
            setOnClickListener { startCenterCalibration() }
        })
        root.addView(Button(this).apply {
            text = "Reset pusat analog"
            setOnClickListener {
                Prefs.resetCenter(this@MainActivity)
                Toast.makeText(this@MainActivity, "Pusat analog dikembalikan ke 0", Toast.LENGTH_SHORT).show()
            }
        })
        addSlider(root, "Sensitivitas sumbu X", 50, 200, Math.round(Prefs.sensX(this) * 100)) { Prefs.setSensX(this, it) }
        addSlider(root, "Sensitivitas sumbu Y", 50, 200, Math.round(Prefs.sensY(this) * 100)) { Prefs.setSensY(this, it) }
        addSlider(root, "Rentang stik gerak: KIRI", 50, 150, Math.round(Prefs.range(this, 0) * 100)) { Prefs.setRange(this, 0, it) }
        addSlider(root, "Rentang stik gerak: KANAN", 50, 150, Math.round(Prefs.range(this, 1) * 100)) { Prefs.setRange(this, 1, it) }
        addSlider(root, "Rentang stik gerak: ATAS", 50, 150, Math.round(Prefs.range(this, 2) * 100)) { Prefs.setRange(this, 2, it) }
        addSlider(root, "Rentang stik gerak: BAWAH", 50, 150, Math.round(Prefs.range(this, 3) * 100)) { Prefs.setRange(this, 3, it) }
        addSlider(root, "Kunci arah saat ditahan lurus (0 = mati)", 0, 30, Math.round(Prefs.axisLock(this) * 100)) { Prefs.setAxisLock(this, it) }
        root.addView(Button(this).apply {
            text = "Reset setelan analog lanjutan"
            setOnClickListener {
                Prefs.resetAnalog(this@MainActivity)
                recreate()
            }
        })
        test = TextView(this).apply { text = "\nTES GAMEPAD: tekan tombol / gerakkan stik di layar ini."; textSize = 14f }
        root.addView(test)
        // Layar bisa digulir supaya semua pengaturan terjangkau
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
    }

    private fun addSlider(root: LinearLayout, title: String, lo: Int, hi: Int, cur: Int, onChange: (Int) -> Unit) {
        val lbl = TextView(this).apply { text = "$title: $cur%" }
        root.addView(lbl)
        root.addView(SeekBar(this).apply {
            this.max = hi - lo
            progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    lbl.text = "$title: ${lo + p}%"
                    onChange(lo + p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    // Layar tes: menampilkan kode tombol & nilai sumbu supaya gamepad "universal" bisa dicek.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN)
            test.text = "TES GAMEPAD\nTombol: ${KeyEvent.keyCodeToString(e.keyCode)} (${e.keyCode})"
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.actionMasked == MotionEvent.ACTION_MOVE) {
            if (centering) {
                for (a in Prefs.calibAxes) lastVal[a] = e.getAxisValue(a)
                return true
            }
            if (calibrating) {
                for (i in 0..3) {
                    val x = e.getAxisValue(axesList[i])
                    if (x < amin[i]) amin[i] = x
                    if (x > amax[i]) amax[i] = x
                }
                return true
            }
            fun v(a: Int) = String.format("%.2f", e.getAxisValue(a))
            test.text = "TES GAMEPAD\nX=${v(MotionEvent.AXIS_X)} Y=${v(MotionEvent.AXIS_Y)}\n" +
                "Z=${v(MotionEvent.AXIS_Z)} RZ=${v(MotionEvent.AXIS_RZ)}\n" +
                "RX=${v(MotionEvent.AXIS_RX)} RY=${v(MotionEvent.AXIS_RY)}\n" +
                "HAT=${v(MotionEvent.AXIS_HAT_X)},${v(MotionEvent.AXIS_HAT_Y)}"
            return true
        }
        return super.onGenericMotionEvent(e)
    }
}
