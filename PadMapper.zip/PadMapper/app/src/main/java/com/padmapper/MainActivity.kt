package com.padmapper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var test: TextView
    private lateinit var profileBox: LinearLayout
    private val axesList = intArrayOf(MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ, MotionEvent.AXIS_RX, MotionEvent.AXIS_RY)
    private val amin = FloatArray(4)
    private val amax = FloatArray(4)
    private var calibrating = false
    private val lastV = FloatArray(6)   // nilai terakhir: X, Y, Z, RZ, RX, RY (stik dilepas = titik tengah)

    private fun startCalibration() {
        for (i in 0..3) { amin[i] = Float.MAX_VALUE; amax[i] = -Float.MAX_VALUE }
        calibrating = true
        test.text = "KALIBRASI 7 detik: putar KEDUA stik penuh ke semua arah, lalu LEPAS dan diamkan."
        Handler(Looper.getMainLooper()).postDelayed({ finishCalibration() }, 7000)
    }

    private fun finishCalibration() {
        calibrating = false
        fun range(i: Int) = if (amax[i] >= amin[i]) amax[i] - amin[i] else 0f
        val a = minOf(range(0), range(1))   // Z/RZ
        val b = minOf(range(2), range(3))   // RX/RY
        val mode = when { a < 0.5f && b < 0.5f -> 0; a >= b -> 1; else -> 2 }
        Prefs.setRsAxes(this, mode)
        var msg = when (mode) {
            1 -> "Stik kanan = sumbu Z/RZ"
            2 -> "Stik kanan = sumbu RX/RY"
            else -> "Stik kanan tidak terdeteksi, pakai Z/RZ."
        }
        // Titik tengah: nilai terakhir saat stik dilepas
        if (abs(lastV[0]) < 0.6f && abs(lastV[1]) < 0.6f) {
            Prefs.setLsCenter(this, lastV[0], lastV[1])
            msg += String.format("\nTengah stik kiri: %.2f, %.2f", lastV[0], lastV[1])
        }
        if (mode != 0) {
            val cx = if (mode == 2) lastV[4] else lastV[2]
            val cy = if (mode == 2) lastV[5] else lastV[3]
            if (abs(cx) < 0.6f && abs(cy) < 0.6f) Prefs.setRsCenter(this, cx, cy)
        }
        test.text = "TES GAMEPAD\n$msg"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()
        if (::profileBox.isInitialized) refreshProfiles()   // daftar simpanan diperbarui setelah kembali dari layar simpan
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        CrashLog.install(this)
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "PadMapper v$ver\nEditor posisi: SELECT + START di gamepad, atau tombol 3."
            textSize = 15f
        })
        val lastErr = CrashLog.last(this)
        if (lastErr.isNotEmpty()) {
            root.addView(TextView(this).apply {
                text = "LOG ERROR TERAKHIR (kirim ke saya):\n$lastErr"
                textSize = 10f
                setTextIsSelectable(true)
            })
            root.addView(Button(this).apply {
                text = "Hapus log"
                setOnClickListener { CrashLog.clear(this@MainActivity); text = "Log dihapus" }
            })
        }
        root.addView(Button(this).apply {
            text = "1. Aktifkan Layanan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. AUTO MAP / RESET (1 klik)"
            setOnClickListener {
                Prefs.reset(this@MainActivity)
                Toast.makeText(this@MainActivity, "Mapping default aktif! Buka game Anda.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "3. Edit posisi (muncul 6 detik, buka game dulu)"
            setOnClickListener {
                val s = MapperService.instance
                if (s == null) Toast.makeText(this@MainActivity, "Aktifkan layanan dulu.", Toast.LENGTH_LONG).show()
                else { s.showEditorDelayed(); Toast.makeText(this@MainActivity, "Buka game sekarang...", Toast.LENGTH_LONG).show() }
            }
        })
        root.addView(TextView(this).apply {
            text = "\nTATA LETAK TERSIMPAN (per game)"
            textSize = 15f
        })
        root.addView(Button(this).apply {
            text = "Simpan tata letak sekarang..."
            setOnClickListener { startActivity(Intent(this@MainActivity, SaveSlotActivity::class.java)) }
        })
        profileBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(profileBox)
        refreshProfiles()
        if (Build.VERSION.SDK_INT < 34) {
            root.addView(Switch(this).apply {
                text = "Mode stik analog (Android < 14)\nGame bisa kehilangan fokus; matikan bila game terpause."
                isChecked = Prefs.stickMode(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setStickMode(this@MainActivity, on)
                    MapperService.instance?.setStickMode(on)
                }
            })
        }
        root.addView(Switch(this).apply {
            text = "Gelembung kontrol di atas game"
            isChecked = Prefs.bubbleOn(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                val s = MapperService.instance
                if (s != null) s.enableBubble(on) else Prefs.setBubbleOn(this@MainActivity, on)
            }
        })
        val opLabel = TextView(this).apply { text = "Transparansi: ${Prefs.opacity(this@MainActivity)}%" }
        root.addView(opLabel)
        root.addView(SeekBar(this).apply {
            max = 80
            progress = Prefs.opacity(this@MainActivity) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Prefs.setOpacity(this@MainActivity, 20 + p)
                    opLabel.text = "Transparansi: ${20 + p}%"
                    MapperService.instance?.applyOpacity()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(Button(this).apply {
            text = "Kalibrasi stik (7 detik)"
            setOnClickListener { startCalibration() }
        })
        root.addView(Button(this).apply {
            text = "Reset titik tengah stik (hapus kalibrasi)"
            setOnClickListener {
                Prefs.setLsCenter(this@MainActivity, 0f, 0f)
                Prefs.setRsCenter(this@MainActivity, 0f, 0f)
                Toast.makeText(this@MainActivity, "Titik tengah stik direset ke 0", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Switch(this).apply {
            text = "Stik kanan aktif (joystick virtual kedua)"
            isChecked = Prefs.rsEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                val s = MapperService.instance
                if (s != null) s.enableRs(on) else Prefs.setRsEnabled(this@MainActivity, on)
            }
        })
        addSlider(root, "Jangkauan stik gerak", 8, 45, Math.round(Prefs.stickRadius(this) * 100)) { Prefs.setStickRadius(this, it) }
        addSlider(root, "Deadzone stik", 5, 40, Math.round(Prefs.deadzone(this) * 100)) { Prefs.setDeadzone(this, it) }
        root.addView(Switch(this).apply {
            text = "Gerak 8 arah (stik kiri & kanan dikunci ke 8 arah, lebih stabil)"
            isChecked = Prefs.stick8(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setStick8(this@MainActivity, on) }
        })
        root.addView(Switch(this).apply {
            text = "D-pad menggerakkan analog virtual (LS) — matikan agar D-pad menyentuh 4 titiknya sendiri"
            isChecked = Prefs.dpadStick(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setDpadStick(this@MainActivity, on) }
        })
        root.addView(Switch(this).apply {
            text = "Mode halus (lintasan melengkung & penghalusan)"
            isChecked = Prefs.smooth(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSmooth(this@MainActivity, on) }
        })
        addSlider(root, "Kehalusan", 0, 80, Math.round(Prefs.smoothness(this) * 100)) { Prefs.setSmoothness(this, it) }
        addSlider(root, "Panjang segmen gestur", 20, 150, Prefs.segMs(this).toInt(), " ms") { Prefs.setSegMs(this, it) }
        test = TextView(this).apply { text = "\nTES GAMEPAD: tekan tombol / gerakkan stik di layar ini."; textSize = 14f }
        root.addView(test)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refreshProfiles() {
        profileBox.removeAllViews()
        val names = ProfileStore.names(this)
        if (names.isEmpty()) {
            profileBox.addView(TextView(this).apply { text = "(belum ada simpanan)"; textSize = 13f })
            return
        }
        for (n in names) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = n; textSize = 15f },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "Muat"
                setOnClickListener {
                    if (ProfileStore.load(this@MainActivity, n))
                        Toast.makeText(this@MainActivity, "Dimuat: $n. Buka game Anda.", Toast.LENGTH_LONG).show()
                }
            })
            row.addView(Button(this).apply {
                text = "Hapus"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Hapus simpanan")
                        .setMessage("Hapus \"$n\"?")
                        .setPositiveButton("Hapus") { _, _ -> ProfileStore.delete(this@MainActivity, n); refreshProfiles() }
                        .setNegativeButton("Batal", null)
                        .show()
                }
            })
            profileBox.addView(row)
        }
    }

    private fun addSlider(root: LinearLayout, title: String, lo: Int, hi: Int, cur: Int, unit: String = "%", onChange: (Int) -> Unit) {
        val lbl = TextView(this).apply { text = "$title: $cur$unit" }
        root.addView(lbl)
        root.addView(SeekBar(this).apply {
            this.max = hi - lo
            progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    lbl.text = "$title: ${lo + p}$unit"
                    onChange(lo + p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    // Layar tes: menampilkan kode tombol & nilai sumbu supaya gamepad "universal" bisa dicek.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN)
            test.text = "TES GAMEPAD\nTombol: ${KeyEvent.keyCodeToString(e.keyCode)} (${e.keyCode})"
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.actionMasked == MotionEvent.ACTION_MOVE) {
            if (calibrating) {
                for (i in 0..3) {
                    val x = e.getAxisValue(axesList[i])
                    if (x < amin[i]) amin[i] = x
                    if (x > amax[i]) amax[i] = x
                }
                lastV[0] = e.getAxisValue(MotionEvent.AXIS_X); lastV[1] = e.getAxisValue(MotionEvent.AXIS_Y)
                lastV[2] = e.getAxisValue(MotionEvent.AXIS_Z); lastV[3] = e.getAxisValue(MotionEvent.AXIS_RZ)
                lastV[4] = e.getAxisValue(MotionEvent.AXIS_RX); lastV[5] = e.getAxisValue(MotionEvent.AXIS_RY)
                return true
            }
            fun v(a: Int) = String.format("%.2f", e.getAxisValue(a))
            test.text = "TES GAMEPAD\nX=${v(MotionEvent.AXIS_X)} Y=${v(MotionEvent.AXIS_Y)}\n" +
                "Z=${v(MotionEvent.AXIS_Z)} RZ=${v(MotionEvent.AXIS_RZ)}\n" +
                "RX=${v(MotionEvent.AXIS_RX)} RY=${v(MotionEvent.AXIS_RY)}\n" +
                "HAT=${v(MotionEvent.AXIS_HAT_X)},${v(MotionEvent.AXIS_HAT_Y)}"
            return true
        }
        return super.onGenericMotionEvent(e)
    }
}
