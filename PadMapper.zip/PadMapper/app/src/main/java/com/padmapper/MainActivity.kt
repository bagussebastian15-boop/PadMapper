package com.padmapper

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Button
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var test: TextView
    // Sumbu yang dicatat saat kalibrasi: X, Y (stik kiri), Z, RZ, RX, RY (kandidat stik kanan)
    private val axes = intArrayOf(
        MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z,
        MotionEvent.AXIS_RZ, MotionEvent.AXIS_RX, MotionEvent.AXIS_RY
    )
    private val amin = FloatArray(6)
    private val amax = FloatArray(6)
    private val recent = ArrayDeque<FloatArray>()   // 3 sampel terakhir saat langkah pusat
    private var step = 0                             // 0 = tidak kalibrasi, 1 = rentang, 2 = pusat
    private val ui = Handler(Looper.getMainLooper())

    private fun startCalibration() {
        if (step != 0) return
        step = 1
        for (i in 0..5) { amin[i] = Float.MAX_VALUE; amax[i] = -Float.MAX_VALUE }
        test.text = "KALIBRASI 1/2 (rentang): putar KEDUA stik penuh ke semua arah, susuri tepinya, selama 6 detik..."
        ui.postDelayed({ startCenterStep() }, 6000)
    }

    private fun startCenterStep() {
        step = 2
        recent.clear()
        test.text = "KALIBRASI 2/2 (pusat): gerakkan stik sedikit lalu LEPASKAN. Jangan disentuh selama 3 detik..."
        ui.postDelayed({ finishCalibration() }, 3500)
    }

    private fun finishCalibration() {
        step = 0
        fun range(i: Int) = if (amax[i] >= amin[i]) amax[i] - amin[i] else 0f

        // Deteksi sumbu stik kanan (Z/RZ atau RX/RY) dari rentang geraknya
        val a = minOf(range(2), range(3))
        val b = minOf(range(4), range(5))
        val mode = when { a < 0.5f && b < 0.5f -> 0; a >= b -> 1; else -> 2 }
        Prefs.setRsAxes(this, mode)

        // Pusat = rata-rata sampel terakhir setelah stik dilepas
        val ctr = FloatArray(6)
        if (recent.isNotEmpty()) {
            for (smp in recent) for (i in 0..5) ctr[i] += smp[i]
            for (i in 0..5) ctr[i] /= recent.size
        }

        fun save(which: Int, ix: Int, iy: Int) {
            val cx = ctr[ix]; val cy = ctr[iy]
            fun ext(v: Float) = if (v >= 0.3f) v else 1f      // arah yang tidak dicapai: pakai 1.0
            Prefs.setStickCal(this, which, floatArrayOf(
                cx, cy,
                ext(amax[ix] - cx), ext(cx - amin[ix]),       // kanan, kiri
                ext(amax[iy] - cy), ext(cy - amin[iy])        // bawah, atas
            ))
        }
        val leftOk = range(0) >= 0.5f && range(1) >= 0.5f
        if (leftOk) save(Analog.LEFT, 0, 1) else Prefs.resetStickCal(this, Analog.LEFT)
        when (mode) {
            1 -> save(Analog.RIGHT, 2, 3)
            2 -> save(Analog.RIGHT, 4, 5)
            else -> Prefs.resetStickCal(this, Analog.RIGHT)
        }

        val msg = StringBuilder()
        msg.append(if (leftOk) "Stik kiri terkalibrasi." else "Stik kiri tidak terdeteksi (kalibrasi direset).")
        msg.append(when (mode) {
            1 -> " Stik kanan = Z/RZ, terkalibrasi."
            2 -> " Stik kanan = RX/RY, terkalibrasi."
            else -> " Stik kanan tidak terdeteksi, pakai otomatis (putar lebih penuh lalu ulangi)."
        })
        if (recent.isEmpty()) msg.append(" Pusat tidak terbaca (stik tidak digerakkan), pusat dianggap 0.")
        test.text = "TES GAMEPAD\n$msg\n${calSummary()}"
        Toast.makeText(this, msg.toString(), Toast.LENGTH_LONG).show()
    }

    private fun calSummary(): String {
        fun f(v: Float) = String.format("%.2f", v)
        fun line(name: String, which: Int): String {
            val k = Prefs.stickCal(this, which)
            return "$name pusat=(${f(k[0])}, ${f(k[1])}) kanan=${f(k[2])} kiri=${f(k[3])} bawah=${f(k[4])} atas=${f(k[5])}"
        }
        return line("Kiri", Analog.LEFT) + "\n" + line("Kanan", Analog.RIGHT)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "PadMapper\nEditor posisi: SELECT + START di gamepad, atau tombol 3."
            textSize = 15f
        })
        root.addView(Button(this).apply {
            text = "1. Aktifkan Layanan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. AUTO MAP / RESET (1 klik)"
            setOnClickListener {
                Prefs.reset(this@MainActivity)
                Toast.makeText(this@MainActivity, "Mapping default aktif! Buka game Anda.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "3. Edit posisi (muncul 6 detik, buka game dulu)"
            setOnClickListener {
                val s = MapperService.instance
                if (s == null) Toast.makeText(this@MainActivity, "Aktifkan layanan dulu.", Toast.LENGTH_LONG).show()
                else { s.showEditorDelayed(); Toast.makeText(this@MainActivity, "Buka game sekarang...", Toast.LENGTH_LONG).show() }
            }
        })
        if (Build.VERSION.SDK_INT < 34) {
            root.addView(Switch(this).apply {
                text = "Mode stik analog (Android < 14)\nGame bisa kehilangan fokus; matikan bila game terpause."
                isChecked = Prefs.stickMode(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setStickMode(this@MainActivity, on)
                    MapperService.instance?.setStickMode(on)
                }
            })
        }
        root.addView(Switch(this).apply {
            text = "Gelembung kontrol di atas game"
            isChecked = Prefs.bubbleOn(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                val s = MapperService.instance
                if (s != null) s.enableBubble(on) else Prefs.setBubbleOn(this@MainActivity, on)
            }
        })
        val opLabel = TextView(this).apply { text = "Transparansi: ${Prefs.opacity(this@MainActivity)}%" }
        root.addView(opLabel)
        root.addView(SeekBar(this).apply {
            max = 80
            progress = Prefs.opacity(this@MainActivity) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Prefs.setOpacity(this@MainActivity, 20 + p)
                    opLabel.text = "Transparansi: ${20 + p}%"
                    MapperService.instance?.applyOpacity()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(Button(this).apply {
            text = "Kalibrasi analog: rentang + pusat (10 detik)"
            setOnClickListener { startCalibration() }
        })
        root.addView(Button(this).apply {
            text = "Reset kalibrasi analog"
            setOnClickListener {
                Prefs.resetStickCal(this@MainActivity, Analog.LEFT)
                Prefs.resetStickCal(this@MainActivity, Analog.RIGHT)
                test.text = "TES GAMEPAD\nKalibrasi direset.\n${calSummary()}"
            }
        })
        root.addView(Switch(this).apply {
            text = "Balik arah vertikal kamera"
            isChecked = Prefs.camInvert(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setCamInvert(this@MainActivity, on) }
        })
        addHeader(root, "Deadzone")
        addSlider(root, "Deadzone stik kiri (gerak)", 0, 40, Math.round(Prefs.deadzone(this, Analog.LEFT) * 100)) { Prefs.setDeadzone(this, Analog.LEFT, it) }
        addSlider(root, "Deadzone stik kanan (kamera)", 0, 40, Math.round(Prefs.deadzone(this, Analog.RIGHT) * 100)) { Prefs.setDeadzone(this, Analog.RIGHT, it) }
        addHeader(root, "Sensitivitas sumbu X dan Y")
        addSlider(root, "Gerak sumbu X (kiri-kanan)", 25, 300, Math.round(Prefs.sens(this, Analog.LEFT, false) * 100)) { Prefs.setSens(this, Analog.LEFT, false, it) }
        addSlider(root, "Gerak sumbu Y (atas-bawah)", 25, 300, Math.round(Prefs.sens(this, Analog.LEFT, true) * 100)) { Prefs.setSens(this, Analog.LEFT, true, it) }
        addSlider(root, "Kamera sumbu X", 25, 300, Math.round(Prefs.sens(this, Analog.RIGHT, false) * 100)) { Prefs.setSens(this, Analog.RIGHT, false, it) }
        addSlider(root, "Kamera sumbu Y", 25, 300, Math.round(Prefs.sens(this, Analog.RIGHT, true) * 100)) { Prefs.setSens(this, Analog.RIGHT, true, it) }
        addHeader(root, "Jangkauan & konsistensi")
        addSlider(root, "Jangkauan stik gerak", 5, 25, Math.round(Prefs.stickRadius(this) * 100)) { Prefs.setStickRadius(this, it) }
        addSlider(root, "Kecepatan kamera", 50, 300, Math.round(Prefs.camSpeed(this) * 100)) { Prefs.setCamSpeed(this, it) }
        addSlider(root, "Kunci arah saat ditahan lurus", 0, 40, Math.round(Prefs.snap(this) * 100)) { Prefs.setSnap(this, it) }
        test = TextView(this).apply { text = "\nTES GAMEPAD: tekan tombol / gerakkan stik di layar ini."; textSize = 14f }
        root.addView(test)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addHeader(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply { text = "\n$title"; textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
    }

    private fun addSlider(root: LinearLayout, title: String, lo: Int, hi: Int, cur: Int, onChange: (Int) -> Unit) {
        val lbl = TextView(this).apply { text = "$title: $cur%" }
        root.addView(lbl)
        root.addView(SeekBar(this).apply {
            this.max = hi - lo
            progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    lbl.text = "$title: ${lo + p}%"
                    onChange(lo + p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    // Layar tes: menampilkan kode tombol & nilai sumbu supaya gamepad "universal" bisa dicek.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN)
            test.text = "TES GAMEPAD\nTombol: ${KeyEvent.keyCodeToString(e.keyCode)} (${e.keyCode})"
        return true
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.isFromSource(InputDevice.SOURCE_JOYSTICK) && e.actionMasked == MotionEvent.ACTION_MOVE) {
            if (step == 1) {
                for (i in 0..5) {
                    val x = e.getAxisValue(axes[i])
                    if (x < amin[i]) amin[i] = x
                    if (x > amax[i]) amax[i] = x
                }
                return true
            }
            if (step == 2) {
                recent.addLast(FloatArray(6) { e.getAxisValue(axes[it]) })
                while (recent.size > 3) recent.removeFirst()
                return true
            }
            fun v(a: Int) = String.format("%.2f", e.getAxisValue(a))
            val r = Analog.raw(this, e)
            val l = Analog.normalize(this, Analog.LEFT, r[0], r[1])
            val k = Analog.normalize(this, Analog.RIGHT, r[2], r[3])
            fun f(x: Float) = String.format("%.2f", x)
            test.text = "TES GAMEPAD\nX=${v(MotionEvent.AXIS_X)} Y=${v(MotionEvent.AXIS_Y)}\n" +
                "Z=${v(MotionEvent.AXIS_Z)} RZ=${v(MotionEvent.AXIS_RZ)}\n" +
                "RX=${v(MotionEvent.AXIS_RX)} RY=${v(MotionEvent.AXIS_RY)}\n" +
                "HAT=${v(MotionEvent.AXIS_HAT_X)},${v(MotionEvent.AXIS_HAT_Y)}\n" +
                "Terkalibrasi kiri=(${f(l.first)}, ${f(l.second)}) kanan=(${f(k.first)}, ${f(k.second)})"
            return true
        }
        return super.onGenericMotionEvent(e)
    }
}
