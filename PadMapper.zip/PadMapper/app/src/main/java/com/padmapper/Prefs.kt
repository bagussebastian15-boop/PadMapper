package com.padmapper

import android.content.Context
import android.view.KeyEvent

/** Posisi disimpan sebagai pecahan layar (0..1) supaya cocok di resolusi apa pun. */
object Prefs {
    const val LS = -1   // pusat joystick virtual kiri (gerak)
    const val RS = -2   // pusat area kamera kanan

    val PRESET: Map<Int, Pair<Float, Float>> = mapOf(
        KeyEvent.KEYCODE_BUTTON_A to (0.88f to 0.72f),
        KeyEvent.KEYCODE_BUTTON_B to (0.95f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_X to (0.81f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_Y to (0.88f to 0.38f),
        KeyEvent.KEYCODE_BUTTON_L1 to (0.10f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_R1 to (0.90f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_L2 to (0.20f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_R2 to (0.78f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_THUMBL to (0.50f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_THUMBR to (0.60f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_START to (0.55f to 0.08f),
        KeyEvent.KEYCODE_BUTTON_SELECT to (0.45f to 0.08f),
        KeyEvent.KEYCODE_DPAD_UP to (0.30f to 0.40f),
        KeyEvent.KEYCODE_DPAD_DOWN to (0.30f to 0.70f),
        KeyEvent.KEYCODE_DPAD_LEFT to (0.24f to 0.55f),
        KeyEvent.KEYCODE_DPAD_RIGHT to (0.36f to 0.55f),
        LS to (0.15f to 0.68f),
        RS to (0.72f to 0.48f),
    )

    private fun sp(c: Context) = c.getSharedPreferences("map", Context.MODE_PRIVATE)

    fun reset(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("x_") || it.startsWith("y_") || it.startsWith("tap_") }.forEach { e.remove(it) }
        e.apply()
    }

    fun stickMode(c: Context) = sp(c).getBoolean("stick_mode", false)
    fun setStickMode(c: Context, on: Boolean) { sp(c).edit().putBoolean("stick_mode", on).apply() }

    // Transparansi gelembung & tombol di layar (20..100 persen)
    fun opacity(c: Context) = sp(c).getInt("opacity", 80)
    fun setOpacity(c: Context, v: Int) { sp(c).edit().putInt("opacity", v.coerceIn(20, 100)).apply() }

    fun bubbleOn(c: Context) = sp(c).getBoolean("bubble_on", true)
    fun setBubbleOn(c: Context, on: Boolean) { sp(c).edit().putBoolean("bubble_on", on).apply() }

    fun showButtons(c: Context) = sp(c).getBoolean("show_buttons", false)
    fun setShowButtons(c: Context, on: Boolean) { sp(c).edit().putBoolean("show_buttons", on).apply() }

    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", 0)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", 200)
    // Mode tombol: true = TAP sekali (pause/menu), false = TAHAN. Default TAP untuk tombol menu.
    private val tapDefault = setOf(
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
        KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR
    )
    fun tapMode(c: Context, k: Int) = sp(c).getBoolean("tap_$k", k in tapDefault)
    fun setTapMode(c: Context, k: Int, on: Boolean) { sp(c).edit().putBoolean("tap_$k", on).apply() }

    fun setBubblePos(c: Context, x: Int, y: Int) { sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply() }

    /** Pakai posisi tersimpan; kalau belum ada, pakai preset (jadi langsung jalan). */
    fun get(c: Context, key: Int): Pair<Float, Float>? {
        val s = sp(c)
        if (s.contains("x_$key")) return s.getFloat("x_$key", 0f) to s.getFloat("y_$key", 0f)
        return PRESET[key]
    }

    fun set(c: Context, key: Int, x: Float, y: Float) {
        sp(c).edit().putFloat("x_$key", x).putFloat("y_$key", y).apply()
    }
}
