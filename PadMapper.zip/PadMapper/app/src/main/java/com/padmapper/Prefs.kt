package com.padmapper

import android.content.Context
import android.view.KeyEvent

/** Posisi disimpan sebagai pecahan layar (0..1) supaya cocok di resolusi apa pun. */
object Prefs {
    const val LS = -1   // pusat joystick virtual kiri (gerak)
    const val RS = -2   // pusat area kamera kanan

    val PRESET: Map<Int, Pair<Float, Float>> = mapOf(
        KeyEvent.KEYCODE_BUTTON_A to (0.88f to 0.72f),
        KeyEvent.KEYCODE_BUTTON_B to (0.95f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_X to (0.81f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_Y to (0.88f to 0.38f),
        KeyEvent.KEYCODE_BUTTON_L1 to (0.10f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_R1 to (0.90f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_L2 to (0.20f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_R2 to (0.78f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_THUMBL to (0.50f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_THUMBR to (0.60f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_START to (0.55f to 0.08f),
        KeyEvent.KEYCODE_BUTTON_SELECT to (0.45f to 0.08f),
        KeyEvent.KEYCODE_DPAD_UP to (0.30f to 0.40f),
        KeyEvent.KEYCODE_DPAD_DOWN to (0.30f to 0.70f),
        KeyEvent.KEYCODE_DPAD_LEFT to (0.24f to 0.55f),
        KeyEvent.KEYCODE_DPAD_RIGHT to (0.36f to 0.55f),
        LS to (0.15f to 0.68f),
        RS to (0.72f to 0.48f),
    )

    private fun sp(c: Context) = c.getSharedPreferences("map", Context.MODE_PRIVATE)

    fun reset(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("x_") || it.startsWith("y_") || it.startsWith("tap") || it.startsWith("sz_") }.forEach { e.remove(it) }
        e.apply()
    }

    fun stickMode(c: Context) = sp(c).getBoolean("stick_mode", false)
    fun setStickMode(c: Context, on: Boolean) { sp(c).edit().putBoolean("stick_mode", on).apply() }

    // Transparansi gelembung & tombol di layar (20..100 persen)
    fun opacity(c: Context) = sp(c).getInt("opacity", 80)
    fun setOpacity(c: Context, v: Int) { sp(c).edit().putInt("opacity", v.coerceIn(20, 100)).apply() }

    fun bubbleOn(c: Context) = sp(c).getBoolean("bubble_on", true)
    fun setBubbleOn(c: Context, on: Boolean) { sp(c).edit().putBoolean("bubble_on", on).apply() }

    fun showButtons(c: Context) = sp(c).getBoolean("show_buttons", false)
    fun setShowButtons(c: Context, on: Boolean) { sp(c).edit().putBoolean("show_buttons", on).apply() }

    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", 0)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", 200)
    // Mode tombol: false = sentuhan MENGIKUTI lama tekan (bawaan), true = satu ketukan saja.
    fun tapMode(c: Context, k: Int) = sp(c).getBoolean("tap3_$k", false)
    fun setTapMode(c: Context, k: Int, on: Boolean) { sp(c).edit().putBoolean("tap3_$k", on).apply() }

    // Ukuran tombol (persen, 50..250)
    fun sizePct(c: Context, k: Int) = sp(c).getInt("sz_$k", 100)
    fun setSizePct(c: Context, k: Int, pct: Int) { sp(c).edit().putInt("sz_$k", pct.coerceIn(50, 250)).apply() }

    // Sumbu stik kanan: 0 = otomatis, 1 = Z/RZ, 2 = RX/RY
    fun rsAxes(c: Context) = sp(c).getInt("rs_axes", 0)
    fun setRsAxes(c: Context, m: Int) { sp(c).edit().putInt("rs_axes", m).apply() }
    fun camInvert(c: Context) = sp(c).getBoolean("cam_inv", false)
    fun setCamInvert(c: Context, on: Boolean) { sp(c).edit().putBoolean("cam_inv", on).apply() }

    // Pengaturan stik analog (persen)
    // Deadzone terpisah untuk stik kiri (gerak) & kanan (kamera). Nilai lama "dz" dipakai sebagai bawaan.
    fun deadzone(c: Context, stick: Int): Float {
        val old = sp(c).getInt("dz", 15)
        return sp(c).getInt(if (stick == Analog.LEFT) "dz_l" else "dz_r", old) / 100f
    }
    fun setDeadzone(c: Context, stick: Int, pct: Int) {
        sp(c).edit().putInt(if (stick == Analog.LEFT) "dz_l" else "dz_r", pct.coerceIn(0, 40)).apply()
    }

    // Sensitivitas per sumbu (persen, 25..300). Stik kiri: skala simpangan joystick virtual; stik kanan: skala kecepatan kamera.
    private fun sensKey(stick: Int, y: Boolean) = "sens_${if (stick == Analog.LEFT) "l" else "r"}${if (y) "y" else "x"}"
    fun sens(c: Context, stick: Int, y: Boolean) = sp(c).getInt(sensKey(stick, y), 100) / 100f
    fun setSens(c: Context, stick: Int, y: Boolean, pct: Int) { sp(c).edit().putInt(sensKey(stick, y), pct.coerceIn(25, 300)).apply() }

    // Kunci arah: simpangan sumbu minor kecil diabaikan saat stik ditahan lurus (persen dari sumbu utama, 0..40)
    fun snap(c: Context) = sp(c).getInt("snap", 8) / 100f
    fun setSnap(c: Context, pct: Int) { sp(c).edit().putInt("snap", pct.coerceIn(0, 40)).apply() }

    /**
     * Kalibrasi stik: [pusatX, pusatY, jangkauanKanan, jangkauanKiri, jangkauanBawah, jangkauanAtas],
     * jangkauan = jarak dari pusat ke ujung gerak stik di arah itu (positif). Bawaan: pusat 0, jangkauan 1.
     */
    fun stickCal(c: Context, stick: Int): FloatArray {
        val s = sp(c); val p = "cal_$stick"
        return floatArrayOf(
            s.getFloat("${p}_cx", 0f), s.getFloat("${p}_cy", 0f),
            s.getFloat("${p}_xp", 1f).coerceAtLeast(0.3f), s.getFloat("${p}_xn", 1f).coerceAtLeast(0.3f),
            s.getFloat("${p}_yp", 1f).coerceAtLeast(0.3f), s.getFloat("${p}_yn", 1f).coerceAtLeast(0.3f),
        )
    }
    fun setStickCal(c: Context, stick: Int, v: FloatArray) {
        val p = "cal_$stick"
        sp(c).edit().putFloat("${p}_cx", v[0]).putFloat("${p}_cy", v[1])
            .putFloat("${p}_xp", v[2]).putFloat("${p}_xn", v[3])
            .putFloat("${p}_yp", v[4]).putFloat("${p}_yn", v[5]).apply()
    }
    fun resetStickCal(c: Context, stick: Int) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("cal_${stick}_") }.forEach { e.remove(it) }
        e.apply()
    }

    fun stickRadius(c: Context) = sp(c).getInt("sr", 12) / 100f      // jangkauan stik kiri, % tinggi layar
    fun setStickRadius(c: Context, pct: Int) { sp(c).edit().putInt("sr", pct.coerceIn(5, 25)).apply() }
    fun camSpeed(c: Context) = sp(c).getInt("cs", 100) / 100f        // kecepatan kamera stik kanan
    fun setCamSpeed(c: Context, pct: Int) { sp(c).edit().putInt("cs", pct.coerceIn(50, 300)).apply() }

    fun setBubblePos(c: Context, x: Int, y: Int) { sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply() }

    /** Pakai posisi tersimpan; kalau belum ada, pakai preset (jadi langsung jalan). */
    fun get(c: Context, key: Int): Pair<Float, Float>? {
        val s = sp(c)
        if (s.contains("x_$key")) return s.getFloat("x_$key", 0f) to s.getFloat("y_$key", 0f)
        return PRESET[key]
    }

    fun set(c: Context, key: Int, x: Float, y: Float) {
        sp(c).edit().putFloat("x_$key", x).putFloat("y_$key", y).apply()
    }
}
