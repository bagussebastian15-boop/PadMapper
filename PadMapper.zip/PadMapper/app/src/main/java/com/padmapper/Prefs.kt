package com.padmapper

import android.content.Context
import android.view.KeyEvent

/** Posisi disimpan sebagai pecahan layar (0..1) supaya cocok di resolusi apa pun. */
object Prefs {
    const val LS = -1   // pusat joystick virtual kiri (gerak)
    const val RS = -2   // pusat area kamera kanan

    val PRESET: Map<Int, Pair<Float, Float>> = mapOf(
        KeyEvent.KEYCODE_BUTTON_A to (0.88f to 0.72f),
        KeyEvent.KEYCODE_BUTTON_B to (0.95f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_X to (0.81f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_Y to (0.88f to 0.38f),
        KeyEvent.KEYCODE_BUTTON_L1 to (0.10f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_R1 to (0.90f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_L2 to (0.20f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_R2 to (0.78f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_THUMBL to (0.50f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_THUMBR to (0.60f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_START to (0.55f to 0.08f),
        KeyEvent.KEYCODE_BUTTON_SELECT to (0.45f to 0.08f),
        KeyEvent.KEYCODE_DPAD_UP to (0.30f to 0.40f),
        KeyEvent.KEYCODE_DPAD_DOWN to (0.30f to 0.70f),
        KeyEvent.KEYCODE_DPAD_LEFT to (0.24f to 0.55f),
        KeyEvent.KEYCODE_DPAD_RIGHT to (0.36f to 0.55f),
        LS to (0.15f to 0.68f),
        RS to (0.72f to 0.48f),
    )

    private fun sp(c: Context) = c.getSharedPreferences("map", Context.MODE_PRIVATE)

    fun reset(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("x_") || it.startsWith("y_") || it.startsWith("tap") || it.startsWith("sz_") }.forEach { e.remove(it) }
        e.apply()
    }

    fun stickMode(c: Context) = sp(c).getBoolean("stick_mode", false)
    fun setStickMode(c: Context, on: Boolean) { sp(c).edit().putBoolean("stick_mode", on).apply() }

    // Transparansi gelembung & tombol di layar (20..100 persen)
    fun opacity(c: Context) = sp(c).getInt("opacity", 80)
    fun setOpacity(c: Context, v: Int) { sp(c).edit().putInt("opacity", v.coerceIn(20, 100)).apply() }

    fun bubbleOn(c: Context) = sp(c).getBoolean("bubble_on", true)
    fun setBubbleOn(c: Context, on: Boolean) { sp(c).edit().putBoolean("bubble_on", on).apply() }

    fun showButtons(c: Context) = sp(c).getBoolean("show_buttons", false)
    fun setShowButtons(c: Context, on: Boolean) { sp(c).edit().putBoolean("show_buttons", on).apply() }

    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", 0)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", 200)
    // Mode tombol: false = sentuhan MENGIKUTI lama tekan (bawaan), true = satu ketukan saja.
    fun tapMode(c: Context, k: Int) = sp(c).getBoolean("tap3_$k", false)
    fun setTapMode(c: Context, k: Int, on: Boolean) { sp(c).edit().putBoolean("tap3_$k", on).apply() }

    // Ukuran tombol (persen, 50..250)
    fun sizePct(c: Context, k: Int) = sp(c).getInt("sz_$k", 100)
    fun setSizePct(c: Context, k: Int, pct: Int) { sp(c).edit().putInt("sz_$k", pct.coerceIn(50, 250)).apply() }

    // Sumbu stik kanan: 0 = otomatis, 1 = Z/RZ, 2 = RX/RY
    fun rsAxes(c: Context) = sp(c).getInt("rs_axes", 0)
    fun setRsAxes(c: Context, m: Int) { sp(c).edit().putInt("rs_axes", m).apply() }
    fun camInvert(c: Context) = sp(c).getBoolean("cam_inv", false)
    fun setCamInvert(c: Context, on: Boolean) { sp(c).edit().putBoolean("cam_inv", on).apply() }

    // Pengaturan stik analog (persen)
    fun deadzone(c: Context) = sp(c).getInt("dz", 15) / 100f
    fun setDeadzone(c: Context, pct: Int) { sp(c).edit().putInt("dz", pct.coerceIn(5, 40)).apply() }
    fun stickRadius(c: Context) = sp(c).getInt("sr", 12) / 100f      // jangkauan stik kiri, % tinggi layar
    fun setStickRadius(c: Context, pct: Int) { sp(c).edit().putInt("sr", pct.coerceIn(5, 25)).apply() }
    fun camSpeed(c: Context) = sp(c).getInt("cs", 100) / 100f        // kecepatan kamera stik kanan
    fun setCamSpeed(c: Context, pct: Int) { sp(c).edit().putInt("cs", pct.coerceIn(50, 300)).apply() }

    // ---- Analog lanjutan ----
    // Deadzone terpisah per stik (bawaan: ikut nilai "dz" lama supaya setelan lama tetap berlaku)
    fun deadzoneL(c: Context) = sp(c).getInt("dz_l", sp(c).getInt("dz", 15)) / 100f
    fun deadzoneR(c: Context) = sp(c).getInt("dz_r", sp(c).getInt("dz", 15)) / 100f
    fun setDeadzoneL(c: Context, pct: Int) { sp(c).edit().putInt("dz_l", pct.coerceIn(0, 40)).apply() }
    fun setDeadzoneR(c: Context, pct: Int) { sp(c).edit().putInt("dz_r", pct.coerceIn(0, 40)).apply() }
    // Deadzone luar: defleksi di atas (100 - nilai)% dianggap penuh (stik tua sering tak sampai 1.0)
    fun outerZone(c: Context) = sp(c).getInt("oz", 5) / 100f
    fun setOuterZone(c: Context, pct: Int) { sp(c).edit().putInt("oz", pct.coerceIn(0, 15)).apply() }

    // Sensitivitas sumbu X dan Y terpisah (persen, 50..200)
    fun sensX(c: Context) = sp(c).getInt("sens_x", 100) / 100f
    fun sensY(c: Context) = sp(c).getInt("sens_y", 100) / 100f
    fun setSensX(c: Context, pct: Int) { sp(c).edit().putInt("sens_x", pct.coerceIn(50, 200)).apply() }
    fun setSensY(c: Context, pct: Int) { sp(c).edit().putInt("sens_y", pct.coerceIn(50, 200)).apply() }

    // Rentang gerak stik gerak untuk tiap arah: 0 = kiri, 1 = kanan, 2 = atas, 3 = bawah (persen, 50..150)
    private val dirKeys = arrayOf("rng_l", "rng_r", "rng_u", "rng_d")
    fun range(c: Context, dir: Int) = sp(c).getInt(dirKeys[dir], 100) / 100f
    fun setRange(c: Context, dir: Int, pct: Int) { sp(c).edit().putInt(dirKeys[dir], pct.coerceIn(50, 150)).apply() }

    // Kunci arah: bila stik ditahan hampir lurus, sumbu lain dinolkan (persen sudut, 0 = mati)
    fun axisLock(c: Context) = sp(c).getInt("lock", 12) / 100f
    fun setAxisLock(c: Context, pct: Int) { sp(c).edit().putInt("lock", pct.coerceIn(0, 30)).apply() }

    // Offset pusat analog per sumbu (hasil kalibrasi pusat)
    private val offKeys = mapOf(
        android.view.MotionEvent.AXIS_X to "off_x", android.view.MotionEvent.AXIS_Y to "off_y",
        android.view.MotionEvent.AXIS_Z to "off_z", android.view.MotionEvent.AXIS_RZ to "off_rz",
        android.view.MotionEvent.AXIS_RX to "off_rx", android.view.MotionEvent.AXIS_RY to "off_ry",
    )
    val calibAxes: Set<Int> get() = offKeys.keys
    fun centerOffset(c: Context, axis: Int): Float {
        val key = offKeys[axis] ?: return 0f
        return sp(c).getFloat(key, 0f)
    }
    fun setCenterOffsets(c: Context, values: Map<Int, Float>) {
        val e = sp(c).edit()
        for ((a, v) in values) offKeys[a]?.let { e.putFloat(it, v) }
        e.apply()
    }
    fun resetCenter(c: Context) = setCenterOffsets(c, offKeys.keys.associateWith { 0f })

    fun resetAnalog(c: Context) {
        val e = sp(c).edit()
        listOf("dz", "dz_l", "dz_r", "oz", "sens_x", "sens_y", "rng_l", "rng_r", "rng_u", "rng_d", "lock").forEach { e.remove(it) }
        e.apply()
    }

    fun setBubblePos(c: Context, x: Int, y: Int) { sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply() }

    /** Pakai posisi tersimpan; kalau belum ada, pakai preset (jadi langsung jalan). */
    fun get(c: Context, key: Int): Pair<Float, Float>? {
        val s = sp(c)
        if (s.contains("x_$key")) return s.getFloat("x_$key", 0f) to s.getFloat("y_$key", 0f)
        return PRESET[key]
    }

    fun set(c: Context, key: Int, x: Float, y: Float) {
        sp(c).edit().putFloat("x_$key", x).putFloat("y_$key", y).apply()
    }
}
