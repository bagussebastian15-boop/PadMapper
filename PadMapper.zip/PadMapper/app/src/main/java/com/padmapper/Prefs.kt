package com.padmapper

import android.content.Context
import android.view.KeyEvent

/** Posisi disimpan sebagai pecahan layar (0..1) supaya cocok di resolusi apa pun. */
object Prefs {
    const val LS = -1   // pusat joystick virtual kiri (gerak)
    const val RS = -2   // pusat joystick virtual kanan

    val PRESET: Map<Int, Pair<Float, Float>> = mapOf(
        KeyEvent.KEYCODE_BUTTON_A to (0.88f to 0.72f),
        KeyEvent.KEYCODE_BUTTON_B to (0.95f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_X to (0.81f to 0.55f),
        KeyEvent.KEYCODE_BUTTON_Y to (0.88f to 0.38f),
        KeyEvent.KEYCODE_BUTTON_L1 to (0.10f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_R1 to (0.90f to 0.12f),
        KeyEvent.KEYCODE_BUTTON_L2 to (0.20f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_R2 to (0.78f to 0.85f),
        KeyEvent.KEYCODE_BUTTON_THUMBL to (0.50f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_THUMBR to (0.60f to 0.90f),
        KeyEvent.KEYCODE_BUTTON_START to (0.55f to 0.50f),
        KeyEvent.KEYCODE_BUTTON_SELECT to (0.45f to 0.50f),
        KeyEvent.KEYCODE_DPAD_UP to (0.30f to 0.40f),
        KeyEvent.KEYCODE_DPAD_DOWN to (0.30f to 0.70f),
        KeyEvent.KEYCODE_DPAD_LEFT to (0.24f to 0.55f),
        KeyEvent.KEYCODE_DPAD_RIGHT to (0.36f to 0.55f),
        LS to (0.15f to 0.68f),
        RS to (0.72f to 0.48f),
    )

    private fun sp(c: Context) = c.getSharedPreferences("map", Context.MODE_PRIVATE)

    /** Sekali saja: START & SELECT yang tersimpan di posisi lama (atas) dikembalikan ke preset baru di tengah layar. */
    fun migrateSelectStart(c: Context) {
        val s = sp(c)
        if (s.getBoolean("ss_mid1", false)) return
        val e = s.edit()
        for (k in listOf(KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT)) e.remove("x_$k").remove("y_$k")
        e.putBoolean("ss_mid1", true).apply()
    }

    fun reset(c: Context) {
        val e = sp(c).edit()
        sp(c).all.keys.filter { it.startsWith("x_") || it.startsWith("y_") || it.startsWith("tap") || it.startsWith("sz_") }.forEach { e.remove(it) }
        e.apply()
    }

    // Mode stik analog (Android < 14) SELALU aktif, tidak ada saklar lagi
    fun stickMode(c: Context) = true
    fun setStickMode(c: Context, on: Boolean) { sp(c).edit().putBoolean("stick_mode", on).apply() }

    // Stik analog kiri & kanan (nyala/mati lewat tahan gelembung 5 detik)
    fun analogOn(c: Context) = sp(c).getBoolean("analog_on", true)
    fun setAnalogOn(c: Context, on: Boolean) { sp(c).edit().putBoolean("analog_on", on).apply() }

    // Transparansi gelembung & tombol di layar (20..100 persen)
    fun opacity(c: Context) = sp(c).getInt("opacity", 80)
    fun setOpacity(c: Context, v: Int) { sp(c).edit().putInt("opacity", v.coerceIn(20, 100)).apply() }

    fun bubbleOn(c: Context) = sp(c).getBoolean("bubble_on", true)
    fun setBubbleOn(c: Context, on: Boolean) { sp(c).edit().putBoolean("bubble_on", on).apply() }

    fun showButtons(c: Context) = sp(c).getBoolean("show_buttons", false)
    fun setShowButtons(c: Context, on: Boolean) { sp(c).edit().putBoolean("show_buttons", on).apply() }

    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", 0)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", 200)
    // Mode tombol: false = sentuhan MENGIKUTI lama tekan (bawaan), true = satu ketukan saja.
    fun tapMode(c: Context, k: Int) = sp(c).getBoolean("tap3_$k", false)
    fun setTapMode(c: Context, k: Int, on: Boolean) { sp(c).edit().putBoolean("tap3_$k", on).apply() }

    // Ukuran tombol (persen, 50..250)
    fun sizePct(c: Context, k: Int) = sp(c).getInt("sz_$k", 100)
    fun setSizePct(c: Context, k: Int, pct: Int) { sp(c).edit().putInt("sz_$k", pct.coerceIn(50, 250)).apply() }

    // Panjang segmen gestur (ms): makin panjang = lebih sedikit sambungan gestur (lebih mulus, sedikit lebih lambat respons)
    fun segMs(c: Context) = sp(c).getInt("seg", 40).toLong()
    fun setSegMs(c: Context, ms: Int) { sp(c).edit().putInt("seg", ms.coerceIn(20, 150)).apply() }

    // Gerak 8 arah: stik kiri "dikunci" ke 8 arah, jari virtual hanya bergeser saat arah berganti
    fun stick8(c: Context) = sp(c).getBoolean("stick8", false)
    fun setStick8(c: Context, on: Boolean) { sp(c).edit().putBoolean("stick8", on).apply() }

    // D-pad menggerakkan joystick virtual (analog) alih-alih menyentuh 4 titik D-pad sendiri.
    // Bawaan MATI: D-pad menyentuh titik UP/DOWN/LEFT/RIGHT miliknya, terpisah dari analog (LS).
    // Kunci baru "dpad_stick2" supaya pengaturan lama (bawaan nyala) tidak terbawa.
    fun dpadStick(c: Context) = sp(c).getBoolean("dpad_stick2", false)
    fun setDpadStick(c: Context, on: Boolean) { sp(c).edit().putBoolean("dpad_stick2", on).apply() }

    // Mode halus: lintasan melengkung bersambung + penghalusan perpindahan antar-segmen
    fun smooth(c: Context) = sp(c).getBoolean("smooth", true)
    fun setSmooth(c: Context, on: Boolean) { sp(c).edit().putBoolean("smooth", on).apply() }
    fun smoothness(c: Context) = sp(c).getInt("smoothness", 30).coerceIn(0, 80) / 100f
    fun setSmoothness(c: Context, pct: Int) { sp(c).edit().putInt("smoothness", pct.coerceIn(0, 80)).apply() }

    // Stik kanan (joystick virtual kedua): bawaan MATI, karena kalau pusat RS tidak pas di joystick game ia menyentuh layar sendiri
    fun rsEnabled(c: Context) = true   // stik kanan SELALU aktif, tidak ada saklar lagi
    fun setRsEnabled(c: Context, on: Boolean) { sp(c).edit().putBoolean("rs_on", on).apply() }

    // Titik tengah stik (hasil kalibrasi). Gamepad murah sering tidak berada di 0,0 saat dilepas.
    fun lsCx(c: Context) = sp(c).getFloat("ls_cx", 0f)
    fun lsCy(c: Context) = sp(c).getFloat("ls_cy", 0f)
    fun setLsCenter(c: Context, x: Float, y: Float) { sp(c).edit().putFloat("ls_cx", x).putFloat("ls_cy", y).apply() }
    fun rsCx(c: Context) = sp(c).getFloat("rs_cx", 0f)
    fun rsCy(c: Context) = sp(c).getFloat("rs_cy", 0f)
    fun setRsCenter(c: Context, x: Float, y: Float) { sp(c).edit().putFloat("rs_cx", x).putFloat("rs_cy", y).apply() }

    // Sumbu stik kanan: 0 = otomatis, 1 = Z/RZ, 2 = RX/RY
    fun rsAxes(c: Context) = sp(c).getInt("rs_axes", 0)
    fun setRsAxes(c: Context, m: Int) { sp(c).edit().putInt("rs_axes", m).apply() }
    fun camInvert(c: Context) = sp(c).getBoolean("cam_inv", false)
    fun setCamInvert(c: Context, on: Boolean) { sp(c).edit().putBoolean("cam_inv", on).apply() }

    // Pengaturan stik analog (persen)
    fun deadzone(c: Context) = sp(c).getInt("dz", 15) / 100f
    fun setDeadzone(c: Context, pct: Int) { sp(c).edit().putInt("dz", pct.coerceIn(5, 40)).apply() }
    fun stickRadius(c: Context) = sp(c).getInt("sr3", 19) / 100f     // jangkauan stik kiri, % tinggi layar
    fun setStickRadius(c: Context, pct: Int) { sp(c).edit().putInt("sr3", pct.coerceIn(8, 45)).apply() }
    fun camSpeed(c: Context) = sp(c).getInt("cs", 100) / 100f        // kecepatan kamera stik kanan
    fun setCamSpeed(c: Context, pct: Int) { sp(c).edit().putInt("cs", pct.coerceIn(50, 300)).apply() }

    fun setBubblePos(c: Context, x: Int, y: Int) { sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply() }

    /** Pakai posisi tersimpan; kalau belum ada, pakai preset (jadi langsung jalan). */
    fun get(c: Context, key: Int): Pair<Float, Float>? {
        val s = sp(c)
        if (s.contains("x_$key")) return s.getFloat("x_$key", 0f) to s.getFloat("y_$key", 0f)
        return PRESET[key]
    }

    fun set(c: Context, key: Int, x: Float, y: Float) {
        sp(c).edit().putFloat("x_$key", x).putFloat("y_$key", y).apply()
    }
}
