package com.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Mesin sentuhan virtual multi-jari.
 * - down/up : sentuhan ditahan (untuk tembak, gerak, dll.)
 * - tap     : ketukan mandiri sekali jalan (untuk pause/menu), tidak bergantung pada waktu lepas tombol
 * Semua jari aktif dikirim dalam SATU gestur per segmen supaya tidak saling membatalkan.
 */
class TouchEngine(private val svc: AccessibilityService) {

    private class T(var x: Float, var y: Float) {
        var px = x
        var py = y
        var last: StrokeDescription? = null
        var up = false
        var tap = false
        var retry = 0
        val ox = x        // titik asal sentuhan (pusat joystick)
        val oy = y
        var damp = false  // peredam getar (khusus stik gerak)
        var cx = x        // target yang sudah "dikunci" (untuk peredam getar)
        var cy = y
        var vx = 0f   // kecepatan segmen sebelumnya (px/ms) untuk lintasan bersambung
        var vy = 0f
        var wig = 1f  // arah getaran mikro 1 px saat ditahan diam (jalur tidak boleh panjang nol)
    }

    private class Retap(val x: Float, val y: Float, val retry: Int)

    private val touches = LinkedHashMap<String, T>()
    private val flight = ArrayList<Retap>()
    private var inFlight = false
    private var building = false
    private var seq = 0
    private val seg: Long
        get() {
            val s = Prefs.segMs(svc)
            return if (Prefs.smooth(svc)) maxOf(s, 50L) else s   // mode halus: segmen minimal 50 ms
        }
    private var dispatchAt = 0L
    private var avgLat = 0f
    private var done = 0
    private var cancels = 0
    private val tapMs = 50L

    // --- Penanda gestur & pemulihan pembatalan ---
    private val handler = Handler(Looper.getMainLooper())
    private var gen = 0                 // nomor gestur terakhir yang dikirim; callback gestur lama diabaikan
    private var quick = 0               // pembatalan beruntun yang datang sangat cepat (<25 ms)
    private var quickTotal = 0
    private var lastCancelLat = 0L
    private var dispatchFails = 0
    private val pumpLater = Runnable { pump() }

    /** Dipanggil sebelum tiap segmen dibuat (dipakai untuk kamera stik kanan). */
    var beforeSegment: (() -> Unit)? = null

    /** (x,y) = titik sentuh awal, (tx,ty) = target pertama (untuk stik: langsung bergeser tanpa jeda). */
    fun down(id: String, x: Float, y: Float, tx: Float = x, ty: Float = y, damp: Boolean = id == "LS" || id == "RS") {
        // Jangan hilangkan pelepasan sentuhan lama yang masih tertunda / tertahan
        touches[id]?.let { old ->
            old.up = true
            touches.remove(id)
            touches["$id~${seq++}"] = old
        }
        touches[id] = T(x, y).also { it.x = tx; it.y = ty; it.damp = damp }
        pump()
    }

    fun move(id: String, x: Float, y: Float) { touches[id]?.let { it.x = x; it.y = y } }
    fun up(id: String) { touches[id]?.up = true; pump() }
    fun isDown(id: String) = touches[id]?.up == false
    fun clear() { touches.clear(); flight.clear() }

    fun cancelCount() = cancels

    /** Ringkasan pembatalan untuk panel diagnosis. */
    fun cancelInfo() = "$cancels (cepat $quickTotal, terakhir ${lastCancelLat}ms)"

    /** Posisi jari virtual saat ini (untuk alat diagnosis). */
    fun snapshot(): List<Triple<String, Float, Float>> =
        touches.entries.filter { !it.value.tap }.map { Triple(it.key, it.value.px, it.value.py) }

    /** Lepas semua sentuhan yang sedang ditahan dengan benar (supaya tidak ada jari virtual yang tersangkut). */
    fun releaseAll() {
        touches.values.forEach { if (!it.tap) it.up = true }
        pump()
    }

    /** Ringkasan latensi gestur: selisih (rata-rata - panjang segmen) = keterlambatan tambahan dari sistem. */
    fun stats(): String =
        if (done == 0) "Latensi: belum ada data (tekan tombol dulu)"
        else "Latensi gestur: ${avgLat.toInt()} ms (segmen $seg ms) | tambahan ${(avgLat - seg).toInt()} ms | batal $cancels/${done + cancels}"

    fun tap(x: Float, y: Float, retry: Int = 0) {
        val t = T(x, y)
        t.tap = true
        t.up = true
        t.retry = retry
        touches["tap${seq++}"] = t
        pump()
    }

    /**
     * Callback per gestur. Callback dari gestur yang sudah digantikan (id != gen) diabaikan, supaya satu
     * pembatalan lama tidak menandai gestur BARU sebagai selesai lalu memicu pembatalan beruntun
     * (tiap pembatalan = jari virtual terangkat lalu menekan lagi = getar).
     */
    private inner class Cb(val id: Int) : AccessibilityService.GestureResultCallback() {
        override fun onCompleted(g: GestureDescription?) {
            if (id != gen) return
            val lat = (SystemClock.uptimeMillis() - dispatchAt).toFloat()
            avgLat = if (done == 0) lat else avgLat * 0.8f + lat * 0.2f
            done++
            quick = 0
            dispatchFails = 0
            inFlight = false
            flight.clear()
            pump()
        }

        override fun onCancelled(g: GestureDescription?) {
            if (id != gen) return
            cancels++
            val lat = SystemClock.uptimeMillis() - dispatchAt
            lastCancelLat = lat
            if (lat < 25) { quick++; quickTotal++ } else quick = 0
            inFlight = false
            // Sentuhan yang masih ditahan dimulai ulang sebagai sentuhan baru
            val fromCenter = Prefs.restartCenter(svc)
            touches.values.forEach {
                it.last = null; it.vx = 0f; it.vy = 0f
                // Stik analog: mulai ulang dari pusat joystik lalu langsung ke target (game joystik melayang tidak salah mengira
                // posisi geser sebagai pusat baru). Tombol & kamera tetap dari posisi terakhir.
                if (fromCenter && it.damp && !it.up && !it.tap) { it.px = it.ox; it.py = it.oy }
            }
            // Ketukan / pelepasan yang ikut batal diulang (maks 2x) supaya tidak hilang
            val again = ArrayList(flight)
            flight.clear()
            for (r in again) {
                if (r.retry < 2) {
                    val t = T(r.x, r.y)
                    t.tap = true; t.up = true; t.retry = r.retry + 1
                    touches["tap${seq++}"] = t
                }
            }
            // Pembatalan beruntun yang sangat cepat: jangan dikirim ulang tanpa jeda (itu yang membuat
            // jari virtual berkedip ratusan kali per detik). Beri jeda bertahap.
            if (quick >= 2) {
                handler.removeCallbacks(pumpLater)
                handler.postDelayed(pumpLater, minOf(15L * quick, 120L))
            } else pump()
        }
    }

    private fun pump() {
        // Pengaman: kalau callback gestur tak pernah datang (>1,5 detik), pulihkan sendiri
        if (inFlight && !building && SystemClock.uptimeMillis() - dispatchAt > 1500) {
            inFlight = false
            touches.values.forEach { it.last = null }
        }
        try {
            pumpInner()
        } catch (e: Throwable) {
            CrashLog.save(svc, "ENGINE", e)
            touches.clear(); flight.clear(); inFlight = false
        } finally {
            building = false
        }
    }

    private fun pumpInner() {
        if (inFlight || touches.isEmpty()) return
        inFlight = true
        building = true
        dispatchAt = SystemClock.uptimeMillis()
        beforeSegment?.invoke()
        if (touches.isEmpty()) { inFlight = false; return }

        flight.clear()
        val smooth = Prefs.smooth(svc)
        val sm = Prefs.smoothness(svc)
        val segMs = seg
        val segF = segMs.toFloat()
        val dm = svc.resources.displayMetrics
        val maxDim = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
        val minMove = minOf(dm.widthPixels, dm.heightPixels) * 0.006f   // gerakan lebih kecil dari ini diabaikan (anti-getar)
        val b = GestureDescription.Builder()
        for (t in touches.values) {
            if (t.tap) {
                val p = Path().apply { moveTo(t.x, t.y) }
                b.addStroke(StrokeDescription(p, 0, tapMs, false))
                flight.add(Retap(t.x, t.y, t.retry))
                continue
            }
            // Target: untuk stik gerak, perubahan sangat kecil diabaikan (anti-getar) tapi target
            // tetap bisa sampai ke ujung karena perubahan besar langsung diikuti.
            var gx = t.x
            var gy = t.y
            if (t.damp && !t.up) {
                if (hypot(t.x - t.cx, t.y - t.cy) >= minMove) { t.cx = t.x; t.cy = t.y }
                gx = t.cx; gy = t.cy
            }
            // Titik akhir segmen: mode halus mendekati target secara bertahap (tanpa melewati target)
            var ex = gx
            var ey = gy
            if (smooth && !t.up && t.last != null) {
                ex = t.px + (gx - t.px) * (1f - sm)
                ey = t.py + (gy - t.py) * (1f - sm)
                if (abs(gx - ex) < 0.5f && abs(gy - ey) < 0.5f) { ex = gx; ey = gy }
            }
            // Sentuhan yang ditahan diam: jangan kirim jalur panjang nol (dianggap "ketukan" dan rawan dibatalkan
            // sistem pada sambungan gestur). Geser 1 px bolak-balik: tidak terlihat, tapi jalurnya tetap bergerak.
            if (!t.up && abs(ex - t.px) < 0.05f && abs(ey - t.py) < 0.05f) {
                t.wig = -t.wig
                ex = t.px + t.wig
            }
            val p = Path().apply {
                moveTo(t.px, t.py)
                if (ex != t.px || ey != t.py) lineTo(ex, ey)   // garis lurus: tidak ada overshoot/getar
            }
            t.vx = (ex - t.px) / segF
            t.vy = (ey - t.py) / segF
            val s = t.last?.continueStroke(p, 0, segMs, !t.up)
                ?: StrokeDescription(p, 0, segMs, !t.up)
            b.addStroke(s)
            if (t.up) flight.add(Retap(t.x, t.y, 0))
            t.last = s
            t.px = ex
            t.py = ey
        }
        dispatchAt = SystemClock.uptimeMillis()
        if (svc.dispatchGesture(b.build(), Cb(++gen), null)) {
            touches.entries.removeAll { it.value.up }
        } else {
            // Gagal dikirim: JANGAN hapus sentuhan yang ditahan (bisa membuat jari virtual tersangkut di game).
            // Coba lagi sebentar lagi dari posisi terakhir; menyerah hanya setelah gagal terus-menerus.
            gen++
            inFlight = false
            flight.clear()
            touches.values.forEach { it.last = null }
            if (++dispatchFails > 20) { touches.clear(); dispatchFails = 0 }
            else { handler.removeCallbacks(pumpLater); handler.postDelayed(pumpLater, 30) }
        }
    }
}
