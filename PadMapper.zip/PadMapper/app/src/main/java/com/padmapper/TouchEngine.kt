package com.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path

/**
 * Mesin sentuhan virtual multi-jari.
 * - down/up : sentuhan ditahan (untuk tembak, gerak, dll.)
 * - tap     : ketukan mandiri sekali jalan (untuk pause/menu), tidak bergantung pada waktu lepas tombol
 * Semua jari aktif dikirim dalam SATU gestur per segmen supaya tidak saling membatalkan.
 */
class TouchEngine(private val svc: AccessibilityService) {

    private class T(var x: Float, var y: Float) {
        var px = x
        var py = y
        var last: StrokeDescription? = null
        var up = false
        var tap = false
        var retry = 0
    }

    private class Retap(val x: Float, val y: Float, val retry: Int)

    private val touches = LinkedHashMap<String, T>()
    private val flight = ArrayList<Retap>()
    private var inFlight = false
    private var seq = 0
    private val seg = 40L
    private val tapMs = 50L

    /** Dipanggil sebelum tiap segmen dibuat (dipakai untuk kamera stik kanan). */
    var beforeSegment: (() -> Unit)? = null

    /** (x,y) = titik sentuh awal, (tx,ty) = target pertama (untuk stik: langsung bergeser tanpa jeda). */
    fun down(id: String, x: Float, y: Float, tx: Float = x, ty: Float = y) {
        // Jangan hilangkan pelepasan sentuhan lama yang masih tertunda / tertahan
        touches[id]?.let { old ->
            old.up = true
            touches.remove(id)
            touches["$id~${seq++}"] = old
        }
        touches[id] = T(x, y).also { it.x = tx; it.y = ty }
        pump()
    }

    fun move(id: String, x: Float, y: Float) { touches[id]?.let { it.x = x; it.y = y } }
    fun up(id: String) { touches[id]?.up = true; pump() }
    fun isDown(id: String) = touches[id]?.up == false
    fun clear() { touches.clear(); flight.clear() }

    /**
     * Lepaskan semua jari virtual dengan benar. clear() saja meninggalkan sentuhan yang
     * masih "tertekan" di sistem (jari macet) karena stroke terakhirnya belum pernah ditutup.
     */
    fun releaseAll() {
        val it = touches.entries.iterator()
        while (it.hasNext()) {
            val t = it.next().value
            if (t.tap || t.up) continue
            if (t.last == null) it.remove() else t.up = true   // belum pernah dikirim = cukup dibuang
        }
        pump()
    }

    fun tap(x: Float, y: Float, retry: Int = 0) {
        val t = T(x, y)
        t.tap = true
        t.up = true
        t.retry = retry
        touches["tap${seq++}"] = t
        pump()
    }

    private val callback = object : AccessibilityService.GestureResultCallback() {
        override fun onCompleted(g: GestureDescription?) {
            inFlight = false
            flight.clear()
            pump()
        }

        override fun onCancelled(g: GestureDescription?) {
            inFlight = false
            // Sentuhan yang masih ditahan dimulai ulang sebagai sentuhan baru
            touches.values.forEach { it.last = null }
            // Ketukan / pelepasan yang ikut batal diulang (maks 2x) supaya tidak hilang
            val again = ArrayList(flight)
            flight.clear()
            for (r in again) {
                if (r.retry < 2) {
                    val t = T(r.x, r.y)
                    t.tap = true; t.up = true; t.retry = r.retry + 1
                    touches["tap${seq++}"] = t
                }
            }
            pump()
        }
    }

    private fun pump() {
        if (inFlight || touches.isEmpty()) return
        inFlight = true
        beforeSegment?.invoke()
        if (touches.isEmpty()) { inFlight = false; return }

        flight.clear()
        val b = GestureDescription.Builder()
        for (t in touches.values) {
            if (t.tap) {
                val p = Path().apply { moveTo(t.x, t.y) }
                b.addStroke(StrokeDescription(p, 0, tapMs, false))
                flight.add(Retap(t.x, t.y, t.retry))
                continue
            }
            val p = Path().apply {
                moveTo(t.px, t.py)
                if (t.x != t.px || t.y != t.py) lineTo(t.x, t.y)
            }
            val s = t.last?.continueStroke(p, 0, seg, !t.up)
                ?: StrokeDescription(p, 0, seg, !t.up)
            b.addStroke(s)
            if (t.up) flight.add(Retap(t.x, t.y, 0))
            t.last = s
            t.px = t.x
            t.py = t.y
        }
        touches.entries.removeAll { it.value.up }

        if (!svc.dispatchGesture(b.build(), callback, null)) {
            inFlight = false
            touches.clear()
            flight.clear()
        }
    }
}
