package com.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.os.SystemClock
import kotlin.math.abs

/**
 * Mesin sentuhan virtual multi-jari.
 * - down/up : sentuhan ditahan (untuk tembak, gerak, dll.)
 * - tap     : ketukan mandiri sekali jalan (untuk pause/menu), tidak bergantung pada waktu lepas tombol
 * Semua jari aktif dikirim dalam SATU gestur per segmen supaya tidak saling membatalkan.
 */
class TouchEngine(private val svc: AccessibilityService) {

    private class T(var x: Float, var y: Float) {
        var px = x
        var py = y
        var last: StrokeDescription? = null
        var up = false
        var tap = false
        var retry = 0
        var vx = 0f   // kecepatan segmen sebelumnya (px/ms) untuk lintasan bersambung
        var vy = 0f
    }

    private class Retap(val x: Float, val y: Float, val retry: Int)

    private val touches = LinkedHashMap<String, T>()
    private val flight = ArrayList<Retap>()
    private var inFlight = false
    private var seq = 0
    private val seg: Long
        get() {
            val s = Prefs.segMs(svc)
            return if (Prefs.smooth(svc)) maxOf(s, 50L) else s   // mode halus: segmen minimal 50 ms
        }
    private var dispatchAt = 0L
    private var avgLat = 0f
    private var done = 0
    private var cancels = 0
    private val tapMs = 50L

    /** Dipanggil sebelum tiap segmen dibuat (dipakai untuk kamera stik kanan). */
    var beforeSegment: (() -> Unit)? = null

    /** (x,y) = titik sentuh awal, (tx,ty) = target pertama (untuk stik: langsung bergeser tanpa jeda). */
    fun down(id: String, x: Float, y: Float, tx: Float = x, ty: Float = y) {
        // Jangan hilangkan pelepasan sentuhan lama yang masih tertunda / tertahan
        touches[id]?.let { old ->
            old.up = true
            touches.remove(id)
            touches["$id~${seq++}"] = old
        }
        touches[id] = T(x, y).also { it.x = tx; it.y = ty }
        pump()
    }

    fun move(id: String, x: Float, y: Float) { touches[id]?.let { it.x = x; it.y = y } }
    fun up(id: String) { touches[id]?.up = true; pump() }
    fun isDown(id: String) = touches[id]?.up == false
    fun clear() { touches.clear(); flight.clear() }

    /** Ringkasan latensi gestur: selisih (rata-rata - panjang segmen) = keterlambatan tambahan dari sistem. */
    fun stats(): String =
        if (done == 0) "Latensi: belum ada data (tekan tombol dulu)"
        else "Latensi gestur: ${avgLat.toInt()} ms (segmen $seg ms) | tambahan ${(avgLat - seg).toInt()} ms | batal $cancels/${done + cancels}"

    fun tap(x: Float, y: Float, retry: Int = 0) {
        val t = T(x, y)
        t.tap = true
        t.up = true
        t.retry = retry
        touches["tap${seq++}"] = t
        pump()
    }

    private val callback = object : AccessibilityService.GestureResultCallback() {
        override fun onCompleted(g: GestureDescription?) {
            val lat = (SystemClock.uptimeMillis() - dispatchAt).toFloat()
            avgLat = if (done == 0) lat else avgLat * 0.8f + lat * 0.2f
            done++
            inFlight = false
            flight.clear()
            pump()
        }

        override fun onCancelled(g: GestureDescription?) {
            cancels++
            inFlight = false
            // Sentuhan yang masih ditahan dimulai ulang sebagai sentuhan baru
            touches.values.forEach { it.last = null; it.vx = 0f; it.vy = 0f }
            // Ketukan / pelepasan yang ikut batal diulang (maks 2x) supaya tidak hilang
            val again = ArrayList(flight)
            flight.clear()
            for (r in again) {
                if (r.retry < 2) {
                    val t = T(r.x, r.y)
                    t.tap = true; t.up = true; t.retry = r.retry + 1
                    touches["tap${seq++}"] = t
                }
            }
            pump()
        }
    }

    private fun pump() {
        if (inFlight || touches.isEmpty()) return
        inFlight = true
        beforeSegment?.invoke()
        if (touches.isEmpty()) { inFlight = false; return }

        flight.clear()
        val smooth = Prefs.smooth(svc)
        val sm = Prefs.smoothness(svc)
        val segMs = seg
        val segF = segMs.toFloat()
        val dm = svc.resources.displayMetrics
        val maxDim = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
        val b = GestureDescription.Builder()
        for (t in touches.values) {
            if (t.tap) {
                val p = Path().apply { moveTo(t.x, t.y) }
                b.addStroke(StrokeDescription(p, 0, tapMs, false))
                flight.add(Retap(t.x, t.y, t.retry))
                continue
            }
            // Titik akhir segmen: mode halus mendekati target secara bertahap (tidak melompat)
            var ex = t.x
            var ey = t.y
            if (smooth && !t.up && t.last != null) {
                ex = t.px + (t.x - t.px) * (1f - sm)
                ey = t.py + (t.y - t.py) * (1f - sm)
                if (abs(t.x - ex) < 0.5f && abs(t.y - ey) < 0.5f) { ex = t.x; ey = t.y }
            }
            val p = Path().apply {
                moveTo(t.px, t.py)
                if (ex != t.px || ey != t.py) {
                    if (smooth && t.last != null && (t.vx != 0f || t.vy != 0f)) {
                        // Lengkung: melanjutkan arah gerak segmen sebelumnya (tanpa patahan arah)
                        val cx = (t.px + t.vx * segF / 2f).coerceIn(0f, maxDim)
                        val cy = (t.py + t.vy * segF / 2f).coerceIn(0f, maxDim)
                        quadTo(cx, cy, ex, ey)
                    } else lineTo(ex, ey)
                }
            }
            t.vx = (ex - t.px) / segF
            t.vy = (ey - t.py) / segF
            val s = t.last?.continueStroke(p, 0, segMs, !t.up)
                ?: StrokeDescription(p, 0, segMs, !t.up)
            b.addStroke(s)
            if (t.up) flight.add(Retap(t.x, t.y, 0))
            t.last = s
            t.px = ex
            t.py = ey
        }
        touches.entries.removeAll { it.value.up }

        dispatchAt = SystemClock.uptimeMillis()
        if (!svc.dispatchGesture(b.build(), callback, null)) {
            inFlight = false
            touches.clear()
            flight.clear()
        }
    }
}
