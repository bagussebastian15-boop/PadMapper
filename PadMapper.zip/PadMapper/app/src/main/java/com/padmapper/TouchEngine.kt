package com.padmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path

/**
 * Mesin sentuhan virtual multi-jari. Semua jari aktif dikirim dalam SATU gestur
 * per segmen (40 ms) dan disambung terus, sehingga banyak tombol bisa ditahan
 * bersamaan tanpa saling membatalkan.
 */
class TouchEngine(private val svc: AccessibilityService) {

    private class T(var x: Float, var y: Float) {
        var px = x
        var py = y
        var last: StrokeDescription? = null
        var up = false
    }

    private val touches = LinkedHashMap<String, T>()
    private var inFlight = false
    private val seg = 40L

    /** Dipanggil sebelum tiap segmen dibuat (dipakai untuk kamera stik kanan). */
    var beforeSegment: (() -> Unit)? = null

    fun down(id: String, x: Float, y: Float) { touches[id] = T(x, y); pump() }
    fun move(id: String, x: Float, y: Float) { touches[id]?.let { it.x = x; it.y = y } }
    fun up(id: String) { touches[id]?.up = true; pump() }
    fun isDown(id: String) = touches[id]?.up == false
    fun clear() { touches.clear() }

    private val callback = object : AccessibilityService.GestureResultCallback() {
        override fun onCompleted(g: GestureDescription?) { inFlight = false; pump() }
        override fun onCancelled(g: GestureDescription?) {
            inFlight = false
            touches.values.forEach { it.last = null }   // mulai ulang sebagai sentuhan baru
            touches.entries.removeAll { it.value.up }
            pump()
        }
    }

    private fun pump() {
        if (inFlight || touches.isEmpty()) return
        inFlight = true
        beforeSegment?.invoke()
        if (touches.isEmpty()) { inFlight = false; return }

        val b = GestureDescription.Builder()
        for (t in touches.values) {
            val p = Path().apply {
                moveTo(t.px, t.py)
                if (t.x != t.px || t.y != t.py) lineTo(t.x, t.y)
            }
            val s = t.last?.continueStroke(p, 0, seg, !t.up)
                ?: StrokeDescription(p, 0, seg, !t.up)
            b.addStroke(s)
            t.last = s
            t.px = t.x
            t.py = t.y
        }
        touches.entries.removeAll { it.value.up }

        if (!svc.dispatchGesture(b.build(), callback, null)) {
            inFlight = false
            touches.clear()
        }
    }
}
