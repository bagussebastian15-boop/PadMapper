package com.padmapper

import android.content.Context
import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sign

/** Pembacaan stik mentah + kalibrasi, dipakai bersama oleh layanan (saat main) dan layar kalibrasi. */
object Analog {
    const val LEFT = 0
    const val RIGHT = 1

    /**
     * Nilai mentah [kiriX, kiriY, kananX, kananY], belum dikalibrasi.
     * Pemilihan sumbu stik kanan (Z/RZ atau RX/RY) mengikuti Prefs.rsAxes.
     */
    fun raw(c: Context, e: MotionEvent, out: FloatArray = FloatArray(4)): FloatArray {
        out[0] = e.getAxisValue(MotionEvent.AXIS_X)
        out[1] = e.getAxisValue(MotionEvent.AXIS_Y)
        val z = e.getAxisValue(MotionEvent.AXIS_Z); val rz = e.getAxisValue(MotionEvent.AXIS_RZ)
        val ax = e.getAxisValue(MotionEvent.AXIS_RX); val ay = e.getAxisValue(MotionEvent.AXIS_RY)
        when (Prefs.rsAxes(c)) {
            1 -> { out[2] = z; out[3] = rz }
            2 -> { out[2] = ax; out[3] = ay }
            else -> if (hypot(z, rz) >= hypot(ax, ay)) { out[2] = z; out[3] = rz } else { out[2] = ax; out[3] = ay }
        }
        return out
    }

    /**
     * Geser ke pusat terkalibrasi lalu bagi dengan jangkauan di arah itu, jadi tiap arah
     * (kiri/kanan/atas/bawah) mencapai tepat 1.0 di ujung geraknya sendiri. Hasil -1..1.
     */
    fun normalize(c: Context, stick: Int, rx: Float, ry: Float): Pair<Float, Float> {
        val k = Prefs.stickCal(c, stick)
        val dx = rx - k[0]
        val dy = ry - k[1]
        val nx = if (dx >= 0f) dx / k[2] else dx / k[3]
        val ny = if (dy >= 0f) dy / k[4] else dy / k[5]
        return nx.coerceIn(-1f, 1f) to ny.coerceIn(-1f, 1f)
    }

    /**
     * Satu stik: mentah -> kalibrasi -> kunci arah -> deadzone radial -> sensitivitas per sumbu.
     * Menyimpan hasil terakhir supaya tahanan lurus ke satu arah tetap stabil (tidak bergetar).
     */
    class Stick(private val which: Int) {
        // setelah kalibrasi
        var nx = 0f
            private set
        var ny = 0f
            private set
        // besar simpangan terkalibrasi (dipakai untuk deadzone & histeresis)
        var mag = 0f
            private set
        // keluaran akhir
        var vx = 0f
            private set
        var vy = 0f
            private set

        fun reset() { nx = 0f; ny = 0f; mag = 0f; vx = 0f; vy = 0f }

        /** curve > 1 = kontrol lebih halus di simpangan kecil. */
        fun update(c: Context, rawX: Float, rawY: Float, curve: Float) {
            val (cx, cy0) = normalize(c, which, rawX, rawY)
            val cy = if (which == RIGHT && Prefs.camInvert(c)) -cy0 else cy0
            nx = cx; ny = cy
            mag = hypot(nx, ny)

            val dz = Prefs.deadzone(c, which)
            if (mag <= dz) { vx = 0f; vy = 0f; return }

            // Kunci arah: buang sebagian kecil sumbu minor secara halus (tanpa lompatan di ambang).
            var x = nx; var y = ny
            val snap = Prefs.snap(c)
            if (snap > 0f) {
                val ax = abs(x); val ay = abs(y)
                if (ax >= ay) y = sign(y) * maxOf(0f, ay - snap * ax)
                else x = sign(x) * maxOf(0f, ax - snap * ay)
            }

            // Deadzone radial + skala ulang: di atas deadzone naik mulus 0..1.
            val m = hypot(x, y)
            if (m <= 1e-4f) { vx = 0f; vy = 0f; return }
            val e = ((minOf(m, 1f) - dz) / (1f - dz)).coerceAtLeast(0f).pow(curve)
            var tx = x / m * e * Prefs.sens(c, which, false)
            var ty = y / m * e * Prefs.sens(c, which, true)
            if (which == LEFT) {   // joystick virtual tidak boleh melewati jangkauannya; kamera boleh lebih cepat
                val tm = hypot(tx, ty)
                if (tm > 1f) { tx /= tm; ty /= tm }
            }

            // Saring getaran kecil saat stik ditahan: abaikan perubahan < 1,2%.
            val held = vx != 0f || vy != 0f
            if (held && abs(tx - vx) < 0.012f && abs(ty - vy) < 0.012f) return
            vx = tx; vy = ty
        }
    }
}
