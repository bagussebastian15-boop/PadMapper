package com.padmapper

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.graphics.PixelFormat
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.hypot

class MapperService : AccessibilityService() {

    companion object { var instance: MapperService? = null }

    private lateinit var engine: TouchEngine
    private val ui = Handler(Looper.getMainLooper())
    private val pressed = HashSet<Int>()
    private var editor: OverlayEditor? = null
    private var catcher: StickCatcher? = null

    private val dz = 0.25f
    private var lx = 0f; private var ly = 0f
    private var rx = 0f; private var ry = 0f
    private var lsOn = false
    private var rsOn = false
    private var rsN = 0
    private var rsX = 0f; private var rsY = 0f
    private var hatX = 0; private var hatY = 0

    override fun onServiceConnected() {
        instance = this
        engine = TouchEngine(this)
        engine.beforeSegment = { driftRightStick() }
        if (Build.VERSION.SDK_INT >= 34) {            // stik analog butuh Android 14+
            val info = serviceInfo
            info.motionEventSources = InputDevice.SOURCE_JOYSTICK
            serviceInfo = info
        } else setStickMode(Prefs.stickMode(this))
    }

    /** Android < 14: tangkap stik lewat jendela 1px yang menerima fokus (game bisa kehilangan fokus). */
    fun setStickMode(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 34) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (on && catcher == null) {
            val v = StickCatcher(this) { handleMotion(it) }
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(v, lp)
            v.requestFocus()
            catcher = v
        } else if (!on && catcher != null) {
            try { wm.removeView(catcher) } catch (_: Exception) {}
            catcher = null
        }
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        setStickMode(false)
        editor?.close()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { engine.clear() }

    // ---------- Editor ----------
    fun showEditorDelayed() { ui.postDelayed({ if (editor == null) openEditor() }, 6000) }
    private fun openEditor() {
        engine.clear(); lsOn = false; rsOn = false
        editor = OverlayEditor(this) { editor = null }.also { it.show() }
    }
    private fun toggleEditor() { if (editor != null) editor?.close() else openEditor() }

    // ---------- Tombol ----------
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        if (e.action == KeyEvent.ACTION_DOWN) pressed.add(k)
        else if (e.action == KeyEvent.ACTION_UP) pressed.remove(k)

        // Kombinasi SELECT + START = buka/tutup editor posisi
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 &&
            pressed.contains(KeyEvent.KEYCODE_BUTTON_SELECT) &&
            pressed.contains(KeyEvent.KEYCODE_BUTTON_START)) {
            toggleEditor(); return true
        }
        if (editor != null) return false
        return handleKey(k, e.action == KeyEvent.ACTION_DOWN, e.repeatCount)
    }

    private fun handleKey(k: Int, isDown: Boolean, repeat: Int = 0): Boolean {
        if (k < 0 || !Prefs.PRESET.containsKey(k)) return false
        val pos = Prefs.get(this, k) ?: return false
        val id = "K$k"
        if (isDown) {
            if (repeat > 0 || engine.isDown(id)) return true
            val (w, h) = screen()
            engine.down(id, pos.first * w, pos.second * h)
        } else engine.up(id)
        return true
    }

    // ---------- Stik analog & D-pad hat (Android 14+) ----------
    override fun onMotionEvent(e: MotionEvent) { handleMotion(e) }

    private fun handleMotion(e: MotionEvent) {
        if (editor != null) return
        if (!e.isFromSource(InputDevice.SOURCE_JOYSTICK) || e.actionMasked != MotionEvent.ACTION_MOVE) return

        val hx = Math.round(e.getAxisValue(MotionEvent.AXIS_HAT_X))
        val hy = Math.round(e.getAxisValue(MotionEvent.AXIS_HAT_Y))
        if (hx != hatX) {
            if (hatX < 0) handleKey(KeyEvent.KEYCODE_DPAD_LEFT, false)
            if (hatX > 0) handleKey(KeyEvent.KEYCODE_DPAD_RIGHT, false)
            if (hx < 0) handleKey(KeyEvent.KEYCODE_DPAD_LEFT, true)
            if (hx > 0) handleKey(KeyEvent.KEYCODE_DPAD_RIGHT, true)
            hatX = hx
        }
        if (hy != hatY) {
            if (hatY < 0) handleKey(KeyEvent.KEYCODE_DPAD_UP, false)
            if (hatY > 0) handleKey(KeyEvent.KEYCODE_DPAD_DOWN, false)
            if (hy < 0) handleKey(KeyEvent.KEYCODE_DPAD_UP, true)
            if (hy > 0) handleKey(KeyEvent.KEYCODE_DPAD_DOWN, true)
            hatY = hy
        }

        lx = e.getAxisValue(MotionEvent.AXIS_X)
        ly = e.getAxisValue(MotionEvent.AXIS_Y)
        val z = e.getAxisValue(MotionEvent.AXIS_Z); val rz = e.getAxisValue(MotionEvent.AXIS_RZ)
        val ax = e.getAxisValue(MotionEvent.AXIS_RX); val ay = e.getAxisValue(MotionEvent.AXIS_RY)
        if (hypot(z, rz) >= hypot(ax, ay)) { rx = z; ry = rz } else { rx = ax; ry = ay }

        updateLeft()
        updateRight()
    }

    private fun updateLeft() {
        val mag = hypot(lx, ly)
        if (mag > dz) {
            val c = Prefs.get(this, Prefs.LS)!!
            val (w, h) = screen()
            val s = if (mag > 1f) 1f / mag else 1f
            val r = 0.12f * h
            if (!lsOn) { lsOn = true; engine.down("LS", c.first * w, c.second * h) }
            engine.move("LS", c.first * w + lx * s * r, c.second * h + ly * s * r)
        } else if (lsOn) { lsOn = false; engine.up("LS") }
    }

    private fun updateRight() {
        val mag = hypot(rx, ry)
        if (mag > dz) { if (!rsOn) { rsOn = true; startRs() } }
        else if (rsOn) { rsOn = false; engine.up("RS$rsN") }
    }

    private fun startRs() {
        val c = Prefs.get(this, Prefs.RS)!!
        val (w, h) = screen()
        rsX = c.first * w; rsY = c.second * h
        rsN++
        engine.down("RS$rsN", rsX, rsY)
    }

    /** Kamera: jari virtual terus bergeser selama stik kanan ditekan (seperti swipe terus-menerus). */
    private fun driftRightStick() {
        if (!rsOn) return
        val c = Prefs.get(this, Prefs.RS)!!
        val (w, h) = screen()
        rsX += rx * 0.02f * h
        rsY += ry * 0.02f * h
        val lim = 0.18f * h
        if (abs(rsX - c.first * w) > lim || abs(rsY - c.second * h) > lim) {
            engine.up("RS$rsN"); startRs()
        } else engine.move("RS$rsN", rsX, rsY)
    }

    private fun screen(): Pair<Float, Float> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return maxOf(dm.widthPixels, dm.heightPixels).toFloat() to
               minOf(dm.widthPixels, dm.heightPixels).toFloat()
    }
}

class StickCatcher(ctx: android.content.Context, private val onMotion: (MotionEvent) -> Unit) : View(ctx) {
    init { isFocusable = true; isFocusableInTouchMode = true }
    override fun onGenericMotionEvent(event: MotionEvent): Boolean { onMotion(event); return true }
}
