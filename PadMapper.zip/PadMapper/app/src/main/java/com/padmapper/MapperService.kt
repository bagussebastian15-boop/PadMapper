package com.padmapper

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow

class MapperService : AccessibilityService() {

    companion object { var instance: MapperService? = null }

    private lateinit var engine: TouchEngine
    private val ui = Handler(Looper.getMainLooper())
    private val pressed = HashSet<Int>()
    private var editor: OverlayEditor? = null
    private var catcher: StickCatcher? = null
    private var saveOverlay: SaveSlotOverlay? = null
    var mappingOn = true
    lateinit var bubble: Bubble
    lateinit var buttons: ButtonsOverlay
    lateinit var dots: TouchDots

    private var lx = 0f; private var ly = 0f
    private var rx = 0f; private var ry = 0f
    private var lsOn = false
    private var lsSector = -1
    private var peakL = 0.85f   // defleksi terbesar yang pernah terbaca stik kiri (gamepad murah sering tak mencapai 1.0)
    private var peakR = 0.85f
    private var rsOn = false
    private var rsSector = -1
    private var hatX = 0; private var hatY = 0
    private var dpL = false; private var dpR = false; private var dpU = false; private var dpD = false
    private var dqL = false; private var dqR = false; private var dqU = false; private var dqD = false
    private var dpOn = false
    private var lastKeyInfo = "-"
    private var lastHatInfo = "-"

    override fun onServiceConnected() {
        instance = this
        CrashLog.install(this)
        engine = TouchEngine(this)
        bubble = Bubble(this)
        buttons = ButtonsOverlay(this)
        dots = TouchDots(this)
        if (Prefs.showDots(this)) dots.show()
        if (Prefs.bubbleOn(this)) bubble.show()
        if (Prefs.showButtons(this)) buttons.show()
        if (Build.VERSION.SDK_INT >= 34) {            // stik analog langsung didukung Android 14+
            val info = serviceInfo
            info.motionEventSources = InputDevice.SOURCE_JOYSTICK
            serviceInfo = info
        } else setStickMode(Prefs.stickMode(this))
    }

    /** Android < 14: tangkap stik lewat jendela 1px yang menerima fokus (game bisa kehilangan fokus). */
    fun setStickMode(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 34) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (on && catcher == null) {
            val v = StickCatcher(this, { handleMotion(it) }, { has -> onCatcherFocus(has) })
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            try {
                wm.addView(v, lp)
                v.requestFocus()
                catcher = v
            } catch (e: Throwable) { CrashLog.save(this, "STICK", e) }
        } else if (!on && catcher != null) {
            try { wm.removeView(catcher) } catch (_: Exception) {}
            catcher = null
        }
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        setStickMode(false)
        bubble.hide()
        buttons.hide()
        dots.hide()
        editor?.close()
        saveOverlay?.close()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { engine.releaseAll() }

    // ---------- Editor ----------
    fun showEditorDelayed() { ui.postDelayed({ if (editor == null) openEditor() }, 6000) }
    private fun toggleEditor() { if (editor != null) editor?.close() else openEditor() }

    fun openEditor() {
        engine.clear(); lsOn = false; rsOn = false
        dpOn = false; dqL = false; dqR = false; dqU = false; dqD = false
        bubble.hide(); buttons.hide()
        editor = OverlayEditor(this) {
            editor = null
            if (Prefs.bubbleOn(this@MapperService)) bubble.show()
            if (Prefs.showButtons(this@MapperService)) { buttons.hide(); buttons.show() }
        }.also { it.show() }
    }

    /** Kotak nama slot di atas game (tanpa pindah aplikasi). Pemetaan dijeda selama terbuka. */
    fun openSaveSlot() {
        if (saveOverlay != null) return
        releaseSticks(); engine.releaseAll()
        val o = SaveSlotOverlay(this) { saveOverlay = null }
        saveOverlay = o          // isi dulu, baru tampilkan: kalau gagal tampil, callback menutupnya dengan benar
        o.show()
    }

    // ---------- Dipanggil dari gelembung / aplikasi ----------
    /** Lepas semua input stik/D-pad yang sedang "ditekan" (dipakai saat input macet atau fokus hilang). */
    private fun releaseSticks() {
        if (lsOn) { lsOn = false; lsSector = -1; engine.up("LS") }
        if (rsOn) { rsOn = false; rsSector = -1; engine.up("RS") }
        if (hatX < 0) handleKey(KeyEvent.KEYCODE_DPAD_LEFT, false)
        if (hatX > 0) handleKey(KeyEvent.KEYCODE_DPAD_RIGHT, false)
        if (hatY < 0) handleKey(KeyEvent.KEYCODE_DPAD_UP, false)
        if (hatY > 0) handleKey(KeyEvent.KEYCODE_DPAD_DOWN, false)
        hatX = 0; hatY = 0
        dpL = false; dpR = false; dpU = false; dpD = false
        if (dpOn) { dpOn = false; engine.up("DP") }
        dqL = false; dqR = false; dqU = false; dqD = false
        lx = 0f; ly = 0f; rx = 0f; ry = 0f
    }

    private var focusLossRunnable: Runnable? = null
    private var lastReason = "-"
    private val staleRunnable = Runnable { staleCheck() }

    /**
     * Stik yang dilepas akan kembali ke posisi diam, dan pada gamepad murah posisi diam itu sering tidak tepat di tengah
     * (misalnya agak ke kiri). Tidak ada event baru setelahnya, jadi aplikasi mengira stik masih didorong dan karakter
     * "tertarik" ke arah itu. Jika defleksi kecil (<= 55%) dan tidak ada gerakan baru selama 0,45 detik,
     * dianggap sudah dilepas. Dorongan besar (stik ditahan penuh) tidak terpengaruh.
     */
    private fun staleCheck() {
        if (lsOn && hypot(lx, ly) <= 0.55f) { lsOn = false; lsSector = -1; engine.up("LS") }
        if (rsOn && hypot(rx, ry) <= 0.55f) { rsOn = false; engine.up("RS") }
    }

    /** Untuk diagnosis di panel gelembung: nilai stik saat ini. */
    fun stickDebug(): String = String.format(
        "Stik kiri x=%.2f y=%.2f %s | kanan x=%.2f y=%.2f %s\nSentuhan terakhir dilepas karena: %s | gestur dibatalkan: %s",
        lx, ly, if (lsOn) "AKTIF" else "diam", rx, ry, if (rsOn) "AKTIF" else "diam",
        lastReason, engine.cancelInfo()
    ) + "\nTombol terakhir: $lastKeyInfo | hat: $lastHatInfo | D-pad: " +
        "${if (dpL || dqL) "K" else "-"}${if (dpR || dqR) "R" else "-"}${if (dpU || dqU) "A" else "-"}${if (dpD || dqD) "B" else "-"}" +
        " | jeda: " + listOfNotNull(
            if (editor != null) "editor" else null,
            if (!mappingOn) "mapping mati" else null,
            if (saveOverlay != null) "kotak nama" else null
        ).ifEmpty { listOf("tidak") }.joinToString("+")

    /**
     * Stik macet biasanya karena jendela penangkap stik kehilangan fokus, sehingga event "stik kembali ke tengah"
     * tak pernah terbaca. Kalau fokus hilang lebih dari 0,4 detik, semua sentuhan stik dilepas otomatis.
     * (Jeda singkat diabaikan supaya tidak mengganggu permainan.)
     */
    private fun onCatcherFocus(has: Boolean) {
        focusLossRunnable?.let { ui.removeCallbacks(it) }
        focusLossRunnable = null
        if (!has) {
            val r = Runnable {
                if (catcher?.hasWindowFocus() == false) { lastReason = "fokus jendela hilang >1,5 dtk"; releaseSticks() }
            }
            focusLossRunnable = r
            ui.postDelayed(r, 1500)
        }
    }

    /** Dipanggil setelah tata letak tersimpan dimuat: segarkan tampilan tombol di layar. */
    fun reloadLayout() {
        ui.post {
            if (editor == null && Prefs.showButtons(this)) { buttons.hide(); buttons.show() }
        }
    }

    fun enableRs(on: Boolean) {
        Prefs.setRsEnabled(this, on)
        if (!on && rsOn) { rsOn = false; engine.up("RS") }
    }

    fun enableMapping(on: Boolean) {
        mappingOn = on
        if (!on) { engine.clear(); lsOn = false; rsOn = false; dpOn = false; dqL = false; dqR = false; dqU = false; dqD = false }
    }
    fun setShowButtons(on: Boolean) {
        Prefs.setShowButtons(this, on)
        if (on && editor == null) buttons.show() else buttons.hide()
    }
    fun enableBubble(on: Boolean) {
        Prefs.setBubbleOn(this, on)
        if (on && editor == null) bubble.show() else bubble.hide()
    }
    fun engineStats(): String = engine.stats()
    fun touchSnapshot() = engine.snapshot()

    /** Pusat & jari-jari jangkauan stik kiri (piksel layar) persis seperti yang dipakai saat menyentuh. */
    fun lsReach(): Triple<Float, Float, Float> {
        val c = Prefs.get(this, Prefs.LS)!!
        val (w, h) = screen()
        return Triple(c.first * w, c.second * h, Prefs.stickRadius(this) * h * 0.9f)
    }
    fun enableDots(on: Boolean) {
        Prefs.setShowDots(this, on)
        if (on) dots.show() else dots.hide()
    }
    fun applyOpacity() { bubble.applyOpacity(); buttons.applyOpacity() }

    // ---------- Tombol ----------
    private fun fail(t: Throwable) {
        CrashLog.save(this, "ERR", t)
        try { engine.releaseAll() } catch (_: Throwable) {}
        lsOn = false; rsOn = false
        dpOn = false; dqL = false; dqR = false; dqU = false; dqD = false
    }

    override fun onKeyEvent(e: KeyEvent): Boolean =
        try { keyInner(e) } catch (t: Throwable) { fail(t); false }

    private fun keyInner(e: KeyEvent): Boolean {
        val k = e.keyCode
        lastKeyInfo = KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_") + (if (e.action == KeyEvent.ACTION_DOWN) " turun" else " naik")
        if (e.action == KeyEvent.ACTION_DOWN) pressed.add(k)
        else if (e.action == KeyEvent.ACTION_UP) pressed.remove(k)

        // Kombinasi SELECT + START = buka/tutup editor posisi
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 &&
            pressed.contains(KeyEvent.KEYCODE_BUTTON_SELECT) &&
            pressed.contains(KeyEvent.KEYCODE_BUTTON_START)) {
            toggleEditor(); return true
        }
        if (editor != null || !mappingOn || saveOverlay != null) return false
        return handleKey(k, e.action == KeyEvent.ACTION_DOWN, e.repeatCount)
    }

    private fun handleKey(k: Int, isDown: Boolean, repeat: Int = 0): Boolean {
        if (k < 0 || !Prefs.PRESET.containsKey(k)) return false
        // D-pad -> joystick virtual: kanan+atas = serong kanan-atas, dan seterusnya
        if (Prefs.dpadStick(this) && (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT ||
                k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN)) {
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT -> dpL = isDown
                KeyEvent.KEYCODE_DPAD_RIGHT -> dpR = isDown
                KeyEvent.KEYCODE_DPAD_UP -> dpU = isDown
                else -> dpD = isDown
            }
            updateLeft()
            return true
        }
        // D-pad menyentuh titiknya sendiri; dua arah bersamaan = satu sentuhan serong
        if ((k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT ||
                k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN) && !Prefs.tapMode(this, k)) {
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT -> dqL = isDown
                KeyEvent.KEYCODE_DPAD_RIGHT -> dqR = isDown
                KeyEvent.KEYCODE_DPAD_UP -> dqU = isDown
                else -> dqD = isDown
            }
            updateDpadTouch()
            return true
        }
        val pos = Prefs.get(this, k) ?: return false
        if (Prefs.tapMode(this, k)) {          // mode TAP: satu ketukan per tekanan
            if (isDown && repeat == 0) {
                val (w, h) = screen()
                engine.tap(pos.first * w, pos.second * h)
            }
            return true
        }
        val id = "K$k"
        if (isDown) {
            if (repeat > 0 || engine.isDown(id)) return true
            val (w, h) = screen()
            engine.down(id, pos.first * w, pos.second * h)
        } else engine.up(id)
        return true
    }

    // ---------- Stik analog & D-pad hat ----------
    override fun onMotionEvent(e: MotionEvent) { handleMotion(e) }

    private fun handleMotion(e: MotionEvent) {
        try { motionInner(e) } catch (t: Throwable) { fail(t) }
    }

    private fun motionInner(e: MotionEvent) {
        val hx0 = Math.round(e.getAxisValue(MotionEvent.AXIS_HAT_X))
        val hy0 = Math.round(e.getAxisValue(MotionEvent.AXIS_HAT_Y))
        if (hx0 != 0 || hy0 != 0) lastHatInfo = "($hx0,$hy0) src=0x" + Integer.toHexString(e.source)
        if (editor != null || !mappingOn || saveOverlay != null) return
        val fromPad = e.isFromSource(InputDevice.SOURCE_JOYSTICK) || e.isFromSource(InputDevice.SOURCE_GAMEPAD) ||
            e.isFromSource(InputDevice.SOURCE_DPAD)
        if (!fromPad || e.actionMasked != MotionEvent.ACTION_MOVE) return

        val hx = hx0
        val hy = hy0
        if (hx != hatX) {
            if (hatX < 0) handleKey(KeyEvent.KEYCODE_DPAD_LEFT, false)
            if (hatX > 0) handleKey(KeyEvent.KEYCODE_DPAD_RIGHT, false)
            if (hx < 0) handleKey(KeyEvent.KEYCODE_DPAD_LEFT, true)
            if (hx > 0) handleKey(KeyEvent.KEYCODE_DPAD_RIGHT, true)
            hatX = hx
        }
        if (hy != hatY) {
            if (hatY < 0) handleKey(KeyEvent.KEYCODE_DPAD_UP, false)
            if (hatY > 0) handleKey(KeyEvent.KEYCODE_DPAD_DOWN, false)
            if (hy < 0) handleKey(KeyEvent.KEYCODE_DPAD_UP, true)
            if (hy > 0) handleKey(KeyEvent.KEYCODE_DPAD_DOWN, true)
            hatY = hy
        }

        // Stik kiri: dikurangi titik tengah hasil kalibrasi
        lx = (e.getAxisValue(MotionEvent.AXIS_X) - Prefs.lsCx(this)).coerceIn(-1f, 1f)
        ly = (e.getAxisValue(MotionEvent.AXIS_Y) - Prefs.lsCy(this)).coerceIn(-1f, 1f)
        updateLeft()

        // Stik kanan (joystick virtual kedua) hanya dibaca bila diaktifkan; sumbu bawaan Z/RZ (standar Android), RX/RY bila hasil kalibrasi
        if (Prefs.rsEnabled(this)) {
            if (Prefs.rsAxes(this) == 2) {
                rx = e.getAxisValue(MotionEvent.AXIS_RX); ry = e.getAxisValue(MotionEvent.AXIS_RY)
            } else {
                rx = e.getAxisValue(MotionEvent.AXIS_Z); ry = e.getAxisValue(MotionEvent.AXIS_RZ)
            }
            rx = (rx - Prefs.rsCx(this)).coerceIn(-1f, 1f)
            ry = (ry - Prefs.rsCy(this)).coerceIn(-1f, 1f)
            updateRight()
        } else if (rsOn) {
            rsOn = false; engine.up("RS")
        }

    }

    /**
     * Deadzone radial + skala ulang: di bawah deadzone = 0, di atasnya naik mulus 0..1
     * (tidak ada lompatan mendadak saat stik mulai digerakkan). curve > 1 = kontrol halus di defleksi kecil.
     */
    private fun shape(ax: Float, ay: Float, curve: Float, peak: Float): Pair<Float, Float> {
        val mag = hypot(ax, ay)
        val dz = Prefs.deadzone(this)
        if (mag <= dz) return 0f to 0f
        val e = ((minOf(mag, peak) - dz) / (peak - dz)).pow(curve)
        return ax / mag * e to ay / mag * e
    }

    /** Stik kiri = joystick virtual: jari turun di pusat lalu bergeser sesuai arah & kekuatan stik. */
    private fun updateLeft() {
        val mag = hypot(lx, ly)
        peakL = maxOf(peakL, minOf(mag, 1f))
        val dz = Prefs.deadzone(this)
        val ddx = (if (dpR) 1 else 0) - (if (dpL) 1 else 0)
        val ddy = (if (dpD) 1 else 0) - (if (dpU) 1 else 0)
        val dpad = ddx != 0 || ddy != 0                          // D-pad menang atas stik analog
        val engage = dpad || (if (lsOn) mag > dz * 0.85f else mag > dz)   // histeresis: tidak putus-nyambung di tepi deadzone
        if (engage) {
            val c = Prefs.get(this, Prefs.LS)!!
            val (w, h) = screen()
            val r = Prefs.stickRadius(this) * h * 0.9f   // berhenti di 90% lingkaran: tetap di dalam area joystick game
            val (vx, vy) = if (dpad) {
                val n = hypot(ddx.toFloat(), ddy.toFloat())   // serong dinormalkan: panjang vektor tetap 1
                ddx / n to ddy / n
            } else if (Prefs.stick8(this)) snap8() else shape(lx, ly, 1f, peakL)
            val tx = c.first * w + vx * r
            val ty = c.second * h + vy * r
            if (!lsOn) { lsOn = true; engine.down("LS", c.first * w, c.second * h, tx, ty) }
            else engine.move("LS", tx, ty)
        } else if (lsOn) { lsOn = false; lsSector = -1; lastReason = "stik kembali ke tengah"; engine.up("LS") }
    }

    /**
     * D-pad (mode titik sendiri): satu arah = sentuh titik tombol itu; dua arah (mis. kanan+atas) = satu sentuhan
     * di titik serong, yaitu pusat D-pad digeser sejauh offset kedua arah dikali 0,707 (jaraknya sama dengan satu arah).
     */
    private fun updateDpadTouch() {
        val dx = (if (dqR) 1 else 0) - (if (dqL) 1 else 0)
        val dy = (if (dqD) 1 else 0) - (if (dqU) 1 else 0)
        if (dx == 0 && dy == 0) {
            if (dpOn) { dpOn = false; engine.up("DP") }
            return
        }
        val l = Prefs.get(this, KeyEvent.KEYCODE_DPAD_LEFT) ?: return
        val r = Prefs.get(this, KeyEvent.KEYCODE_DPAD_RIGHT) ?: return
        val u = Prefs.get(this, KeyEvent.KEYCODE_DPAD_UP) ?: return
        val d = Prefs.get(this, KeyEvent.KEYCODE_DPAD_DOWN) ?: return
        val (w, h) = screen()
        val tx: Float
        val ty: Float
        if (dx != 0 && dy != 0) {
            val cx = (l.first + r.first) / 2f * w
            val cy = (u.second + d.second) / 2f * h
            val hp = if (dx < 0) l else r
            val vp = if (dy < 0) u else d
            tx = cx + (hp.first * w - cx) * 0.7071f
            ty = cy + (vp.second * h - cy) * 0.7071f
        } else {
            val p = if (dx < 0) l else if (dx > 0) r else if (dy < 0) u else d
            tx = p.first * w; ty = p.second * h
        }
        if (dpOn && engine.isDown("DP")) engine.move("DP", tx, ty)
        else { dpOn = true; engine.down("DP", tx, ty) }
    }

    /** 8 arah dengan histeresis sudut: tidak berpindah arah karena getaran kecil di dekat batas. */
    private fun snap8(): Pair<Float, Float> {
        val a = Math.toDegrees(Math.atan2(ly.toDouble(), lx.toDouble())).toFloat()
        if (lsSector >= 0) {
            var diff = a - lsSector * 45f
            while (diff > 180f) diff -= 360f
            while (diff < -180f) diff += 360f
            if (abs(diff) <= 28f) return sectorVec(lsSector)
        }
        val sec = ((Math.round(a / 45f) % 8) + 8) % 8
        lsSector = sec
        return sectorVec(sec)
    }

    private fun sectorVec(sec: Int): Pair<Float, Float> {
        val r = Math.toRadians(sec * 45.0)
        return Math.cos(r).toFloat() to Math.sin(r).toFloat()
    }

    /** Stik kanan = joystick virtual kedua, cara kerjanya SAMA dengan stik kiri (jari ditahan di pusat RS, bergeser sesuai tarikan). */
    private fun updateRight() {
        val mag = hypot(rx, ry)
        peakR = maxOf(peakR, minOf(mag, 1f))
        val dz = Prefs.deadzone(this)
        val engage = if (rsOn) mag > dz * 0.85f else mag > dz   // histeresis: tidak putus-nyambung di tepi deadzone
        if (engage) {
            val c = Prefs.get(this, Prefs.RS)!!
            val (w, h) = screen()
            val r = Prefs.stickRadius(this) * h * 0.9f
            val (vx, vy) = if (Prefs.stick8(this)) snap8R() else shape(rx, ry, 1f, peakR)
            val tx = c.first * w + vx * r
            val ty = c.second * h + vy * r
            if (!rsOn) { rsOn = true; engine.down("RS", c.first * w, c.second * h, tx, ty) }
            else engine.move("RS", tx, ty)
        } else if (rsOn) { rsOn = false; rsSector = -1; engine.up("RS") }
    }

    /** 8 arah untuk stik kanan (sama seperti stik kiri). */
    private fun snap8R(): Pair<Float, Float> {
        val a = Math.toDegrees(Math.atan2(ry.toDouble(), rx.toDouble())).toFloat()
        if (rsSector >= 0) {
            var diff = a - rsSector * 45f
            while (diff > 180f) diff -= 360f
            while (diff < -180f) diff += 360f
            if (abs(diff) <= 28f) return sectorVec(rsSector)
        }
        val sec = ((Math.round(a / 45f) % 8) + 8) % 8
        rsSector = sec
        return sectorVec(sec)
    }

    private fun screen(): Pair<Float, Float> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return maxOf(dm.widthPixels, dm.heightPixels).toFloat() to
               minOf(dm.widthPixels, dm.heightPixels).toFloat()
    }
}

class StickCatcher(
    ctx: android.content.Context,
    private val onMotion: (MotionEvent) -> Unit,
    private val onFocusChanged: (Boolean) -> Unit
) : View(ctx) {
    init { isFocusable = true; isFocusableInTouchMode = true }
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        onFocusChanged(hasWindowFocus)
    }
    override fun onGenericMotionEvent(event: MotionEvent): Boolean { onMotion(event); return true }
}
