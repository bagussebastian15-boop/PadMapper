package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.os.Build
import android.widget.TextView
import kotlin.math.abs

/** Gelembung melayang: tap = buka panel kontrol, seret = pindahkan. */
class Bubble(private val svc: MapperService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val size = (48 * d).toInt()
    private var bubble: TextView? = null
    private var blp: WindowManager.LayoutParams? = null
    private var panel: View? = null

    private fun dp(v: Int) = (v * d).toInt()

    fun show() {
        if (bubble != null) return
        val tv = TextView(svc).apply {
            text = "PAD"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            alpha = Prefs.opacity(svc) / 100f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD1E88E5.toInt())
                setStroke(3, Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.bubbleX(svc)
            y = Prefs.bubbleY(svc)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt()
                    val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        closePanel()
                        lp.x = ox + dx; lp.y = oy + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.setBubblePos(svc, lp.x, lp.y) else togglePanel()
                }
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        blp = lp
    }

    fun hide() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        blp = null
    }

    fun applyOpacity() { bubble?.alpha = Prefs.opacity(svc) / 100f }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun label(t: String) = TextView(svc).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE)
    }

    private fun slider(p: LinearLayout, title: String, lo: Int, hi: Int, cur: Int, unit: String = "%", onChange: (Int) -> Unit) {
        val lbl = label("$title: $cur$unit")
        p.addView(lbl)
        p.addView(SeekBar(svc).apply {
            max = hi - lo
            progress = (cur - lo).coerceIn(0, hi - lo)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    lbl.text = "$title: ${lo + v}$unit"
                    onChange(lo + v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun openPanel() {
        val b = blp ?: return
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        p.addView(label("PadMapper").apply { textSize = 15f })

        p.addView(Switch(svc).apply {
            text = "Mapping aktif"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = svc.mappingOn
            setOnCheckedChangeListener { _, on -> svc.enableMapping(on) }
        })
        p.addView(Switch(svc).apply {
            text = "Tampilkan tombol di layar"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.showButtons(svc)
            setOnCheckedChangeListener { _, on -> svc.setShowButtons(on) }
        })
        if (Build.VERSION.SDK_INT < 34) {
            p.addView(Switch(svc).apply {
                text = "Mode stik analog"; setTextColor(Color.WHITE); textSize = 13f
                isChecked = Prefs.stickMode(svc)
                setOnCheckedChangeListener { _, on -> Prefs.setStickMode(svc, on); svc.setStickMode(on) }
            })
        }

        val opLabel = label("Transparansi: ${Prefs.opacity(svc)}%")
        p.addView(opLabel)
        p.addView(SeekBar(svc).apply {
            max = 80
            progress = Prefs.opacity(svc) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    Prefs.setOpacity(svc, 20 + v)
                    opLabel.text = "Transparansi: ${20 + v}%"
                    svc.applyOpacity()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        slider(p, "Deadzone kiri", 0, 50, Math.round(Prefs.deadzoneLeft(svc) * 100)) { Prefs.setDeadzoneLeft(svc, it) }
        slider(p, "Deadzone kanan", 0, 50, Math.round(Prefs.deadzoneRight(svc) * 100)) { Prefs.setDeadzoneRight(svc, it) }

        slider(p, "Interval sentuhan", 10, 80, Prefs.segMs(svc), " ms") { Prefs.setSegMs(svc, it) }

        p.addView(Button(svc).apply {
            text = "Edit posisi tombol"; textSize = 12f
            setOnClickListener { closePanel(); svc.openEditor() }
        })
        p.addView(Button(svc).apply {
            text = "Tutup"; textSize = 12f
            setOnClickListener { closePanel() }
        })

        // Panel bisa digulir supaya tidak terpotong di layar landscape yang pendek
        val sv = ScrollView(svc).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xF0222222.toInt())
            }
            addView(p)
        }
        val wpx = dp(240)
        val dm = svc.resources.displayMetrics
        val screenW = dm.widthPixels
        sv.measure(
            View.MeasureSpec.makeMeasureSpec(wpx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val lp = WindowManager.LayoutParams(
            wpx, minOf(sv.measuredHeight, dm.heightPixels - dp(16)),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (b.x + size + wpx + dp(8) > screenW) b.x - wpx - dp(8) else b.x + size + dp(8)
            y = dp(4)
        }
        wm.addView(sv, lp)
        panel = sv
    }
}
