package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.util.DisplayMetrics
import android.view.View
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.os.Build
import android.widget.TextView
import kotlin.math.abs

/** Gelembung melayang: tap = buka panel kontrol, seret = pindahkan. */
class Bubble(private val svc: MapperService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val size = (48 * d).toInt()
    private var bubble: TextView? = null
    private var blp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var liveRunnable: Runnable? = null

    // Halaman panel: 0 = utama, 1 = daftar makro, 2 = pilih pemicu, 3 = pilih tombol kombo
    private var page = 0
    private var mTrigger = -1
    private val mChosen = LinkedHashSet<Int>()

    private fun dp(v: Int) = (v * d).toInt()


    fun show() {
        if (bubble != null) return
        val tv = TextView(svc).apply {
            text = "PAD"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            alpha = Prefs.opacity(svc) / 100f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD1E88E5.toInt())
                setStroke(3, Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.bubbleX(svc)
            y = Prefs.bubbleY(svc)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt()
                    val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        closePanel()
                        lp.x = ox + dx; lp.y = oy + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.setBubblePos(svc, lp.x, lp.y) else togglePanel()
                }
            }
            true
        }
        try {
            wm.addView(tv, lp)
            bubble = tv
            blp = lp
        } catch (e: Throwable) { CrashLog.save(svc, "BUBBLE", e) }
    }

    fun hide() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        blp = null
    }

    fun applyOpacity() { bubble?.alpha = Prefs.opacity(svc) / 100f }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun closePanel() { page = 0; removePanel() }

    private fun goPage(n: Int) { page = n; removePanel(); openPanel() }

    private fun removePanel() {
        liveRunnable?.let { handler.removeCallbacks(it) }
        liveRunnable = null
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun section(p: LinearLayout, t: String) = p.addView(label(t).apply {
        textSize = 14f; setTextColor(0xFFFFB74D.toInt()); setPadding(0, dp(12), 0, dp(2))
    })

    private fun sw(p: LinearLayout, t: String, on: Boolean, f: (Boolean) -> Unit) = p.addView(Switch(svc).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f
        isChecked = on
        setOnCheckedChangeListener { _, v -> f(v) }
    })

    private fun slider(p: LinearLayout, title: String, lo: Int, hi: Int, cur: Int, unit: String = "%", f: (Int) -> Unit) {
        val l = label("$title: $cur$unit")
        p.addView(l)
        p.addView(SeekBar(svc).apply {
            max = hi - lo
            progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { l.text = "$title: ${lo + v}$unit"; f(lo + v) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun btn(p: LinearLayout, t: String, f: () -> Unit) = p.addView(Button(svc).apply {
        text = t; textSize = 12f; transformationMethod = null
        setOnClickListener { f() }
    })

    /** Tombol berbahaya: ketuk sekali = "Yakin?", ketuk lagi dalam 3 detik = jalankan. */
    private fun confirmBtn(p: LinearLayout, t: String, f: () -> Unit) = p.addView(makeConfirm(t, f))

    private fun makeConfirm(t: String, f: () -> Unit) = Button(svc).apply {
        text = t; textSize = 12f; transformationMethod = null
        var armed = false
        setOnClickListener {
            if (!armed) {
                armed = true; text = "Yakin? Ketuk lagi"
                postDelayed({ armed = false; text = t }, 3000)
            } else { armed = false; text = t; f() }
        }
    }

    private fun label(t: String) = TextView(svc).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE)
    }

    // ---------- Tombol makro (kombo), semuanya di dalam panel gelembung ----------
    private fun mlab(k: Int) = Prefs.keyLabel(k)

    private fun pill(t: String, color: Int, size: Float = 12f, f: () -> Unit) = Button(svc).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); transformationMethod = null
        minWidth = 0; minHeight = 0; setPadding(dp(6), dp(6), dp(6), dp(6))
        background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(color) }
        setOnClickListener { f() }
    }

    private fun wlp(weight: Float = 1f) =
        LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }

    private fun keyGrid(p: LinearLayout, selected: (Int) -> Boolean, mark: (Int) -> String, onTap: (Int) -> Unit) {
        for (rowKeys in Prefs.MACRO_KEYS.chunked(3)) {
            val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in rowKeys) {
                row.addView(pill(mlab(k) + mark(k), if (selected(k)) 0xFF2E7D32.toInt() else 0xFF555555.toInt(), 11f) { onTap(k) }, wlp())
            }
            repeat(3 - rowKeys.size) { row.addView(View(svc), wlp()) }
            p.addView(row)
        }
    }

    private fun bar(p: LinearLayout, vararg b: Button) {
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        for (x in b) row.addView(x, wlp())
        p.addView(row)
    }

    private fun toast(t: String) = android.widget.Toast.makeText(svc, t, android.widget.Toast.LENGTH_SHORT).show()

    private fun buildMacro(p: LinearLayout) {
        when (page) {
            1 -> {
                section(p, "TOMBOL MAKRO (KOMBO)")
                p.addView(label("Satu tombol gamepad menekan beberapa tombol sekaligus. Kamu bebas memilih pemicu dan kombinasinya.").apply {
                    textSize = 11f; setTextColor(0xFFBBBBBB.toInt())
                })
                val trig = Prefs.macroTriggers(svc)
                if (trig.isEmpty()) p.addView(label("(belum ada makro)").apply { setPadding(0, dp(8), 0, dp(8)) })
                for (t in trig) {
                    val tg = Prefs.macro(svc, t) ?: continue
                    p.addView(label("${mlab(t)} → " + tg.joinToString(" + ") { mlab(it) }).apply { setPadding(0, dp(6), 0, 0) })
                    val ubah = pill("Ubah", 0xFF1565C0.toInt()) { mTrigger = t; mChosen.clear(); mChosen.addAll(tg); goPage(3) }
                    var armed = false
                    val del = pill("Hapus", 0xFFC62828.toInt()) {}
                    del.setOnClickListener {
                        if (!armed) {
                            armed = true; del.text = "Yakin?"
                            del.postDelayed({ armed = false; del.text = "Hapus" }, 3000)
                        } else { Prefs.clearMacro(svc, t); goPage(1) }
                    }
                    bar(p, ubah, del)
                }
                bar(p,
                    pill("+ Tambah makro", 0xFF2E7D32.toInt()) { mTrigger = -1; mChosen.clear(); goPage(2) },
                    pill("Kembali", 0xFF616161.toInt()) { goPage(0) })
            }
            2 -> {
                section(p, "1/2  PILIH TOMBOL PEMICU")
                p.addView(label("Tombol yang kamu tekan di gamepad:").apply { textSize = 11f })
                keyGrid(p, { it == mTrigger }, { if (Prefs.macro(svc, it) != null) "*" else "" }) { mTrigger = it; goPage(2) }
                p.addView(label("* = sudah ada makro (akan ditimpa)").apply { textSize = 10f; setTextColor(0xFFBBBBBB.toInt()) })
                bar(p,
                    pill("Lanjut", 0xFF2E7D32.toInt()) {
                        if (mTrigger < 0) toast("Pilih tombol pemicu dulu")
                        else { mChosen.clear(); Prefs.macro(svc, mTrigger)?.let { mChosen.addAll(it) }; goPage(3) }
                    },
                    pill("Batal", 0xFF616161.toInt()) { goPage(1) })
            }
            else -> {
                section(p, "2/2  ${mlab(mTrigger)} MENEKAN SEKALIGUS")
                keyGrid(p, { it in mChosen }, { "" }) { if (!mChosen.add(it)) mChosen.remove(it); goPage(3) }
                bar(p,
                    pill("Simpan", 0xFF2E7D32.toInt()) {
                        if (mChosen.isEmpty()) toast("Pilih minimal satu tombol")
                        else { Prefs.setMacro(svc, mTrigger, Prefs.MACRO_KEYS.filter { it in mChosen }); goPage(1) }
                    },
                    pill("Kembali", 0xFF616161.toInt()) { goPage(2) })
            }
        }
    }

    private fun divider(p: LinearLayout) = p.addView(View(svc).apply { setBackgroundColor(0x33FFFFFF) },
        LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 1).apply { setMargins(0, dp(10), 0, 0) })

    private fun heading(p: LinearLayout, t: String) { divider(p); section(p, t) }

    private fun buildMain(p: LinearLayout) {
        // ===== UMUM =====
        section(p, "UMUM")
        sw(p, "Mapping aktif", svc.mappingOn) { svc.enableMapping(it) }
        sw(p, "Tampilkan tombol di layar", Prefs.showButtons(svc)) { svc.setShowButtons(it) }
        slider(p, "Transparansi", 20, 100, Prefs.opacity(svc)) { Prefs.setOpacity(svc, it); svc.applyOpacity() }

        // ===== STIK KIRI / GERAK =====
        heading(p, "STIK KIRI (GERAK)")
        sw(p, "Analog kiri & kanan", svc.analogOn) { svc.setAnalog(it) }
        sw(p, "Gerak 8 arah", Prefs.stick8(svc)) { Prefs.setStick8(svc, it) }
        sw(p, "Mode halus", Prefs.smooth(svc)) { Prefs.setSmooth(svc, it) }
        sw(p, "D-pad menggerakkan analog virtual (LS)", Prefs.dpadStick(svc)) { Prefs.setDpadStick(svc, it) }
        sw(p, "Stik mulai ulang dari pusat (anti macet)", Prefs.restartCenter(svc)) { Prefs.setRestartCenter(svc, it) }
        slider(p, "Jangkauan stik gerak", 8, 45, Math.round(Prefs.stickRadius(svc) * 100)) { Prefs.setStickRadius(svc, it) }
        slider(p, "Deadzone stik", 5, 40, Math.round(Prefs.deadzone(svc) * 100)) { Prefs.setDeadzone(svc, it) }
        slider(p, "Kehalusan", 0, 80, Math.round(Prefs.smoothness(svc) * 100)) { Prefs.setSmoothness(svc, it) }
        slider(p, "Panjang segmen gestur", 20, 150, Prefs.segMs(svc).toInt(), " ms") { Prefs.setSegMs(svc, it) }

        // ===== STIK KANAN / KAMERA =====
        heading(p, "STIK KANAN (KAMERA)")
        sw(p, "Mode kamera (geser terus)", Prefs.rsCamera(svc)) { svc.setRsCamera(it) }
        slider(p, "Kecepatan kamera", 50, 300, Math.round(Prefs.camSpeed(svc) * 100)) { Prefs.setCamSpeed(svc, it) }
        slider(p, "Jangkauan stik kamera", 8, 45, Math.round(Prefs.rsReach(svc) * 100)) { Prefs.setRsReach(svc, it) }

        // ===== KALIBRASI =====
        heading(p, "KALIBRASI")
        btn(p, "Kalibrasi stik (7 detik)") { closePanel(); svc.startCalibration() }
        confirmBtn(p, "Reset titik tengah stik") {
            Prefs.setLsCenter(svc, 0f, 0f); Prefs.setRsCenter(svc, 0f, 0f)
            android.widget.Toast.makeText(svc, "Titik tengah stik direset ke 0", android.widget.Toast.LENGTH_SHORT).show()
        }

        // ===== TATA LETAK & MAKRO =====
        heading(p, "TATA LETAK & MAKRO")
        btn(p, "Edit posisi tombol") { closePanel(); svc.openEditor() }
        btn(p, "Tombol makro (kombo)...") { goPage(1) }
        btn(p, "Simpan slot") { closePanel(); svc.openSaveSlot() }
        p.addView(label("Muat slot:").apply { setPadding(0, dp(6), 0, 0) })
        val saved = ProfileStore.names(svc)
        if (saved.isEmpty()) p.addView(label("(belum ada slot)").apply { textSize = 11f })
        for (n in saved) {
            val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(Button(svc).apply {
                text = n; textSize = 12f; transformationMethod = null
                setOnClickListener {
                    if (ProfileStore.load(svc, n)) {
                        android.widget.Toast.makeText(svc, "Dimuat: $n", android.widget.Toast.LENGTH_SHORT).show()
                        closePanel()
                    }
                }
            }, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(makeConfirm("Hapus") { ProfileStore.delete(svc, n); goPage(0) })
            p.addView(row)
        }

        // ===== DIAGNOSIS =====
        heading(p, "DIAGNOSIS")
        sw(p, "Titik jari virtual", Prefs.fingerDots(svc)) { svc.setFingerDots(it) }
        val err = CrashLog.last(svc)
        if (err.isNotEmpty()) {
            p.addView(label("Log error terakhir:").apply { textSize = 11f; setPadding(0, dp(6), 0, 0) })
            p.addView(label(err.take(400)).apply { textSize = 10f })
            btn(p, "Salin log (untuk dikirim)") {
                val cm = svc.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("PadMapper log", err))
                android.widget.Toast.makeText(svc, "Log disalin", android.widget.Toast.LENGTH_SHORT).show()
            }
            btn(p, "Hapus log") { CrashLog.clear(svc); goPage(0) }
        }

        // ===== RESET =====
        heading(p, "RESET")
        confirmBtn(p, "Reset semua persenan ke awal") {
            Prefs.resetSliders(svc)
            svc.applyOpacity()
            svc.reloadLayout()
            android.widget.Toast.makeText(svc, "Semua persenan dikembalikan ke awal", android.widget.Toast.LENGTH_SHORT).show()
            goPage(0)
        }
        confirmBtn(p, "AUTO MAP / RESET tata letak") {
            Prefs.reset(svc)
            svc.reloadLayout()
            android.widget.Toast.makeText(svc, "Mapping default aktif!", android.widget.Toast.LENGTH_SHORT).show()
            closePanel()
        }
    }

    private fun openPanel() {
        val b = blp ?: return
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val header = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("PadMapper").apply { textSize = 15f }, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(svc).apply {
            text = "X"; textSize = 12f
            setOnClickListener { closePanel() }
        }, LinearLayout.LayoutParams(dp(48), dp(40)))
        p.addView(header)
        if (page != 0) buildMacro(p) else buildMain(p)

        p.addView(Button(svc).apply {
            text = "Tutup"; textSize = 12f
            setOnClickListener { closePanel() }
        })

        val wpx = dp(250)
        val real = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(real)
        val screenW = real.widthPixels
        val screenH = real.heightPixels
        // Ukur isi panel; kalau lebih tinggi dari layar, batasi tinggi jendela dan biarkan isinya bisa digulir
        p.measure(
            View.MeasureSpec.makeMeasureSpec(wpx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val panelH = minOf(p.measuredHeight, screenH - dp(16))
        val sv = ScrollView(svc).apply {
            isVerticalScrollBarEnabled = true
            isFillViewport = false
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xF0222222.toInt())
            }
            addView(p)
        }
        val lp = WindowManager.LayoutParams(
            wpx, panelH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (b.x + size + wpx + dp(8) > screenW) maxOf(0, b.x - wpx - dp(8)) else b.x + size + dp(8)
            y = dp(8)
        }
        try {
            wm.addView(sv, lp)
            panel = sv
        } catch (e: Throwable) { CrashLog.save(svc, "PANEL", e) }
    }
}
