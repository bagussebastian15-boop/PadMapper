package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.util.DisplayMetrics
import android.view.View
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.os.Build
import android.widget.TextView
import kotlin.math.abs

/** Gelembung melayang: tap = buka panel kontrol, seret = pindahkan. */
class Bubble(private val svc: MapperService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val size = (48 * d).toInt()
    private var bubble: TextView? = null
    private var blp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var liveRunnable: Runnable? = null

    private fun dp(v: Int) = (v * d).toInt()


    fun show() {
        if (bubble != null) return
        val tv = TextView(svc).apply {
            text = "PAD"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            alpha = Prefs.opacity(svc) / 100f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD1E88E5.toInt())
                setStroke(3, Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.bubbleX(svc)
            y = Prefs.bubbleY(svc)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt()
                    val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        closePanel()
                        lp.x = ox + dx; lp.y = oy + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.setBubblePos(svc, lp.x, lp.y) else togglePanel()
                }
            }
            true
        }
        try {
            wm.addView(tv, lp)
            bubble = tv
            blp = lp
        } catch (e: Throwable) { CrashLog.save(svc, "BUBBLE", e) }
    }

    fun hide() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        blp = null
    }

    fun applyOpacity() { bubble?.alpha = Prefs.opacity(svc) / 100f }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun closePanel() {
        liveRunnable?.let { handler.removeCallbacks(it) }
        liveRunnable = null
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun label(t: String) = TextView(svc).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE)
    }

    private fun openPanel() {
        val b = blp ?: return
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val header = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("PadMapper").apply { textSize = 15f }, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(svc).apply {
            text = "X"; textSize = 12f
            setOnClickListener { closePanel() }
        }, LinearLayout.LayoutParams(dp(48), dp(40)))
        p.addView(header)
        p.addView(Switch(svc).apply {
            text = "Mapping aktif"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = svc.mappingOn
            setOnCheckedChangeListener { _, on -> svc.enableMapping(on) }
        })
        p.addView(Switch(svc).apply {
            text = "Analog kiri & kanan"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = svc.analogOn
            setOnCheckedChangeListener { _, on -> svc.setAnalog(on) }
        })
        if (Build.VERSION.SDK_INT < 34) {
            p.addView(Switch(svc).apply {
                text = "Penangkap stik (matikan bila game freeze)"; setTextColor(Color.WHITE); textSize = 13f
                isChecked = Prefs.stickMode(svc)
                setOnCheckedChangeListener { _, on -> Prefs.setStickMode(svc, on); svc.syncCatcher() }
            })
            val pkg = svc.currentPkg()
            if (pkg.isNotEmpty()) p.addView(Switch(svc).apply {
                text = "Tanpa penangkap untuk app ini ($pkg)"; setTextColor(Color.WHITE); textSize = 13f
                isChecked = pkg in Prefs.catcherSkip(svc)
                setOnCheckedChangeListener { _, on -> Prefs.setCatcherSkip(svc, pkg, on); svc.syncCatcher() }
            })
        }
        p.addView(Switch(svc).apply {
            text = "Gerak 8 arah"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.stick8(svc)
            setOnCheckedChangeListener { _, on -> Prefs.setStick8(svc, on) }
        })
        p.addView(Switch(svc).apply {
            text = "Mode halus"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.smooth(svc)
            setOnCheckedChangeListener { _, on -> Prefs.setSmooth(svc, on) }
        })
        p.addView(Switch(svc).apply {
            text = "Tampilkan tombol di layar"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.showButtons(svc)
            setOnCheckedChangeListener { _, on -> svc.setShowButtons(on) }
        })
        p.addView(Switch(svc).apply {
            text = "Titik jari virtual (diagnosis)"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.fingerDots(svc)
            setOnCheckedChangeListener { _, on -> svc.setFingerDots(on) }
        })

        p.addView(Switch(svc).apply {
            text = "Stik mulai ulang dari pusat (anti macet)"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.restartCenter(svc)
            setOnCheckedChangeListener { _, on -> Prefs.setRestartCenter(svc, on) }
        })
        p.addView(Switch(svc).apply {
            text = "Stik kanan: mode kamera (geser terus)"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.rsCamera(svc)
            setOnCheckedChangeListener { _, on -> svc.setRsCamera(on) }
        })
        val camPct = Math.round(Prefs.camSpeed(svc) * 100)
        val camLabel = label("Kecepatan kamera: $camPct%")
        p.addView(camLabel)
        p.addView(SeekBar(svc).apply {
            max = 250                                  // 50..300 %
            progress = camPct - 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    Prefs.setCamSpeed(svc, 50 + v)
                    camLabel.text = "Kecepatan kamera: ${50 + v}%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        val rrPct = Math.round(Prefs.rsReach(svc) * 100)
        val rrLabel = label("Jangkauan stik kamera: $rrPct%")
        p.addView(rrLabel)
        p.addView(SeekBar(svc).apply {
            max = 37                                   // 8..45 %
            progress = rrPct - 8
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    Prefs.setRsReach(svc, 8 + v)
                    rrLabel.text = "Jangkauan stik kamera: ${8 + v}%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        val opLabel = label("Transparansi: ${Prefs.opacity(svc)}%")
        p.addView(opLabel)
        p.addView(SeekBar(svc).apply {
            max = 80
            progress = Prefs.opacity(svc) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    Prefs.setOpacity(svc, 20 + v)
                    opLabel.text = "Transparansi: ${20 + v}%"
                    svc.applyOpacity()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        val reachPct = Math.round(Prefs.stickRadius(svc) * 100)
        val reachLabel = label("Jangkauan stik gerak: $reachPct%")
        p.addView(reachLabel)
        p.addView(SeekBar(svc).apply {
            max = 37                                   // 8..45 %
            progress = reachPct - 8
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    Prefs.setStickRadius(svc, 8 + v)
                    reachLabel.text = "Jangkauan stik gerak: ${8 + v}%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        // Slot tata letak: simpan (minta nama lewat dialog) dan muat
        p.addView(Button(svc).apply {
            text = "Simpan slot"; textSize = 12f
            setOnClickListener {
                closePanel()
                svc.openSaveSlot()   // tampil di atas game, tanpa pindah aplikasi
            }
        })
        p.addView(label("Muat slot:"))
        val saved = ProfileStore.names(svc)
        if (saved.isEmpty()) p.addView(label("(belum ada slot)").apply { textSize = 11f })
        for (n in saved) {
            p.addView(Button(svc).apply {
                text = n; textSize = 12f; transformationMethod = null
                setOnClickListener {
                    if (ProfileStore.load(svc, n)) {
                        android.widget.Toast.makeText(svc, "Dimuat: $n", android.widget.Toast.LENGTH_SHORT).show()
                        closePanel()
                    }
                }
            })
        }
        p.addView(Button(svc).apply {
            text = "Edit posisi tombol"; textSize = 12f
            setOnClickListener { closePanel(); svc.openEditor() }
        })
        p.addView(Button(svc).apply {
            text = "Tutup"; textSize = 12f
            setOnClickListener { closePanel() }
        })

        val wpx = dp(250)
        val real = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(real)
        val screenW = real.widthPixels
        val screenH = real.heightPixels
        // Ukur isi panel; kalau lebih tinggi dari layar, batasi tinggi jendela dan biarkan isinya bisa digulir
        p.measure(
            View.MeasureSpec.makeMeasureSpec(wpx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val panelH = minOf(p.measuredHeight, screenH - dp(16))
        val sv = ScrollView(svc).apply {
            isVerticalScrollBarEnabled = true
            isFillViewport = false
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xF0222222.toInt())
            }
            addView(p)
        }
        val lp = WindowManager.LayoutParams(
            wpx, panelH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (b.x + size + wpx + dp(8) > screenW) maxOf(0, b.x - wpx - dp(8)) else b.x + size + dp(8)
            y = dp(8)
        }
        try {
            wm.addView(sv, lp)
            panel = sv
        } catch (e: Throwable) { CrashLog.save(svc, "PANEL", e) }
    }
}
