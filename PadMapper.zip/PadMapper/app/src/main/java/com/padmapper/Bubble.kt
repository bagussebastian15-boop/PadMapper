package com.padmapper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.os.Build
import android.widget.TextView
import kotlin.math.abs

/** Gelembung melayang: tap = buka panel kontrol, seret = pindahkan. */
class Bubble(private val svc: MapperService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private val size = (48 * d).toInt()
    private var bubble: TextView? = null
    private var blp: WindowManager.LayoutParams? = null
    private var panel: android.view.View? = null

    private fun dp(v: Int) = (v * d).toInt()

    fun show() {
        if (bubble != null) return
        val tv = TextView(svc).apply {
            text = "PAD"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            alpha = Prefs.opacity(svc) / 100f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD1E88E5.toInt())
                setStroke(3, Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.bubbleX(svc)
            y = Prefs.bubbleY(svc)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt()
                    val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        closePanel()
                        lp.x = ox + dx; lp.y = oy + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.setBubblePos(svc, lp.x, lp.y) else togglePanel()
                }
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        blp = lp
    }

    fun hide() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        blp = null
    }

    fun applyOpacity() { bubble?.alpha = Prefs.opacity(svc) / 100f }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun label(t: String) = TextView(svc).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE)
    }

    private fun slider(p: LinearLayout, title: String, lo: Int, hi: Int, cur: Int, onChange: (Int) -> Unit) {
        val lbl = label("$title: $cur%")
        p.addView(lbl)
        p.addView(SeekBar(svc).apply {
            max = hi - lo
            progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    lbl.text = "$title: ${lo + v}%"
                    onChange(lo + v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun openPanel() {
        val b = blp ?: return
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        p.addView(label("PadMapper").apply { textSize = 15f })

        p.addView(Switch(svc).apply {
            text = "Mapping aktif"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = svc.mappingOn
            setOnCheckedChangeListener { _, on -> svc.enableMapping(on) }
        })
        p.addView(Switch(svc).apply {
            text = "Tampilkan tombol di layar"; setTextColor(Color.WHITE); textSize = 13f
            isChecked = Prefs.showButtons(svc)
            setOnCheckedChangeListener { _, on -> svc.setShowButtons(on) }
        })
        if (Build.VERSION.SDK_INT < 34) {
            p.addView(Switch(svc).apply {
                text = "Mode stik analog"; setTextColor(Color.WHITE); textSize = 13f
                isChecked = Prefs.stickMode(svc)
                setOnCheckedChangeListener { _, on -> Prefs.setStickMode(svc, on); svc.setStickMode(on) }
            })
        }

        val opLabel = label("Transparansi: ${Prefs.opacity(svc)}%")
        p.addView(opLabel)
        p.addView(SeekBar(svc).apply {
            max = 80
            progress = Prefs.opacity(svc) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    Prefs.setOpacity(svc, 20 + v)
                    opLabel.text = "Transparansi: ${20 + v}%"
                    svc.applyOpacity()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        // ---- Analog ----
        p.addView(label("\nANALOG").apply { textSize = 14f })
        slider(p, "Deadzone kiri", 0, 40, Math.round(Prefs.deadzoneL(svc) * 100)) { Prefs.setDeadzoneL(svc, it) }
        slider(p, "Deadzone kanan", 0, 40, Math.round(Prefs.deadzoneR(svc) * 100)) { Prefs.setDeadzoneR(svc, it) }
        slider(p, "Deadzone luar", 0, 15, Math.round(Prefs.outerZone(svc) * 100)) { Prefs.setOuterZone(svc, it) }
        p.addView(Button(svc).apply {
            text = "Kalibrasi pusat analog"; textSize = 12f
            setOnClickListener { closePanel(); svc.calibrateCenter() }
        })
        p.addView(Button(svc).apply {
            text = "Reset pusat analog"; textSize = 12f
            setOnClickListener { Prefs.resetCenter(svc) }
        })
        slider(p, "Sensitivitas X", 50, 200, Math.round(Prefs.sensX(svc) * 100)) { Prefs.setSensX(svc, it) }
        slider(p, "Sensitivitas Y", 50, 200, Math.round(Prefs.sensY(svc) * 100)) { Prefs.setSensY(svc, it) }
        slider(p, "Rentang kiri", 50, 150, Math.round(Prefs.range(svc, 0) * 100)) { Prefs.setRange(svc, 0, it) }
        slider(p, "Rentang kanan", 50, 150, Math.round(Prefs.range(svc, 1) * 100)) { Prefs.setRange(svc, 1, it) }
        slider(p, "Rentang atas", 50, 150, Math.round(Prefs.range(svc, 2) * 100)) { Prefs.setRange(svc, 2, it) }
        slider(p, "Rentang bawah", 50, 150, Math.round(Prefs.range(svc, 3) * 100)) { Prefs.setRange(svc, 3, it) }
        slider(p, "Kunci arah (0 = mati)", 0, 30, Math.round(Prefs.axisLock(svc) * 100)) { Prefs.setAxisLock(svc, it) }
        slider(p, "Jangkauan stik gerak", 5, 25, Math.round(Prefs.stickRadius(svc) * 100)) { Prefs.setStickRadius(svc, it) }
        slider(p, "Kecepatan kamera", 50, 300, Math.round(Prefs.camSpeed(svc) * 100)) { Prefs.setCamSpeed(svc, it) }

        p.addView(Button(svc).apply {
            text = "Edit posisi tombol"; textSize = 12f
            setOnClickListener { closePanel(); svc.openEditor() }
        })
        p.addView(Button(svc).apply {
            text = "Tutup"; textSize = 12f
            setOnClickListener { closePanel() }
        })

        val wpx = dp(260)
        val screenW = svc.resources.displayMetrics.widthPixels
        val screenH = svc.resources.displayMetrics.heightPixels
        // Panel digulir bila lebih tinggi dari layar
        p.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(wpx, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED)
        )
        val hpx = minOf(p.measuredHeight, screenH - dp(16))
        val sv = ScrollView(svc).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xF0222222.toInt())
            }
            addView(p)
        }
        val lp = WindowManager.LayoutParams(
            wpx, hpx,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (b.x + size + wpx + dp(8) > screenW) b.x - wpx - dp(8) else b.x + size + dp(8)
            y = dp(4)
        }
        wm.addView(sv, lp)
        panel = sv
    }
}
